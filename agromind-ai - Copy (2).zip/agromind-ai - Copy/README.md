# AgroMind AI — Intelligent Smart Farming Companion

> **Problem Statement 14:** AI Agent for Smart Farming Advice  
> **Technology:** IBM Granite (watsonx.ai) · LangChain · RAG · FastAPI · React

[![IBM Granite](https://img.shields.io/badge/IBM-Granite%2013B-0f62fe?style=flat&logo=ibm)](https://www.ibm.com/products/watsonx-ai)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?style=flat)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-18-61dafb?style=flat)](https://react.dev)

## 🌾 Overview

AgroMind AI is an intelligent agricultural advisory platform powered by **IBM Granite** (via IBM watsonx.ai) that provides personalized, practical, and sustainable farming recommendations to Indian farmers.

The system uses **four specialized AI agents** coordinated by an **orchestrator** to answer complex farming questions:

- 🌱 **Crop Advisory Agent** — Crop selection, nutrient management, planting calendar
- 🌤 **Weather & Irrigation Agent** — Weather forecasts, irrigation scheduling
- 🔍 **Pest & Disease Detection Agent** — Image analysis, IPM recommendations
- 📊 **Market Insights Agent** — APMC prices, profitability analysis

## ✨ Key Features

| Feature | Status |
|---------|--------|
| IBM Granite via watsonx.ai integration | ✅ (API key required / DEMO mode available) |
| Multi-agent orchestration | ✅ Full implementation |
| RAG knowledge retrieval (ChromaDB) | ✅ Full implementation |
| Crop disease detection (image upload) | ✅ Full implementation |
| Weather-based irrigation advisory | ✅ (API key / DEMO mode) |
| Market price & profitability analysis | ✅ (API key / DEMO mode) |
| Farmer profile management (SQLite) | ✅ Full implementation |
| Knowledge base upload & indexing | ✅ Full implementation |
| Kannada + English language support | ✅ Structure ready |
| Responsive React dashboard (10 pages) | ✅ Full implementation |
| Demo mode with realistic Karnataka data | ✅ Full implementation |

## 🚀 Quick Start

### Prerequisites
- Python 3.10+ 
- Node.js 18+
- pip

### 1. Backend (PowerShell)

```powershell
cd agromind-ai\backend
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
uvicorn app.main:app --reload
```

Or use the one-click script:
```powershell
cd agromind-ai\backend
.\start.ps1
```

### 2. Frontend (PowerShell)

```powershell
cd agromind-ai\frontend
npm install
npm run dev
```

Or use the one-click script:
```powershell
cd agromind-ai\frontend
.\start.ps1
```

Open **http://localhost:5173**

## 🔧 IBM Granite Configuration

Add to `backend/.env`:

```env
WATSONX_API_KEY=your_ibm_cloud_api_key
WATSONX_PROJECT_ID=your_watsonx_project_id
WATSONX_URL=https://us-south.ml.cloud.ibm.com
WATSONX_MODEL_ID=ibm/granite-13b-chat-v2
```

Get credentials at [IBM Cloud](https://cloud.ibm.com/catalog/services/watsonx-ai).

> **Without IBM Granite credentials:** The app runs in **DEMO MODE** — all features work with realistic Karnataka agricultural data. DEMO badges are shown clearly throughout the UI.

## 📁 Project Structure

```
agromind-ai/
├── backend/
│   ├── app/
│   │   ├── main.py                    # FastAPI entry point
│   │   ├── config.py                  # Environment configuration
│   │   ├── api/                       # Route handlers
│   │   ├── agents/
│   │   │   ├── orchestrator.py        # Agent coordinator
│   │   │   ├── crop_advisory_agent.py
│   │   │   ├── weather_irrigation_agent.py
│   │   │   ├── pest_disease_agent.py
│   │   │   └── market_insights_agent.py
│   │   ├── services/
│   │   │   └── granite_service.py     # IBM Granite adapter
│   │   ├── rag/pipeline.py            # ChromaDB RAG pipeline
│   │   ├── models/                    # Database models
│   │   ├── schemas/                   # Pydantic schemas
│   │   └── database/                  # SQLite connection
│   ├── tests/test_api.py              # Test suite
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.tsx                    # Router + Layout
│   │   ├── components/
│   │   │   ├── Layout.tsx             # Sidebar navigation
│   │   │   └── UI.tsx                 # Shared components
│   │   ├── pages/                     # 10 application pages
│   │   ├── services/api.ts            # Centralized API client
│   │   ├── hooks/                     # Custom React hooks
│   │   └── types/                     # TypeScript types
│   ├── package.json
│   └── .env.example
├── knowledge_base/                    # Agricultural documents
├── docs/                              # Architecture & guides
└── README.md
```

## 🧠 Architecture

```
Farmer Query → FastAPI → Orchestrator → [Intent Classification]
                                           ↓
                              ┌────────────┴────────────┐
                              ↓            ↓             ↓
                         Crop Agent  Weather Agent  Pest Agent
                              ↓            ↓             ↓
                          Market Agent  RAG Pipeline  IBM Granite
                              ↓            ↓             ↓
                          ChromaDB     watsonx.ai    DEMO fallback
                              └────────────┬────────────┘
                                           ↓
                              Unified Advisory → Farmer
```

## 📚 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | System health check |
| `/api/chat` | POST | Main AI advisory chat |
| `/api/farmer/profile` | GET/POST/PUT | Farmer profile management |
| `/api/advisory/crop` | POST | Crop-specific advisory |
| `/api/advisory/irrigation` | POST | Irrigation advisory |
| `/api/detection/analyze` | POST | Pest/disease detection |
| `/api/market/insights` | POST | Market price analysis |
| `/api/rag/query` | POST | RAG knowledge search |
| `/api/knowledge/upload` | POST | Upload knowledge docs |
| `/api/knowledge/sources` | GET | List knowledge sources |
| `/api/agents/status` | GET | Agent status |
| `/api/integrations/status` | GET | Integration status |
| `/api/history` | GET | Advisory history |

Full docs: http://localhost:8000/api/docs

## 🧪 Tests

```bash
cd backend
pytest tests/ -v
```

Tests cover: health endpoint, farmer profile CRUD, crop advisory, disease detection, market insights, RAG query, integrations status, and demo mode.

## 🌍 Supported Crops & Regions

- **States:** Karnataka (primary), all major Indian states
- **Crops:** Ragi, Paddy, Maize, Groundnut, Cotton, Soybean, Wheat, Jowar, Bajra, Sunflower, Chickpea, Tomato, Onion, Sugarcane
- **Seasons:** Kharif, Rabi, Zaid
- **Languages:** English (full), Kannada (structure ready), Hindi (structure ready)

## ⚠️ Disclaimers

- AgroMind AI provides advisory support only. Recommendations must be verified with qualified agricultural experts.
- AI suggestions do not replace professional agricultural advice.
- Market prices are indicative estimates; actual prices vary by mandi and quality.
- Disease detection is AI-assisted and should be confirmed by laboratory analysis.

## 📄 License

Built for IBM PS14 Hackathon — Smart Farming AI Agent  
© 2024 AgroMind AI Team
