# AgroMind AI — Knowledge Base

## Overview

The AgroMind AI knowledge base powers the RAG (Retrieval-Augmented Generation) pipeline.
Documents are chunked, embedded, and stored in ChromaDB for semantic retrieval.

## Sample Corpus (Auto-loaded on startup)

| Document | Source | Crop | State |
|----------|--------|------|-------|
| Ragi Cultivation Guide — Karnataka | ICAR / IIMR | Ragi | Karnataka |
| Karnataka Kharif Season Crop Advisory 2024 | Karnataka Dept. of Agriculture | All | Karnataka |
| Integrated Pest Management in Cotton | ICAR / CICR | Cotton | All India |
| Soil Health Management — KVK Karnataka Guidelines | KVK Karnataka | All | Karnataka |
| IMD Agricultural Weather Advisory — Karnataka 2024 | IMD | All | Karnataka |
| APMC Market Price Information — Karnataka 2024 | AGMARKNET / Karnataka APMC | All | Karnataka |

## How to Add Documents

### Via Web Interface
1. Go to **Knowledge Base** → **Upload** tab
2. Fill in document metadata (title, organization, crop, state)
3. Upload PDF, TXT, or Markdown file
4. Click "Upload & Index Document"

### Via API
```bash
curl -X POST http://localhost:8000/api/knowledge/upload \
  -F "title=ICAR Ragi Guide" \
  -F "organization=ICAR" \
  -F "crop=ragi" \
  -F "state=Karnataka" \
  -F "language=en" \
  -F "file=@ragi_guide.pdf"
```

## Trusted Sources for Uploading

- **ICAR (Indian Council of Agricultural Research)**: https://www.icar.org.in
- **Krishi Vigyan Kendras (KVKs)**: https://kvk.icar.gov.in
- **Karnataka Dept. of Agriculture (Raithamitra)**: https://raitamitra.karnataka.gov.in
- **India Meteorological Department (IMD)**: https://imd.gov.in
- **AGMARKNET**: https://agmarknet.gov.in
- **e-NAM**: https://enam.gov.in
- **UAS Dharwad**: https://uasd.edu.in
- **GKVK Bangalore**: https://gkvk.uasbangalore.edu.in

## Disclaimer

Only upload documents from verifiable, authoritative sources.
Never upload unofficial content as agricultural guidance.
All uploaded documents should have proper attribution (organization, source URL).
