"""
AgroMind AI — Backend Test Suite
Tests health, profile, agents, RAG, and demo mode.
"""
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from app.main import app
from app.config import settings


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ─── Health Endpoint ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health(client):
    resp = await client.get("/api/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "services" in data
    assert data["app"] == "AgroMind AI"


@pytest.mark.asyncio
async def test_root(client):
    resp = await client.get("/")
    assert resp.status_code == 200
    data = resp.json()
    assert data["app"] == "AgroMind AI"


# ─── Farmer Profile ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_create_and_get_farmer_profile(client):
    # Create
    payload = {
        "farmer_id": "test_farmer_001",
        "name": "Ramesh Kumar",
        "state": "Karnataka",
        "district": "Mysuru",
        "village": "Mandya Village",
        "farm_size": 2.5,
        "farm_size_unit": "acres",
        "soil_type": "red laterite",
        "current_crop": "Ragi",
        "season": "Kharif",
        "budget": 25000.0,
        "farming_preference": "conventional",
    }
    create_resp = await client.post("/api/farmer/profile", json=payload)
    assert create_resp.status_code == 200
    data = create_resp.json()
    assert data["farmer_id"] == "test_farmer_001"
    assert data["district"] == "Mysuru"

    # Get
    get_resp = await client.get("/api/farmer/profile/test_farmer_001")
    assert get_resp.status_code == 200
    assert get_resp.json()["name"] == "Ramesh Kumar"


@pytest.mark.asyncio
async def test_update_farmer_profile(client):
    payload = {
        "name": "Ramesh Kumar (updated)",
        "state": "Karnataka",
        "district": "Mysuru",
        "current_crop": "Maize",
        "crop_stage": "vegetative",
    }
    resp = await client.put("/api/farmer/profile/test_farmer_001", json=payload)
    assert resp.status_code == 200
    assert resp.json()["current_crop"] == "Maize"


@pytest.mark.asyncio
async def test_farmer_not_found(client):
    resp = await client.get("/api/farmer/profile/nonexistent_farmer")
    assert resp.status_code == 404


# ─── Chat / Advisory (Demo Mode) ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_chat_demo_mode(client):
    payload = {"query": "What crop should I grow this kharif season?", "language": "en"}
    resp = await client.post("/api/chat", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "answer" in data
    assert len(data["answer"]) > 10
    # In demo mode, agents should still be invoked
    assert "agents_used" in data


@pytest.mark.asyncio
async def test_chat_disease_query(client):
    payload = {
        "query": "My crop leaves are turning yellow. What should I do?",
        "farmer_id": "test_farmer_001",
        "language": "en",
    }
    resp = await client.post("/api/chat", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "answer" in data


@pytest.mark.asyncio
async def test_chat_invalid_query(client):
    payload = {"query": "Hi", "language": "en"}  # too short — min_length=3 passes, but let's check 1 char
    resp = await client.post("/api/chat", json={"query": "H", "language": "en"})
    assert resp.status_code == 422  # Validation error


# ─── Crop Advisory ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_crop_advisory(client):
    payload = {
        "state": "Karnataka",
        "district": "Davangere",
        "season": "Kharif",
        "soil_type": "red laterite",
        "budget": 15000,
        "farming_preference": "conventional",
    }
    resp = await client.post("/api/advisory/crop", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "recommended_crops" in data
    assert len(data["recommended_crops"]) > 0


# ─── Disease Detection (no image) ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_disease_detection_text_only(client):
    resp = await client.post(
        "/api/detection/analyze",
        data={"query": "Leaves are yellowing from the bottom of the plant"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "detected_issue" in data
    assert "ipm_recommendations" in data
    assert "disclaimer" in data


@pytest.mark.asyncio
async def test_disease_detection_invalid_file_type(client):
    import io
    resp = await client.post(
        "/api/detection/analyze",
        data={"query": "test"},
        files={"image": ("test.txt", io.BytesIO(b"not an image"), "text/plain")},
    )
    assert resp.status_code == 400


# ─── Market Insights ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_market_insights(client):
    payload = {
        "crop": "Ragi",
        "district": "Davangere",
        "state": "Karnataka",
        "farm_size": 2.0,
        "farm_size_unit": "acres",
    }
    resp = await client.post("/api/market/insights", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "current_price" in data
    assert "farm_analysis" in data
    assert data["farm_analysis"]["farm_size_acres"] == 2.0


# ─── RAG Pipeline ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rag_query(client):
    payload = {"query": "How to manage ragi crop in Karnataka?", "top_k": 3}
    resp = await client.post("/api/rag/query", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "answer" in data


# ─── Integrations / Agent Status ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_integrations_status(client):
    resp = await client.get("/api/integrations/status")
    assert resp.status_code == 200
    data = resp.json()
    assert "integrations" in data
    assert len(data["integrations"]) >= 4


@pytest.mark.asyncio
async def test_agents_status(client):
    resp = await client.get("/api/agents/status")
    assert resp.status_code == 200
    data = resp.json()
    assert "agents" in data
    assert len(data["agents"]) == 5


@pytest.mark.asyncio
async def test_knowledge_sources(client):
    resp = await client.get("/api/knowledge/sources")
    assert resp.status_code == 200
    data = resp.json()
    assert "sources" in data


@pytest.mark.asyncio
async def test_history_empty(client):
    resp = await client.get("/api/history")
    assert resp.status_code == 200
    data = resp.json()
    assert "history" in data
