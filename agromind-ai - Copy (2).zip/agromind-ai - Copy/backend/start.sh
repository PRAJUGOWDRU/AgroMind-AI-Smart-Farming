#!/bin/bash
# AgroMind AI — Backend Quick Start (Linux/Mac)

echo ""
echo "========================================"
echo " AgroMind AI Backend Startup"
echo "========================================"
echo ""

# Create venv if not exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate venv
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt --quiet

# Copy .env if not exists
if [ ! -f ".env" ]; then
    echo "Copying .env.example to .env ..."
    cp .env.example .env
    echo ""
    echo "IMPORTANT: Edit .env to add your IBM Granite credentials!"
    echo "  WATSONX_API_KEY=your_key"
    echo "  WATSONX_PROJECT_ID=your_project_id"
    echo ""
fi

# Start backend
echo ""
echo "Starting AgroMind AI Backend on http://localhost:8000"
echo "API Docs: http://localhost:8000/api/docs"
echo ""
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
