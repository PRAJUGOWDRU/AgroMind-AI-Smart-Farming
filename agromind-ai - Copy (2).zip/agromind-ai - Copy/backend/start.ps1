# AgroMind AI — Backend Startup Script (PowerShell)
# Run from the backend folder:  .\start.ps1

Set-StrictMode -Off
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  AgroMind AI Backend Startup" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# ── Check Python ─────────────────────────────────────────────────────────────
try {
    $pyVersion = python --version 2>&1
    Write-Host "Python found: $pyVersion" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Python not found." -ForegroundColor Red
    Write-Host "Install Python 3.10+ from https://www.python.org/downloads/" -ForegroundColor Yellow
    exit 1
}

# ── Create virtual environment ────────────────────────────────────────────────
if (-not (Test-Path "venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv venv
    if ($LASTEXITCODE -ne 0) { Write-Host "Failed to create venv" -ForegroundColor Red; exit 1 }
}

# ── Activate virtual environment ──────────────────────────────────────────────
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& "venv\Scripts\Activate.ps1"

# ── Install dependencies ──────────────────────────────────────────────────────
Write-Host "Installing dependencies (this may take a few minutes)..." -ForegroundColor Yellow
pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { Write-Host "pip install failed" -ForegroundColor Red; exit 1 }

# ── Create .env if missing ────────────────────────────────────────────────────
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "✅  Created .env from .env.example" -ForegroundColor Green
    Write-Host ""
    Write-Host "⚠️   OPTIONAL: Edit .env to enable IBM Granite AI:" -ForegroundColor Yellow
    Write-Host "      WATSONX_API_KEY=your_ibm_cloud_api_key" -ForegroundColor Cyan
    Write-Host "      WATSONX_PROJECT_ID=your_watsonx_project_id" -ForegroundColor Cyan
    Write-Host "    Without these, the app runs in DEMO MODE (fully functional)." -ForegroundColor Gray
    Write-Host ""
}

# ── Start backend ─────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Starting AgroMind AI Backend..." -ForegroundColor Green
Write-Host "  API Base : http://localhost:8000" -ForegroundColor Cyan
Write-Host "  API Docs : http://localhost:8000/api/docs" -ForegroundColor Cyan
Write-Host "  Health   : http://localhost:8000/api/health" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop." -ForegroundColor Gray
Write-Host ""

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
