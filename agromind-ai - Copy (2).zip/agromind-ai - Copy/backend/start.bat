@echo off
REM AgroMind AI — Backend Quick Start (Windows CMD)

echo.
echo ========================================
echo  AgroMind AI Backend Startup
echo ========================================
echo.

REM Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python not found. Please install Python 3.10+ from https://python.org
    pause
    exit /b 1
)

REM Create venv if not exists
if not exist "venv\" (
    echo Creating virtual environment...
    python -m venv venv
    if %errorlevel% neq 0 ( echo Failed to create venv & pause & exit /b 1 )
)

REM Activate venv
call venv\Scripts\activate.bat

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt
if %errorlevel% neq 0 ( echo pip install failed & pause & exit /b 1 )

REM Copy .env if not exists
if not exist ".env" (
    copy .env.example .env
    echo.
    echo IMPORTANT: Edit .env to add your IBM Granite credentials!
    echo   WATSONX_API_KEY=your_key
    echo   WATSONX_PROJECT_ID=your_project_id
    echo.
)

REM Start backend
echo.
echo Starting AgroMind AI Backend ...
echo   API:  http://localhost:8000
echo   Docs: http://localhost:8000/api/docs
echo.
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
