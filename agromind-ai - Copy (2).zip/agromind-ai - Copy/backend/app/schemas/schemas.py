"""
AgroMind AI — Pydantic Schemas for API request/response validation
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime


# ─── Farmer Profile ──────────────────────────────────────────────────────────

class FarmerProfileBase(BaseModel):
    name: Optional[str] = None
    state: str = "Karnataka"
    district: str
    village: Optional[str] = None
    farm_size: Optional[float] = None
    farm_size_unit: str = "acres"
    soil_type: Optional[str] = None
    water_source: Optional[str] = None
    irrigation_method: Optional[str] = None
    current_crop: Optional[str] = None
    crop_stage: Optional[str] = None
    sowing_date: Optional[str] = None
    season: Optional[str] = None
    budget: Optional[float] = None
    farming_preference: str = "conventional"
    preferred_language: str = "en"
    soil_ph: Optional[float] = Field(None, ge=0, le=14)
    soil_nitrogen: Optional[float] = Field(None, ge=0)
    soil_phosphorus: Optional[float] = Field(None, ge=0)
    soil_potassium: Optional[float] = Field(None, ge=0)
    soil_ec: Optional[float] = Field(None, ge=0)


class FarmerProfileCreate(FarmerProfileBase):
    farmer_id: str


class FarmerProfileUpdate(FarmerProfileBase):
    pass


class FarmerProfileResponse(FarmerProfileBase):
    farmer_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ─── Chat / Advisory ─────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=2000)
    farmer_id: Optional[str] = None
    language: str = "en"
    include_images: bool = False


class AgentResult(BaseModel):
    agent_name: str
    status: str  # success | error | skipped | demo
    task: str
    result: Dict[str, Any]
    sources: List[Dict[str, Any]] = []
    execution_time_ms: Optional[int] = None


class ChatResponse(BaseModel):
    query: str
    answer: str
    agents_used: List[AgentResult]
    rag_sources: List[Dict[str, Any]] = []
    demo_mode: bool
    model_used: str
    timestamp: datetime


# ─── Crop Advisory ───────────────────────────────────────────────────────────

class CropAdvisoryRequest(BaseModel):
    farmer_id: Optional[str] = None
    state: str = "Karnataka"
    district: str
    season: Optional[str] = None
    soil_type: Optional[str] = None
    water_availability: Optional[str] = None
    budget: Optional[float] = None
    farming_preference: str = "conventional"
    query: Optional[str] = None


class CropAdvisoryResponse(BaseModel):
    recommended_crops: List[Dict[str, Any]]
    nutrient_advice: Dict[str, Any]
    planting_calendar: Dict[str, Any]
    sustainable_practices: List[str]
    reasoning: str
    sources: List[Dict[str, Any]] = []
    demo_mode: bool


# ─── Irrigation Advisory ─────────────────────────────────────────────────────

class IrrigationRequest(BaseModel):
    farmer_id: Optional[str] = None
    location: str
    crop: Optional[str] = None
    crop_stage: Optional[str] = None
    soil_type: Optional[str] = None
    irrigation_method: Optional[str] = None


class IrrigationResponse(BaseModel):
    weather_summary: Dict[str, Any]
    irrigation_recommendation: str
    next_irrigation: Optional[str] = None
    water_saving_tips: List[str]
    weather_warnings: List[str]
    demo_mode: bool


# ─── Pest & Disease Detection ─────────────────────────────────────────────────

class DetectionResponse(BaseModel):
    detected_issue: str
    confidence: Optional[str] = None
    symptoms: List[str]
    severity: str
    ipm_recommendations: List[str]
    chemical_options: List[str]
    consult_expert: bool
    disclaimer: str
    demo_mode: bool


# ─── Market Insights ─────────────────────────────────────────────────────────

class MarketRequest(BaseModel):
    crop: str
    district: str
    state: str = "Karnataka"
    farm_size: Optional[float] = None
    farm_size_unit: str = "acres"
    expected_yield_per_acre: Optional[float] = None
    cultivation_cost: Optional[float] = None


class MarketResponse(BaseModel):
    crop: str
    current_price: Optional[float] = None
    price_unit: str = "INR/quintal"
    market_name: Optional[str] = None
    price_trend: Optional[str] = None
    cultivation_cost_estimate: float
    gross_revenue_estimate: float
    net_return_estimate: float
    cost_breakdown: Dict[str, Any]
    marketing_options: List[str]
    disclaimer: str
    demo_mode: bool


# ─── RAG ─────────────────────────────────────────────────────────────────────

class RAGQueryRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=1000)
    crop: Optional[str] = None
    state: Optional[str] = None
    top_k: int = Field(default=5, ge=1, le=20)


class RAGQueryResponse(BaseModel):
    query: str
    answer: str
    sources: List[Dict[str, Any]]
    demo_mode: bool


# ─── Knowledge Base ──────────────────────────────────────────────────────────

class KnowledgeSourceResponse(BaseModel):
    id: int
    title: str
    source_type: str
    organization: Optional[str]
    crop: Optional[str]
    state: Optional[str]
    language: str
    chunk_count: int
    indexed: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ─── Agent Status ────────────────────────────────────────────────────────────

class AgentStatusResponse(BaseModel):
    agents: List[Dict[str, Any]]
    orchestrator_status: str
    last_run: Optional[datetime] = None


# ─── Integration Status ──────────────────────────────────────────────────────

class IntegrationStatus(BaseModel):
    name: str
    configured: bool
    status: str  # connected | demo | error | not_configured
    last_check: Optional[datetime] = None
    message: Optional[str] = None


class IntegrationsStatusResponse(BaseModel):
    integrations: List[IntegrationStatus]
    overall_demo_mode: bool
