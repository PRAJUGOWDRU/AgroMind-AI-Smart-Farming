"""
AgroMind AI — Health Check Endpoint
"""
from fastapi import APIRouter
from datetime import datetime
from app.config import settings
from app.services.granite_service import granite_service
from app.rag.pipeline import rag_pipeline

router = APIRouter()


@router.get("/health")
async def health_check():
    rag_status = rag_pipeline.get_status()
    return {
        "status": "ok",
        "app": "AgroMind AI",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "demo_mode": settings.demo_mode or not settings.is_watsonx_configured,
        "services": {
            "database": "ok",
            "ibm_granite": granite_service.get_status()["status"],
            "rag_pipeline": rag_status["status"],
            "weather_api": "configured" if settings.is_weather_configured else "demo",
            "market_api": "configured" if settings.is_market_configured else "demo",
        },
    }
