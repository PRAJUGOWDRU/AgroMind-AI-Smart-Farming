"""
AgroMind AI — Advisory and Chat API
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
from datetime import datetime

from app.database.connection import get_db
from app.models.db_models import FarmerProfile, AdvisoryHistory
from app.schemas.schemas import (
    ChatRequest, ChatResponse, CropAdvisoryRequest, CropAdvisoryResponse,
    IrrigationRequest, IrrigationResponse, MarketRequest, MarketResponse,
    DetectionResponse
)
from app.agents.orchestrator import orchestrator
from app.agents.crop_advisory_agent import crop_advisory_agent
from app.agents.weather_irrigation_agent import weather_irrigation_agent
from app.agents.pest_disease_agent import pest_disease_agent
from app.agents.market_insights_agent import market_insights_agent
from app.config import settings

router = APIRouter()

MAX_IMAGE_SIZE = settings.max_upload_size_mb * 1024 * 1024
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/jpg", "image/png", "image/webp"}


async def _get_profile_dict(farmer_id: Optional[str], db: AsyncSession) -> Optional[dict]:
    """Helper to retrieve farmer profile as dict."""
    if not farmer_id:
        return None
    result = await db.execute(
        select(FarmerProfile).where(FarmerProfile.farmer_id == farmer_id)
    )
    profile = result.scalar_one_or_none()
    if not profile:
        return None
    return {
        col.name: getattr(profile, col.name)
        for col in FarmerProfile.__table__.columns
    }


@router.post("/chat")
async def chat(request: ChatRequest, db: AsyncSession = Depends(get_db)):
    """Main chat endpoint — routes to orchestrator."""
    profile = await _get_profile_dict(request.farmer_id, db)

    result = await orchestrator.process_query(
        query=request.query,
        farmer_profile=profile,
        language=request.language,
    )

    # Save to history
    if request.farmer_id:
        history = AdvisoryHistory(
            farmer_id=request.farmer_id,
            query=request.query,
            response=result["answer"],
            agents_used=[a["agent_name"] for a in result.get("agents_used", [])],
            rag_sources=[{"title": s.get("title")} for s in result.get("rag_sources", [])],
            demo_mode=result.get("demo_mode", True),
        )
        db.add(history)
        await db.commit()

    return {
        "query": result["query"],
        "answer": result["answer"],
        "agents_used": result.get("agents_used", []),
        "rag_sources": result.get("rag_sources", []),
        "demo_mode": result.get("demo_mode", True),
        "model_used": result.get("model_used", "DEMO_MODE"),
        "timestamp": datetime.utcnow().isoformat(),
    }


@router.post("/advisory/crop")
async def crop_advisory(request: CropAdvisoryRequest, db: AsyncSession = Depends(get_db)):
    """Dedicated crop advisory endpoint."""
    profile = await _get_profile_dict(request.farmer_id, db)
    if not profile:
        profile = {
            "state": request.state,
            "district": request.district,
            "season": request.season,
            "soil_type": request.soil_type,
            "water_source": request.water_availability,
            "budget": request.budget,
            "farming_preference": request.farming_preference,
        }

    result = await crop_advisory_agent.run(
        farmer_profile=profile,
        query=request.query or "Recommend suitable crops",
    )
    return result


@router.post("/advisory/irrigation")
async def irrigation_advisory(request: IrrigationRequest, db: AsyncSession = Depends(get_db)):
    """Dedicated irrigation advisory endpoint."""
    profile = await _get_profile_dict(request.farmer_id, db)
    if not profile:
        profile = {
            "district": request.location,
            "state": "Karnataka",
            "current_crop": request.crop,
            "crop_stage": request.crop_stage,
            "soil_type": request.soil_type,
            "irrigation_method": request.irrigation_method,
        }

    result = await weather_irrigation_agent.run(
        farmer_profile=profile,
        query=f"Irrigation advice for {request.crop or 'my crop'} at {request.location}",
    )
    return result


@router.post("/detection/analyze")
async def detect_disease(
    farmer_id: Optional[str] = Form(None),
    query: str = Form(default="Analyze this crop image"),
    image: Optional[UploadFile] = File(None),
    db: AsyncSession = Depends(get_db),
):
    """Crop image analysis for pest and disease detection."""
    image_data = None
    image_filename = None

    if image:
        # Validate content type
        if image.content_type not in ALLOWED_IMAGE_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid file type: {image.content_type}. Allowed: JPG, PNG, WebP"
            )
        # Read and validate size
        image_data = await image.read()
        if len(image_data) > MAX_IMAGE_SIZE:
            raise HTTPException(
                status_code=413,
                detail=f"Image too large. Maximum size: {settings.max_upload_size_mb}MB"
            )
        image_filename = image.filename

    profile = await _get_profile_dict(farmer_id, db)

    result = await pest_disease_agent.run(
        farmer_profile=profile,
        query=query,
        image_data=image_data,
        image_filename=image_filename,
    )
    return result


@router.post("/market/insights")
async def market_insights(request: MarketRequest, db: AsyncSession = Depends(get_db)):
    """Market price and profitability analysis."""
    profile = {
        "current_crop": request.crop,
        "district": request.district,
        "state": request.state,
        "farm_size": request.farm_size or 1.0,
        "farm_size_unit": request.farm_size_unit,
    }

    result = await market_insights_agent.run(
        farmer_profile=profile,
        query=f"Market analysis for {request.crop} in {request.district}",
    )
    return result
