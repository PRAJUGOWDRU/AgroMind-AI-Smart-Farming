"""
AgroMind AI — Integration Status, Agent Status, and History APIs
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from datetime import datetime
from typing import Optional

from app.database.connection import get_db
from app.models.db_models import AdvisoryHistory
from app.config import settings
from app.services.granite_service import granite_service
from app.rag.pipeline import rag_pipeline

router = APIRouter()


@router.get("/integrations/status")
async def integrations_status():
    """Return status of all external integrations."""
    granite_st = granite_service.get_status()
    rag_st = rag_pipeline.get_status()

    integrations = [
        {
            "name": "IBM Granite (watsonx.ai)",
            "configured": settings.is_watsonx_configured,
            "status": granite_st["status"],
            "message": granite_st["message"],
            "demo_mode": granite_st["demo_mode"],
            "model": granite_st["model"],
        },
        {
            "name": "RAG Pipeline (ChromaDB)",
            "configured": True,
            "status": rag_st["status"],
            "message": f"{rag_st.get('document_count', 0)} documents indexed",
            "demo_mode": rag_st["status"] != "ready",
        },
        {
            "name": "Weather API (OpenWeatherMap)",
            "configured": settings.is_weather_configured,
            "status": "configured" if settings.is_weather_configured else "demo",
            "message": "Connected" if settings.is_weather_configured else "Using demo weather data",
            "demo_mode": not settings.is_weather_configured,
        },
        {
            "name": "Market Data (AGMARKNET)",
            "configured": settings.is_market_configured,
            "status": "configured" if settings.is_market_configured else "demo",
            "message": "Connected" if settings.is_market_configured else "Using Karnataka APMC demo prices",
            "demo_mode": not settings.is_market_configured,
        },
    ]

    return {
        "integrations": integrations,
        "overall_demo_mode": not settings.is_watsonx_configured,
        "last_check": datetime.utcnow().isoformat(),
    }


@router.post("/integrations/test-granite")
async def test_granite_connection():
    """Test IBM Granite connection."""
    result = await granite_service.test_connection()
    return result


@router.get("/agents/status")
async def agents_status():
    """Return status of all AI agents."""
    return {
        "agents": [
            {
                "name": "Crop Advisory Agent",
                "description": "Recommends crops, varieties, nutrients, and planting practices",
                "status": "ready",
                "capabilities": ["crop_selection", "nutrient_advice", "planting_calendar", "sustainable_practices"],
            },
            {
                "name": "Weather & Irrigation Agent",
                "description": "Analyzes weather forecasts and recommends irrigation scheduling",
                "status": "ready",
                "capabilities": ["weather_retrieval", "irrigation_timing", "water_saving", "weather_alerts"],
                "weather_api": "configured" if settings.is_weather_configured else "demo",
            },
            {
                "name": "Pest & Disease Detection Agent",
                "description": "Analyzes crop images and describes for pest/disease identification",
                "status": "ready",
                "capabilities": ["symptom_analysis", "ipm_recommendations", "chemical_guidance"],
                "note": "IBM Granite text model used for reasoning. Vision model integration available via adapter.",
            },
            {
                "name": "Market Insights Agent",
                "description": "Provides market prices and profitability estimates",
                "status": "ready",
                "capabilities": ["price_lookup", "profitability_analysis", "marketing_options"],
                "market_api": "configured" if settings.is_market_configured else "demo",
            },
            {
                "name": "Agent Orchestrator",
                "description": "Routes queries to appropriate agents and synthesizes unified advisory",
                "status": "ready",
                "routing": "intelligent_intent_classification",
            },
        ],
        "orchestrator_status": "ready",
        "ibm_granite_status": granite_service.get_status()["status"],
    }


@router.get("/history")
async def get_history(
    farmer_id: Optional[str] = None,
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
):
    """Retrieve advisory history."""
    query = select(AdvisoryHistory).order_by(desc(AdvisoryHistory.created_at)).limit(limit)
    if farmer_id:
        query = query.where(AdvisoryHistory.farmer_id == farmer_id)

    result = await db.execute(query)
    items = result.scalars().all()

    return {
        "history": [
            {
                "id": item.id,
                "farmer_id": item.farmer_id,
                "query": item.query[:200],
                "response_preview": item.response[:300] + "..." if len(item.response) > 300 else item.response,
                "agents_used": item.agents_used,
                "demo_mode": item.demo_mode,
                "created_at": item.created_at.isoformat(),
            }
            for item in items
        ],
        "count": len(items),
    }
