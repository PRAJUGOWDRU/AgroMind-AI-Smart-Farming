"""
AgroMind AI — Farmer Profile API
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database.connection import get_db
from app.models.db_models import FarmerProfile
from app.schemas.schemas import FarmerProfileCreate, FarmerProfileUpdate, FarmerProfileResponse
from datetime import datetime
import uuid

router = APIRouter()


def generate_farmer_id() -> str:
    return f"farmer_{uuid.uuid4().hex[:10]}"


@router.get("/profile/{farmer_id}", response_model=FarmerProfileResponse)
async def get_farmer_profile(farmer_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(FarmerProfile).where(FarmerProfile.farmer_id == farmer_id)
    )
    profile = result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="Farmer profile not found")
    return profile


@router.post("/profile", response_model=FarmerProfileResponse)
async def create_farmer_profile(data: FarmerProfileCreate, db: AsyncSession = Depends(get_db)):
    # Check if farmer_id already exists
    existing = await db.execute(
        select(FarmerProfile).where(FarmerProfile.farmer_id == data.farmer_id)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Farmer ID already exists. Use PUT to update.")

    profile = FarmerProfile(**data.model_dump())
    db.add(profile)
    await db.commit()
    await db.refresh(profile)
    return profile


@router.put("/profile/{farmer_id}", response_model=FarmerProfileResponse)
async def update_farmer_profile(
    farmer_id: str, data: FarmerProfileUpdate, db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(FarmerProfile).where(FarmerProfile.farmer_id == farmer_id)
    )
    profile = result.scalar_one_or_none()

    if not profile:
        # Create if not exists
        profile = FarmerProfile(farmer_id=farmer_id, **data.model_dump())
        db.add(profile)
    else:
        for key, value in data.model_dump(exclude_unset=True).items():
            setattr(profile, key, value)
        profile.updated_at = datetime.utcnow()

    await db.commit()
    await db.refresh(profile)
    return profile


@router.delete("/profile/{farmer_id}")
async def delete_farmer_profile(farmer_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(FarmerProfile).where(FarmerProfile.farmer_id == farmer_id)
    )
    profile = result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="Farmer profile not found")

    await db.delete(profile)
    await db.commit()
    return {"message": "Profile deleted", "farmer_id": farmer_id}


@router.get("/profile")
async def list_farmer_profiles(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(FarmerProfile))
    profiles = result.scalars().all()
    return {"profiles": [p.farmer_id for p in profiles], "count": len(profiles)}
