"""
AgroMind AI — RAG and Knowledge Base API
"""
import os
import uuid
import structlog
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
from datetime import datetime

from app.database.connection import get_db
from app.models.db_models import KnowledgeSource
from app.schemas.schemas import RAGQueryRequest, RAGQueryResponse, KnowledgeSourceResponse
from app.rag.pipeline import rag_pipeline
from app.config import settings

router = APIRouter()
logger = structlog.get_logger()

ALLOWED_DOCUMENT_TYPES = {
    "application/pdf", "text/plain", "text/markdown",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}


@router.post("/rag/query")
async def rag_query(request: RAGQueryRequest):
    """Query the RAG knowledge base and get a Granite-powered answer."""
    result = await rag_pipeline.query_with_rag(
        query=request.query,
        top_k=request.top_k,
        crop=request.crop,
        state=request.state,
    )
    return result


@router.post("/knowledge/upload")
async def upload_knowledge_document(
    title: str = Form(...),
    organization: Optional[str] = Form(None),
    crop: Optional[str] = Form(None),
    state: Optional[str] = Form(None),
    source_url: Optional[str] = Form(None),
    language: str = Form(default="en"),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """Upload and index a knowledge base document."""
    # Validate file type
    if file.content_type not in ALLOWED_DOCUMENT_TYPES and not file.filename.endswith((".txt", ".md", ".pdf")):
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.content_type}")

    # Read file
    content = await file.read()
    if len(content) > 20 * 1024 * 1024:  # 20MB max for documents
        raise HTTPException(status_code=413, detail="Document too large. Maximum 20MB.")

    # Save file
    os.makedirs(settings.upload_dir, exist_ok=True)
    file_id = uuid.uuid4().hex[:8]
    safe_name = f"{file_id}_{file.filename.replace(' ', '_')}"
    file_path = os.path.join(settings.upload_dir, safe_name)

    with open(file_path, "wb") as f:
        f.write(content)

    # Extract text
    try:
        text = _extract_text(content, file.filename, file.content_type)
    except Exception as e:
        logger.error("Text extraction failed", error=str(e))
        text = content.decode("utf-8", errors="ignore")

    # Split into chunks
    chunks = _split_text(text, chunk_size=800, overlap=100)

    # Index chunks in ChromaDB
    chunk_count = 0
    for i, chunk in enumerate(chunks):
        try:
            await rag_pipeline.add_document(
                text=chunk,
                title=title,
                metadata={
                    "source": title,
                    "organization": organization,
                    "crop": crop,
                    "state": state,
                    "language": language,
                    "source_url": source_url,
                    "type": "uploaded_document",
                    "chunk_index": i,
                },
                doc_id=f"{file_id}_chunk_{i}",
            )
            chunk_count += 1
        except Exception as e:
            logger.warning("Chunk indexing failed", chunk=i, error=str(e))

    # Save metadata to DB
    source = KnowledgeSource(
        title=title,
        source_type=file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "txt",
        source_url=source_url,
        organization=organization,
        crop=crop,
        state=state,
        language=language,
        chunk_count=chunk_count,
        indexed=chunk_count > 0,
        file_path=file_path,
    )
    db.add(source)
    await db.commit()
    await db.refresh(source)

    return {
        "message": "Document uploaded and indexed successfully",
        "title": title,
        "chunks_indexed": chunk_count,
        "source_id": source.id,
    }


@router.get("/knowledge/sources")
async def list_knowledge_sources(db: AsyncSession = Depends(get_db)):
    """List all indexed knowledge sources."""
    result = await db.execute(select(KnowledgeSource).order_by(KnowledgeSource.created_at.desc()))
    sources = result.scalars().all()
    rag_status = rag_pipeline.get_status()
    return {
        "sources": [
            {
                "id": s.id,
                "title": s.title,
                "source_type": s.source_type,
                "organization": s.organization,
                "crop": s.crop,
                "state": s.state,
                "language": s.language,
                "chunk_count": s.chunk_count,
                "indexed": s.indexed,
                "created_at": s.created_at.isoformat(),
            }
            for s in sources
        ],
        "rag_status": rag_status,
        "sample_corpus_docs": 6,
    }


def _extract_text(content: bytes, filename: str, content_type: str) -> str:
    """Extract text from uploaded document."""
    if filename.endswith(".pdf") or content_type == "application/pdf":
        try:
            import PyPDF2
            import io
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception as e:
            logger.warning("PDF extraction failed", error=str(e))
            return content.decode("utf-8", errors="ignore")
    elif filename.endswith(".docx"):
        try:
            import docx
            import io
            doc = docx.Document(io.BytesIO(content))
            return "\n".join(para.text for para in doc.paragraphs)
        except Exception as e:
            logger.warning("DOCX extraction failed", error=str(e))
            return content.decode("utf-8", errors="ignore")
    else:
        return content.decode("utf-8", errors="ignore")


def _split_text(text: str, chunk_size: int = 800, overlap: int = 100) -> list:
    """Split text into overlapping chunks."""
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size - overlap):
        chunk = " ".join(words[i:i + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
    return chunks if chunks else [text[:chunk_size]]
