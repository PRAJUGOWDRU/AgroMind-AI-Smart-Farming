"""
AgroMind AI — FastAPI Main Application Entry Point
"""
import os
import structlog
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database.connection import init_db
from app.rag.pipeline import rag_pipeline
from app.services.granite_service import granite_service

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

logger = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    logger.info("AgroMind AI starting up...")

    # Initialize database
    await init_db()

    # Create upload directories
    os.makedirs(settings.upload_dir, exist_ok=True)
    os.makedirs(settings.chroma_db_path, exist_ok=True)

    # Initialize IBM Granite (lazy — will log if not configured)
    granite_service._init_client()

    # Ingest sample corpus into RAG
    count = await rag_pipeline.ingest_sample_corpus()
    logger.info("RAG corpus ready", documents=count)

    logger.info(
        "AgroMind AI ready",
        demo_mode=not settings.is_watsonx_configured,
        granite=granite_service.get_status()["status"],
    )

    yield

    logger.info("AgroMind AI shutting down...")


app = FastAPI(
    title="AgroMind AI",
    description="Intelligent Smart Farming Agent — IBM Granite powered",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Global Exception Handler ─────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception", path=request.url.path, error=str(exc))
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error": str(exc)},
    )


# ─── Include Routers ─────────────────────────────────────────────────────────

from app.api.health import router as health_router
from app.api.farmer import router as farmer_router
from app.api.advisory import router as advisory_router
from app.api.knowledge import router as knowledge_router
from app.api.integrations import router as integrations_router

app.include_router(health_router, prefix="/api", tags=["Health"])
app.include_router(farmer_router, prefix="/api/farmer", tags=["Farmer Profile"])
app.include_router(advisory_router, prefix="/api", tags=["Advisory & Chat"])
app.include_router(knowledge_router, prefix="/api", tags=["Knowledge Base"])
app.include_router(integrations_router, prefix="/api", tags=["Status & History"])


@app.get("/")
async def root():
    return {
        "app": "AgroMind AI",
        "description": "Intelligent Smart Farming Agent",
        "version": "1.0.0",
        "docs": "/api/docs",
        "health": "/api/health",
        "demo_mode": not settings.is_watsonx_configured,
    }
