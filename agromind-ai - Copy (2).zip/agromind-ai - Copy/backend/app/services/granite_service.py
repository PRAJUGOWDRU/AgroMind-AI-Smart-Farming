"""
AgroMind AI — IBM watsonx.ai / Granite Service Adapter

This module handles all IBM Granite model interactions.
When WATSONX_API_KEY and WATSONX_PROJECT_ID are not configured,
the service transparently falls back to DEMO MODE with realistic
sample responses — clearly labeled as demo data.
"""
import time
import structlog
from typing import Optional, Dict, Any, List
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from app.config import settings

logger = structlog.get_logger()


class WatsonxGraniteService:
    """IBM watsonx.ai Granite language model adapter."""

    def __init__(self):
        self.model_id = settings.watsonx_model_id
        self.project_id = settings.watsonx_project_id
        self.url = settings.watsonx_url
        self._client = None
        self._initialized = False

    def _init_client(self):
        """Lazily initialize the IBM watsonx.ai client."""
        if not settings.is_watsonx_configured:
            logger.warning("watsonx.ai not configured — running in DEMO MODE")
            return False
        try:
            from ibm_watsonx_ai import APIClient, Credentials
            from ibm_watsonx_ai.foundation_models import ModelInference
            from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams

            credentials = Credentials(
                url=self.url,
                api_key=settings.watsonx_api_key,
            )
            self._client = ModelInference(
                model_id=self.model_id,
                credentials=credentials,
                project_id=self.project_id,
                params={
                    GenParams.MAX_NEW_TOKENS: 1024,
                    GenParams.TEMPERATURE: 0.3,
                    GenParams.TOP_P: 0.9,
                    GenParams.REPETITION_PENALTY: 1.1,
                },
            )
            self._initialized = True
            logger.info("IBM watsonx.ai client initialized", model=self.model_id)
            return True
        except ImportError:
            logger.error("ibm-watsonx-ai package not installed")
            return False
        except Exception as e:
            logger.error("Failed to initialize watsonx.ai client", error=str(e))
            return False

    @property
    def is_live(self) -> bool:
        return self._initialized

    def get_status(self) -> Dict[str, Any]:
        """Return connection status for the settings page."""
        if not settings.is_watsonx_configured:
            return {
                "configured": False,
                "status": "not_configured",
                "message": "WATSONX_API_KEY and WATSONX_PROJECT_ID not set. Running in DEMO MODE.",
                "model": self.model_id,
                "demo_mode": True,
            }
        if self._initialized:
            return {
                "configured": True,
                "status": "connected",
                "message": f"Connected to IBM watsonx.ai — model: {self.model_id}",
                "model": self.model_id,
                "demo_mode": False,
            }
        return {
            "configured": True,
            "status": "error",
            "message": "Credentials configured but client failed to initialize.",
            "model": self.model_id,
            "demo_mode": True,
        }

    async def test_connection(self) -> Dict[str, Any]:
        """Test IBM Granite connectivity with a minimal prompt."""
        if not settings.is_watsonx_configured:
            return {"success": False, "demo_mode": True, "message": "Not configured — demo mode active."}
        if not self._initialized:
            self._init_client()
        try:
            result = await self.generate("Say hello in one sentence.", max_tokens=50)
            return {
                "success": True,
                "demo_mode": False,
                "message": "IBM Granite connection successful.",
                "sample_response": result["text"],
            }
        except Exception as e:
            return {"success": False, "demo_mode": True, "message": str(e)}

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=False,
    )
    async def generate(
        self,
        prompt: str,
        max_tokens: int = 1024,
        temperature: float = 0.3,
        system_prompt: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate text using IBM Granite. Falls back to demo if not configured."""
        if not settings.is_watsonx_configured:
            return self._demo_response(prompt)

        if not self._initialized:
            ok = self._init_client()
            if not ok:
                return self._demo_response(prompt)

        start = time.time()
        full_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt

        try:
            response = self._client.generate_text(prompt=full_prompt)
            elapsed = int((time.time() - start) * 1000)
            logger.info("Granite inference complete", ms=elapsed, tokens=len(response.split()))
            return {
                "text": response,
                "model": self.model_id,
                "demo_mode": False,
                "elapsed_ms": elapsed,
            }
        except Exception as e:
            logger.error("Granite inference failed", error=str(e))
            raise

    def _demo_response(self, prompt: str) -> Dict[str, Any]:
        """
        Return a realistic demo response when IBM Granite is not configured.
        These responses are clearly labeled as DEMO DATA.
        """
        prompt_lower = prompt.lower()

        if any(k in prompt_lower for k in ["yellow", "leaves", "disease", "pest", "symptom"]):
            text = (
                "[DEMO MODE — IBM Granite not configured]\n\n"
                "Based on the symptoms described (yellowing leaves), this could indicate:\n"
                "1. **Nitrogen Deficiency** — Most common cause of yellowing in older leaves. "
                "Apply urea (46% N) at 25-30 kg/acre as a top dressing.\n"
                "2. **Iron Chlorosis** — Yellowing between leaf veins on young leaves. "
                "Apply ferrous sulphate (0.5%) as a foliar spray.\n"
                "3. **Leaf Blight (Helminthosporium)** — Yellow-brown lesions with dark margins. "
                "Apply Mancozeb 75 WP @ 2 g/L water.\n\n"
                "**Recommended Action:** Since rainfall is expected this week, delay foliar sprays "
                "until after rain. Focus on nitrogen top-dressing now. Monitor closely and consult "
                "your nearest KVK if symptoms worsen.\n\n"
                "*Note: This is a demo response. Connect IBM Granite via watsonx.ai for AI-powered analysis.*"
            )
        elif any(k in prompt_lower for k in ["crop", "recommend", "suitable", "grow"]):
            text = (
                "[DEMO MODE — IBM Granite not configured]\n\n"
                "**Recommended Crops for Karnataka (Kharif Season):**\n\n"
                "1. **Ragi (Finger Millet)** — Highly drought-tolerant, ideal for red laterite soils. "
                "Yield: 8-12 quintals/acre. Market price: ₹1,800-2,200/quintal.\n"
                "2. **Groundnut** — Suitable for sandy loam soils. Yield: 6-8 quintals/acre. "
                "Good market demand. Requires moderate irrigation.\n"
                "3. **Soybean** — Nitrogen-fixing legume, improves soil health. "
                "Yield: 8-10 quintals/acre. Suitable for black cotton soil.\n\n"
                "**For budget-conscious farmers:** Ragi is recommended — "
                "low input cost (₹8,000-10,000/acre) and government MSP support.\n\n"
                "*Note: This is a demo response. Connect IBM Granite via watsonx.ai for personalized AI advice.*"
            )
        elif any(k in prompt_lower for k in ["irrigation", "water", "rain", "forecast"]):
            text = (
                "[DEMO MODE — IBM Granite not configured]\n\n"
                "**Irrigation Advisory:**\n\n"
                "With rainfall expected this week (40-60% probability, 15-25mm forecast), "
                "it is advisable to:\n"
                "1. **Skip scheduled irrigation** for the next 3-4 days.\n"
                "2. **Check drainage channels** — ensure excess water can drain from fields.\n"
                "3. **After rain:** Wait 2-3 days before resuming drip/sprinkler irrigation "
                "to allow soil moisture to normalize.\n\n"
                "**Water-saving tip:** Use tensiometer or feel-test method to check soil moisture "
                "before irrigating. This can reduce water use by 30-40%.\n\n"
                "*Note: This is a demo response. Connect IBM Granite via watsonx.ai for weather-based irrigation advice.*"
            )
        elif any(k in prompt_lower for k in ["market", "price", "profit", "cost", "income"]):
            text = (
                "[DEMO MODE — IBM Granite not configured]\n\n"
                "**Market & Profitability Estimate (Karnataka, Kharif 2024):**\n\n"
                "| Crop | Market Price | Yield/Acre | Gross Revenue | Input Cost | Net Profit |\n"
                "|------|-------------|------------|---------------|------------|------------|\n"
                "| Ragi | ₹2,000/qtl | 10 qtl | ₹20,000 | ₹9,000 | ₹11,000 |\n"
                "| Maize | ₹1,800/qtl | 20 qtl | ₹36,000 | ₹15,000 | ₹21,000 |\n"
                "| Groundnut | ₹5,500/qtl | 8 qtl | ₹44,000 | ₹20,000 | ₹24,000 |\n\n"
                "⚠️ *Prices are indicative estimates based on recent APMC data. "
                "Actual prices vary by mandi and quality.*\n\n"
                "*Note: This is a demo response. Connect IBM Granite via watsonx.ai for real-time market insights.*"
            )
        else:
            text = (
                "[DEMO MODE — IBM Granite not configured]\n\n"
                "Namaskara! I am AgroMind AI, your intelligent farming companion.\n\n"
                "I can help you with:\n"
                "• **Crop selection** based on your soil, season, and budget\n"
                "• **Soil health** and fertilizer recommendations\n"
                "• **Weather-based irrigation** planning\n"
                "• **Pest and disease** identification and management\n"
                "• **Market prices** and profitability analysis\n"
                "• **Government schemes** and agricultural advisories\n\n"
                "Please describe your farming situation or ask a specific question. "
                "For best results, complete your Farm Profile so I can give personalized advice.\n\n"
                "*Note: Currently running in DEMO MODE. Configure IBM watsonx.ai credentials "
                "in Settings for AI-powered responses.*"
            )

        return {
            "text": text,
            "model": "DEMO_MODE",
            "demo_mode": True,
            "elapsed_ms": 50,
        }


# Singleton instance
granite_service = WatsonxGraniteService()
