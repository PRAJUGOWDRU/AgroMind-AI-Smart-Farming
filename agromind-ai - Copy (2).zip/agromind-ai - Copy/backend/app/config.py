"""
AgroMind AI — Application Settings
Loads configuration from environment variables / .env file.
"""
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List
import os


class Settings(BaseSettings):
    # Application
    app_env: str = Field(default="development", env="APP_ENV")
    app_secret_key: str = Field(default="dev-secret-key-change-in-production", env="APP_SECRET_KEY")
    demo_mode: bool = Field(default=True, env="DEMO_MODE")

    # IBM watsonx.ai
    watsonx_api_key: str = Field(default="", env="WATSONX_API_KEY")
    watsonx_project_id: str = Field(default="", env="WATSONX_PROJECT_ID")
    watsonx_url: str = Field(default="https://us-south.ml.cloud.ibm.com", env="WATSONX_URL")
    watsonx_model_id: str = Field(default="ibm/granite-13b-chat-v2", env="WATSONX_MODEL_ID")

    # Database
    database_url: str = Field(default="sqlite+aiosqlite:///./agromind.db", env="DATABASE_URL")

    # Weather API
    openweather_api_key: str = Field(default="", env="OPENWEATHER_API_KEY")
    openweather_base_url: str = Field(default="https://api.openweathermap.org/data/2.5", env="OPENWEATHER_BASE_URL")

    # Market Data
    agmarknet_api_key: str = Field(default="", env="AGMARKNET_API_KEY")
    agmarknet_base_url: str = Field(default="https://api.data.gov.in/resource", env="AGMARKNET_BASE_URL")

    # CORS
    allowed_origins: str = Field(default="http://localhost:5173,http://localhost:3000", env="ALLOWED_ORIGINS")

    # File Upload
    max_upload_size_mb: int = Field(default=10, env="MAX_UPLOAD_SIZE_MB")
    upload_dir: str = Field(default="./uploads", env="UPLOAD_DIR")

    # ChromaDB
    chroma_db_path: str = Field(default="./chroma_db", env="CHROMA_DB_PATH")

    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")

    @property
    def allowed_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",")]

    @property
    def is_watsonx_configured(self) -> bool:
        return bool(self.watsonx_api_key and self.watsonx_project_id)

    @property
    def is_weather_configured(self) -> bool:
        return bool(self.openweather_api_key)

    @property
    def is_market_configured(self) -> bool:
        return bool(self.agmarknet_api_key)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


settings = Settings()
