"""
AgroMind AI — SQLAlchemy Database Models
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class FarmerProfile(Base):
    __tablename__ = "farmer_profiles"

    id = Column(Integer, primary_key=True, index=True)
    farmer_id = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(String(200), nullable=True)
    state = Column(String(100), nullable=False, default="Karnataka")
    district = Column(String(100), nullable=False)
    village = Column(String(200), nullable=True)
    farm_size = Column(Float, nullable=True)
    farm_size_unit = Column(String(20), default="acres")
    soil_type = Column(String(100), nullable=True)
    water_source = Column(String(100), nullable=True)
    irrigation_method = Column(String(100), nullable=True)
    current_crop = Column(String(100), nullable=True)
    crop_stage = Column(String(100), nullable=True)
    sowing_date = Column(String(20), nullable=True)
    season = Column(String(50), nullable=True)
    budget = Column(Float, nullable=True)
    farming_preference = Column(String(50), default="conventional")
    preferred_language = Column(String(20), default="en")
    # Soil test data (optional)
    soil_ph = Column(Float, nullable=True)
    soil_nitrogen = Column(Float, nullable=True)
    soil_phosphorus = Column(Float, nullable=True)
    soil_potassium = Column(Float, nullable=True)
    soil_ec = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    advisories = relationship("AdvisoryHistory", back_populates="farmer")


class AdvisoryHistory(Base):
    __tablename__ = "advisory_history"

    id = Column(Integer, primary_key=True, index=True)
    farmer_id = Column(String(50), ForeignKey("farmer_profiles.farmer_id"), nullable=False)
    query = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    agents_used = Column(JSON, nullable=True)
    rag_sources = Column(JSON, nullable=True)
    demo_mode = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    farmer = relationship("FarmerProfile", back_populates="advisories")


class KnowledgeSource(Base):
    __tablename__ = "knowledge_sources"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(500), nullable=False)
    source_type = Column(String(50), nullable=False)  # pdf, url, txt, md
    source_url = Column(String(1000), nullable=True)
    organization = Column(String(200), nullable=True)
    crop = Column(String(100), nullable=True)
    state = Column(String(100), nullable=True)
    language = Column(String(20), default="en")
    chunk_count = Column(Integer, default=0)
    indexed = Column(Boolean, default=False)
    file_path = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
