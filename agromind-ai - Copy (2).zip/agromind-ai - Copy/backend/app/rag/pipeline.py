"""
AgroMind AI — RAG Pipeline
Handles document ingestion, embedding, storage in ChromaDB,
and retrieval-augmented generation with IBM Granite.
"""
import os
import uuid
import structlog
from typing import List, Dict, Any, Optional
from pathlib import Path
from app.config import settings
from app.services.granite_service import granite_service

logger = structlog.get_logger()

# ─── Lazy imports for heavy dependencies ─────────────────────────────────────

def _get_chroma_client():
    import chromadb
    client = chromadb.PersistentClient(path=settings.chroma_db_path)
    return client

def _get_embedding_function():
    try:
        from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
        return SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")
    except Exception as e:
        logger.warning("SentenceTransformer not available, using default embeddings", error=str(e))
        return None

# ─── Sample Knowledge Corpus ─────────────────────────────────────────────────

SAMPLE_DOCUMENTS = [
    {
        "id": "icar-ragi-karnataka-001",
        "title": "Ragi Cultivation Guide — Karnataka",
        "text": (
            "Ragi (Eleusine coracana), commonly known as Finger Millet, is a major cereal crop "
            "in Karnataka. It is best cultivated during Kharif season (June–September). "
            "Recommended varieties: MR-1, GPU-28, GPU-45, and ML-365. "
            "Soil: Well-drained red laterite soils with pH 5.5–7.5. "
            "Seed rate: 8–10 kg/hectare for line sowing. Spacing: 22.5 cm × 10 cm. "
            "Fertilizer (per hectare): 60 kg N, 30 kg P2O5, 30 kg K2O. "
            "Apply half nitrogen and full phosphorus and potassium at basal. "
            "Remaining nitrogen at 30 days after transplanting. "
            "Irrigation: Requires 350–400 mm water. Drip irrigation can save 30–40% water. "
            "Pest: Shoot fly (Atherigona spp.) — Use carbofuran 3G @ 33 kg/ha. "
            "Disease: Blast (Pyricularia grisea) — Apply Tricyclazole 75 WP @ 0.6 g/L. "
            "Average yield: 20–25 quintals/hectare under irrigated conditions."
        ),
        "metadata": {
            "source": "ICAR — Indian Institute of Millets Research",
            "organization": "ICAR",
            "crop": "ragi",
            "state": "Karnataka",
            "language": "en",
            "source_url": "https://www.millets.res.in/ragi.php",
            "type": "crop_guide",
        },
    },
    {
        "id": "karnataka-doa-kharif-2024",
        "title": "Karnataka Kharif Season Crop Advisory 2024",
        "text": (
            "The Karnataka Department of Agriculture advises farmers for Kharif 2024: "
            "Major crops recommended: Paddy, Maize, Ragi, Soybean, Groundnut, Cotton, Jowar, Bajra. "
            "Paddy (rice): Preferred varieties — BPT-5204, MTU-1010, Sona Masuri. "
            "Suitable districts for paddy: Mandya, Mysuru, Hassan, Shimoga, Dakshina Kannada. "
            "Maize cultivation: Suited for Belgaum, Dharwad, Haveri, Gadag districts. "
            "Varieties: HQPM-1 (quality protein maize), NK-6240. Yield: 40–50 quintals/hectare. "
            "Soil health: Apply 2–3 tonnes farmyard manure (FYM) per acre before sowing. "
            "Use soil test reports from KSDA labs for accurate fertilizer recommendations. "
            "Government schemes: Pradhan Mantri Fasal Bima Yojana (PMFBY) — crop insurance. "
            "PM-Kisan: ₹6,000/year direct benefit transfer. "
            "RKVY: Rashtriya Krishi Vikas Yojana for farm infrastructure grants. "
            "For soil testing: Contact nearest Raitha Samparka Kendra (RSK)."
        ),
        "metadata": {
            "source": "Karnataka Department of Agriculture",
            "organization": "Karnataka Dept. of Agriculture",
            "crop": None,
            "state": "Karnataka",
            "language": "en",
            "source_url": "https://raitamitra.karnataka.gov.in",
            "type": "government_advisory",
        },
    },
    {
        "id": "icar-ipm-cotton-001",
        "title": "Integrated Pest Management in Cotton — ICAR Advisory",
        "text": (
            "Cotton is susceptible to several pests. IPM approach is strongly recommended. "
            "Key pests: Bollworm (Helicoverpa armigera), Whitefly (Bemisia tabaci), "
            "Aphids (Aphis gossypii), Thrips (Thrips tabaci), Spider mites. "
            "Cultural controls: Deep ploughing, crop rotation with cereals, use of Bt cotton varieties. "
            "Mechanical controls: Install pheromone traps (5/acre) for bollworm monitoring. "
            "Yellow sticky traps for whitefly (10/acre). "
            "Biological controls: Release Chrysoperla carnea @ 50,000 eggs/ha at flowering stage. "
            "Trichogramma spp. parasitoids for bollworm eggs. "
            "Chemical controls (only when threshold exceeded): "
            "Bollworm: Spinosad 45 SC @ 0.3 ml/L or Indoxacarb 15.8 EC @ 1 ml/L. "
            "Whitefly: Diafenthiuron 50 WP @ 1 g/L or Spiromesifen 22.9 SC @ 1 ml/L. "
            "Never mix insecticides without expert guidance. Follow label directions strictly. "
            "Pre-harvest interval: Observe recommended waiting periods before harvest."
        ),
        "metadata": {
            "source": "ICAR — Central Institute for Cotton Research",
            "organization": "ICAR",
            "crop": "cotton",
            "state": None,
            "language": "en",
            "source_url": "https://www.cicr.org.in",
            "type": "pest_management",
        },
    },
    {
        "id": "kvk-soil-health-karnataka",
        "title": "Soil Health Management — KVK Karnataka Guidelines",
        "text": (
            "Healthy soil is the foundation of sustainable agriculture. "
            "Karnataka soils are broadly classified as: "
            "Red laterite (north and eastern districts), Black cotton/vertisol (north Karnataka), "
            "Coastal alluvial (Dakshina Kannada, Udupi), Sandy loam (Tumkur, Chitradurga). "
            "Soil pH management: Acidic soils (pH < 6): Apply lime (CaCO3) @ 250–500 kg/acre. "
            "Alkaline soils (pH > 7.5): Apply gypsum @ 200–400 kg/acre. "
            "Organic matter improvement: Apply FYM, vermicompost, or green manure crops "
            "(Dhaincha, Sunhemp) before monsoon. "
            "Micronutrient deficiencies in Karnataka: "
            "Zinc: Apply zinc sulphate @ 10 kg/acre at sowing. "
            "Iron: Apply ferrous sulphate @ 12.5 kg/acre or foliar spray 0.5% solution. "
            "Boron: Apply borax @ 2 kg/acre for groundnut, sunflower. "
            "Soil testing: Recommended every 3 years. Sample collection: "
            "Collect 10–12 samples per acre (0–20 cm depth), mix, and send 500 g to KSDA lab. "
            "Cost: Free at government labs, ₹100–300 at private labs."
        ),
        "metadata": {
            "source": "Krishi Vigyan Kendra (KVK) Karnataka",
            "organization": "KVK Karnataka",
            "crop": None,
            "state": "Karnataka",
            "language": "en",
            "source_url": "https://kvk.icar.gov.in",
            "type": "soil_management",
        },
    },
    {
        "id": "imd-monsoon-advisory-karnataka-2024",
        "title": "IMD Agricultural Weather Advisory — Karnataka 2024 Kharif",
        "text": (
            "India Meteorological Department (IMD) Seasonal Forecast for Karnataka Kharif 2024: "
            "Southwest monsoon onset over Karnataka: 1st–5th June (normal dates). "
            "Seasonal rainfall forecast: Normal to above-normal (104–110% of Long Period Average). "
            "Districts expecting above-normal rainfall: Kodagu, Dakshina Kannada, Hassan, Mysuru. "
            "Districts with normal rainfall: Bangalore Rural, Tumkur, Kolar, Mandya. "
            "Districts with possible below-normal rainfall: Raichur, Bellary, Koppal (northern districts). "
            "Advisory for Kharif sowing: Begin field preparation after 3–4 consecutive rainy days. "
            "Do not sow immediately after first rain — wait for soil moisture to stabilize. "
            "Drought-contingency crops for dry spells: Ragi, Jowar, Bajra (short-duration varieties). "
            "Flood precautions for Kodagu/Dakshina Kannada: Avoid sowing in low-lying areas in July. "
            "Agro-meteorological advisory: SMS alerts available on mKisan portal (mkisan.gov.in). "
            "District-level advisories issued every Tuesday and Friday by ADMA (Agro-meteorology)."
        ),
        "metadata": {
            "source": "India Meteorological Department (IMD)",
            "organization": "IMD",
            "crop": None,
            "state": "Karnataka",
            "language": "en",
            "source_url": "https://imd.gov.in",
            "type": "weather_advisory",
        },
    },
    {
        "id": "agmarknet-price-advisory-karnataka",
        "title": "APMC Market Price Information — Karnataka 2024",
        "text": (
            "Karnataka has 157 Agriculture Produce Market Committees (APMCs). "
            "Key APMC mandis: Yelahanka (Bangalore), Hubli, Davangere, Shimoga, Mysuru, Gulbarga. "
            "Current indicative prices (Kharif 2024): "
            "Paddy (raw): ₹1,940–2,200/quintal. MSP: ₹2,183/quintal (Grade A). "
            "Maize: ₹1,700–2,000/quintal. MSP: ₹1,962/quintal. "
            "Ragi: ₹1,800–2,400/quintal. MSP: ₹3,846/quintal (IIMR recommended). "
            "Groundnut (pods): ₹4,800–6,000/quintal. "
            "Soybean: ₹3,800–4,500/quintal. MSP: ₹4,600/quintal. "
            "Cotton (seed cotton): ₹5,800–7,500/quintal. MSP: ₹7,121/quintal. "
            "Onion: ₹800–2,500/quintal (highly variable). "
            "For live prices: Visit e-NAM portal (enam.gov.in) or AGMARKNET (agmarknet.gov.in). "
            "Sell when prices are above MSP — avoid distress sales at harvest. "
            "Farmer Producer Organizations (FPOs) can negotiate better prices collectively."
        ),
        "metadata": {
            "source": "AGMARKNET / Karnataka APMC",
            "organization": "Karnataka APMC",
            "crop": None,
            "state": "Karnataka",
            "language": "en",
            "source_url": "https://agmarknet.gov.in",
            "type": "market_price",
        },
    },
]


class RAGPipeline:
    """Retrieval-Augmented Generation pipeline using ChromaDB."""

    COLLECTION_NAME = "agromind_knowledge"

    def __init__(self):
        self._collection = None
        self._ready = False

    def _get_collection(self):
        """Lazily initialize ChromaDB collection."""
        if self._collection is not None:
            return self._collection
        try:
            client = _get_chroma_client()
            ef = _get_embedding_function()
            if ef:
                self._collection = client.get_or_create_collection(
                    name=self.COLLECTION_NAME,
                    embedding_function=ef,
                    metadata={"description": "AgroMind AI agricultural knowledge base"},
                )
            else:
                self._collection = client.get_or_create_collection(
                    name=self.COLLECTION_NAME,
                    metadata={"description": "AgroMind AI agricultural knowledge base"},
                )
            self._ready = True
            return self._collection
        except Exception as e:
            logger.error("ChromaDB initialization failed", error=str(e))
            return None

    async def ingest_sample_corpus(self):
        """Ingest the built-in sample knowledge corpus."""
        collection = self._get_collection()
        if collection is None:
            logger.warning("ChromaDB unavailable — skipping corpus ingestion")
            return 0

        try:
            existing = collection.get(ids=[d["id"] for d in SAMPLE_DOCUMENTS])
            existing_ids = set(existing.get("ids", []))
            to_add = [d for d in SAMPLE_DOCUMENTS if d["id"] not in existing_ids]

            if not to_add:
                logger.info("Sample corpus already ingested")
                return len(SAMPLE_DOCUMENTS)

            collection.add(
                ids=[d["id"] for d in to_add],
                documents=[d["text"] for d in to_add],
                metadatas=[d["metadata"] for d in to_add],
            )
            logger.info("Sample corpus ingested", count=len(to_add))
            return len(to_add)
        except Exception as e:
            logger.error("Corpus ingestion failed", error=str(e))
            return 0

    async def add_document(
        self,
        text: str,
        title: str,
        metadata: Dict[str, Any],
        doc_id: Optional[str] = None,
    ) -> str:
        """Add a single document (or chunk) to the vector store."""
        collection = self._get_collection()
        if collection is None:
            raise RuntimeError("ChromaDB not available")

        doc_id = doc_id or str(uuid.uuid4())
        collection.add(
            ids=[doc_id],
            documents=[text],
            metadatas=[{k: v for k, v in metadata.items() if v is not None}],
        )
        return doc_id

    async def retrieve(
        self,
        query: str,
        top_k: int = 5,
        crop: Optional[str] = None,
        state: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve top-k relevant documents for a query."""
        collection = self._get_collection()
        if collection is None:
            return self._demo_results(query)

        try:
            where_filter = {}
            if crop:
                where_filter["crop"] = crop
            if state:
                where_filter["state"] = state

            results = collection.query(
                query_texts=[query],
                n_results=min(top_k, 10),
                where=where_filter if where_filter else None,
                include=["documents", "metadatas", "distances"],
            )

            docs = []
            for i, doc in enumerate(results.get("documents", [[]])[0]):
                meta = results.get("metadatas", [[]])[0][i] if results.get("metadatas") else {}
                dist = results.get("distances", [[]])[0][i] if results.get("distances") else None
                relevance = round(1 - (dist or 0), 3) if dist is not None else None
                docs.append({
                    "text": doc,
                    "title": meta.get("source", "Unknown Source"),
                    "organization": meta.get("organization"),
                    "crop": meta.get("crop"),
                    "state": meta.get("state"),
                    "source_url": meta.get("source_url"),
                    "type": meta.get("type"),
                    "relevance": relevance,
                    "demo": False,
                })
            return docs
        except Exception as e:
            logger.error("RAG retrieval failed", error=str(e))
            return self._demo_results(query)

    async def query_with_rag(
        self,
        query: str,
        top_k: int = 5,
        crop: Optional[str] = None,
        state: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retrieve documents and generate a Granite-powered answer."""
        docs = await self.retrieve(query, top_k=top_k, crop=crop, state=state)

        context = "\n\n---\n\n".join(
            [f"Source: {d['title']}\n{d['text']}" for d in docs[:4]]
        )

        system_prompt = (
            "You are AgroMind AI, an agricultural advisor specializing in Indian farming, "
            "particularly Karnataka. Use the provided context documents to answer the farmer's "
            "question accurately. Cite your sources. If the context does not contain enough "
            "information, say so clearly. Provide practical, actionable advice."
        )

        prompt = (
            f"Context documents:\n{context}\n\n"
            f"Farmer's question: {query}\n\n"
            "Please provide a clear, practical answer with source citations:"
        )

        result = await granite_service.generate(prompt, system_prompt=system_prompt)

        return {
            "query": query,
            "answer": result["text"],
            "sources": docs,
            "demo_mode": result["demo_mode"],
        }

    def _demo_results(self, query: str) -> List[Dict[str, Any]]:
        """Return relevant demo results when ChromaDB is unavailable."""
        query_lower = query.lower()
        results = []
        for doc in SAMPLE_DOCUMENTS:
            text_lower = doc["text"].lower()
            crop_match = doc["metadata"].get("crop") and doc["metadata"]["crop"] in query_lower
            keyword_match = any(
                word in text_lower
                for word in query_lower.split()
                if len(word) > 4
            )
            if crop_match or keyword_match:
                results.append({
                    "text": doc["text"][:400] + "...",
                    "title": doc["metadata"]["source"],
                    "organization": doc["metadata"].get("organization"),
                    "crop": doc["metadata"].get("crop"),
                    "state": doc["metadata"].get("state"),
                    "source_url": doc["metadata"].get("source_url"),
                    "type": doc["metadata"].get("type"),
                    "relevance": 0.75,
                    "demo": True,
                })
        return results[:5] if results else [
            {
                "text": SAMPLE_DOCUMENTS[0]["text"][:400] + "...",
                "title": SAMPLE_DOCUMENTS[0]["metadata"]["source"],
                "organization": "ICAR",
                "demo": True,
                "relevance": 0.5,
            }
        ]

    def get_status(self) -> Dict[str, Any]:
        collection = self._get_collection()
        if collection is None:
            return {"status": "unavailable", "document_count": 0}
        try:
            count = collection.count()
            return {"status": "ready", "document_count": count}
        except Exception as e:
            return {"status": "error", "error": str(e), "document_count": 0}


# Singleton
rag_pipeline = RAGPipeline()
