"""
AgroMind AI — Weather and Irrigation Agent
Retrieves weather data and provides irrigation recommendations.
Uses OpenWeatherMap when configured; falls back to realistic demo data.
"""
import time
import structlog
from typing import Dict, Any, Optional
from app.config import settings
from app.services.granite_service import granite_service

logger = structlog.get_logger()

# Demo weather data for Karnataka districts
DEMO_WEATHER = {
    "default": {
        "location": "Karnataka, India",
        "temperature": 28.5,
        "feels_like": 30.2,
        "humidity": 72,
        "rainfall_mm": 8.4,
        "wind_speed": 12.3,
        "description": "Partly cloudy with chance of rain",
        "rain_probability": 65,
        "forecast": [
            {"day": "Today", "max": 30, "min": 22, "rain_prob": 65, "rain_mm": 8},
            {"day": "Tomorrow", "max": 29, "min": 21, "rain_prob": 80, "rain_mm": 15},
            {"day": "Day 3", "max": 28, "min": 20, "rain_prob": 70, "rain_mm": 12},
            {"day": "Day 4", "max": 31, "min": 23, "rain_prob": 30, "rain_mm": 2},
            {"day": "Day 5", "max": 32, "min": 24, "rain_prob": 20, "rain_mm": 0},
        ],
        "demo": True,
    }
}

IRRIGATION_GUIDE = {
    "drip": {"efficiency": 0.9, "notes": "Drip irrigation saves 40–50% water vs flood"},
    "sprinkler": {"efficiency": 0.75, "notes": "Sprinkler is suitable for most crops"},
    "flood": {"efficiency": 0.5, "notes": "Flood irrigation; consider upgrading to drip"},
    "rain-fed": {"efficiency": 1.0, "notes": "Fully dependent on monsoon rainfall"},
    "default": {"efficiency": 0.6, "notes": "Irrigation method not specified"},
}

CROP_WATER_NEED = {
    "paddy": {"stage_needs": {"seedling": "high", "tillering": "high", "panicle": "high", "ripening": "low"}},
    "maize": {"stage_needs": {"seedling": "low", "vegetative": "medium", "flowering": "high", "grain-fill": "medium"}},
    "ragi": {"stage_needs": {"seedling": "low", "vegetative": "medium", "flowering": "medium", "ripening": "low"}},
    "cotton": {"stage_needs": {"seedling": "low", "vegetative": "medium", "flowering": "high", "boll-fill": "high"}},
    "groundnut": {"stage_needs": {"seedling": "medium", "vegetative": "medium", "pegging": "high", "pod-fill": "high"}},
    "wheat": {"stage_needs": {"sowing": "medium", "tillering": "high", "jointing": "high", "grain-fill": "medium"}},
    "default": {"stage_needs": {"general": "medium"}},
}


class WeatherIrrigationAgent:
    """Specialized agent for weather analysis and irrigation planning."""

    name = "Weather & Irrigation Agent"

    async def run(
        self,
        farmer_profile: Optional[Dict[str, Any]] = None,
        query: str = "",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        start = time.time()
        try:
            result = await self._analyze(farmer_profile, query, context)
            result["agent_name"] = self.name
            result["status"] = "demo" if result.get("demo_mode") else "success"
            result["task"] = "Weather analysis and irrigation advisory"
            result["execution_time_ms"] = int((time.time() - start) * 1000)
            return result
        except Exception as e:
            logger.error("WeatherIrrigationAgent failed", error=str(e))
            return {
                "agent_name": self.name,
                "status": "error",
                "task": "Weather analysis and irrigation advisory",
                "error": str(e),
                "result": {},
                "sources": [],
                "execution_time_ms": int((time.time() - start) * 1000),
            }

    async def _analyze(
        self,
        profile: Optional[Dict[str, Any]],
        query: str,
        context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        location = ""
        if profile:
            location = f"{profile.get('district', '')}, {profile.get('state', 'Karnataka')}"
        if not location.strip(", "):
            location = "Karnataka, India"

        crop = profile.get("current_crop", "").lower() if profile else ""
        crop_stage = profile.get("crop_stage", "vegetative") if profile else "vegetative"
        irrigation_method = profile.get("irrigation_method", "drip") if profile else "drip"

        # Try live weather API
        weather_data = await self._fetch_weather(location)
        demo_mode = weather_data.get("demo", True)

        # Irrigation logic
        rain_prob = weather_data.get("rain_probability", 0)
        rain_mm = weather_data.get("rainfall_mm", 0)
        rain_expected = rain_prob > 50 or rain_mm > 10

        crop_key = crop.split("(")[0].strip().lower() if crop else "default"
        crop_water = CROP_WATER_NEED.get(crop_key, CROP_WATER_NEED["default"])
        stage_needs = crop_water["stage_needs"]
        current_need = stage_needs.get(crop_stage.lower(), "medium")

        irr_guide = IRRIGATION_GUIDE.get(irrigation_method.lower(), IRRIGATION_GUIDE["default"])

        if rain_expected:
            irrigation_rec = (
                "⏸️ Skip irrigation for next 2–3 days. "
                f"Rainfall of {rain_mm:.0f}mm expected with {rain_prob}% probability. "
                "Ensure field drainage is clear to prevent waterlogging."
            )
            next_irrigation = "Check after rainfall — likely 3–4 days from now"
        elif current_need == "high":
            irrigation_rec = (
                f"💧 Irrigate today or tomorrow — {crop or 'crop'} at {crop_stage} stage "
                "has HIGH water requirement. Apply sufficient water for full root zone saturation."
            )
            next_irrigation = "In 3–5 days depending on soil moisture"
        elif current_need == "medium":
            irrigation_rec = (
                f"💧 Irrigate when top 5 cm soil feels dry. "
                f"{crop or 'Crop'} at {crop_stage} stage needs MODERATE water."
            )
            next_irrigation = "In 5–7 days or when soil moisture is depleted"
        else:
            irrigation_rec = (
                f"✅ Minimal irrigation needed. "
                f"{crop or 'Crop'} at {crop_stage} stage has LOW water requirement."
            )
            next_irrigation = "Check in 7–10 days"

        # Weather warnings
        warnings = []
        temp = weather_data.get("temperature", 28)
        if temp > 35:
            warnings.append(f"⚠️ High temperature ({temp}°C): Risk of heat stress. Consider mulching and avoid afternoon irrigation.")
        if weather_data.get("rain_probability", 0) > 80:
            warnings.append("⚠️ Heavy rainfall risk: Ensure drainage channels are open. Avoid spraying fertilizers or pesticides.")
        if weather_data.get("wind_speed", 0) > 20:
            warnings.append(f"⚠️ High wind ({weather_data['wind_speed']} km/h): Avoid spraying operations.")

        # AI advisory
        prompt = (
            f"Weather report for {location}:\n"
            f"Temperature: {temp}°C, Humidity: {weather_data.get('humidity')}%, "
            f"Rain probability: {rain_prob}%, Expected rain: {rain_mm}mm\n\n"
            f"Farmer's crop: {crop or 'not specified'}, Stage: {crop_stage}\n"
            f"Irrigation method: {irrigation_method}\n\n"
            f"Query: {query}\n\n"
            "Provide specific weather-based irrigation advice and water management tips."
        )
        ai_result = await granite_service.generate(prompt)

        return {
            "weather_summary": weather_data,
            "irrigation_recommendation": irrigation_rec,
            "next_irrigation": next_irrigation,
            "water_saving_tips": [
                f"{irr_guide['notes']}",
                "Irrigate during early morning (6–9 AM) to minimize evaporation",
                "Use mulching to retain soil moisture (save 20–30% water)",
                "Monitor soil moisture with tensiometer or feel test",
                "Practice furrow or raised-bed cultivation for better water distribution",
            ],
            "weather_warnings": warnings,
            "ai_advisory": ai_result["text"],
            "demo_mode": demo_mode or ai_result["demo_mode"],
        }

    async def _fetch_weather(self, location: str) -> Dict[str, Any]:
        """Fetch live weather from OpenWeatherMap or return demo data."""
        if not settings.is_weather_configured:
            demo = dict(DEMO_WEATHER["default"])
            demo["location"] = location
            return demo

        try:
            import httpx
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    f"{settings.openweather_base_url}/weather",
                    params={
                        "q": location,
                        "appid": settings.openweather_api_key,
                        "units": "metric",
                    },
                )
                response.raise_for_status()
                data = response.json()
                forecast_response = await client.get(
                    f"{settings.openweather_base_url}/forecast",
                    params={
                        "q": location,
                        "appid": settings.openweather_api_key,
                        "units": "metric",
                        "cnt": 5,
                    },
                )
                forecast_data = forecast_response.json() if forecast_response.status_code == 200 else {}

                rain = data.get("rain", {}).get("1h", 0)
                forecast_list = forecast_data.get("list", [])
                return {
                    "location": location,
                    "temperature": data["main"]["temp"],
                    "feels_like": data["main"]["feels_like"],
                    "humidity": data["main"]["humidity"],
                    "rainfall_mm": rain,
                    "wind_speed": data["wind"]["speed"] * 3.6,
                    "description": data["weather"][0]["description"].capitalize(),
                    "rain_probability": int(forecast_list[0].get("pop", 0) * 100) if forecast_list else 0,
                    "forecast": [
                        {
                            "day": f"Day {i+1}",
                            "max": f["main"]["temp_max"],
                            "min": f["main"]["temp_min"],
                            "rain_prob": int(f.get("pop", 0) * 100),
                            "rain_mm": f.get("rain", {}).get("3h", 0),
                        }
                        for i, f in enumerate(forecast_list[:5])
                    ],
                    "demo": False,
                }
        except Exception as e:
            logger.warning("Weather API failed, using demo data", error=str(e))
            demo = dict(DEMO_WEATHER["default"])
            demo["location"] = location
            return demo


weather_irrigation_agent = WeatherIrrigationAgent()
