"""
AgroMind AI — Crop Advisory Agent
Recommends crops, nutrients, planting practices based on farmer profile.
"""
import time
import structlog
from typing import Dict, Any, Optional
from app.services.granite_service import granite_service
from app.rag.pipeline import rag_pipeline

logger = structlog.get_logger()

CROP_DATABASE = {
    "Karnataka": {
        "Kharif": [
            {"name": "Ragi (Finger Millet)", "soil": ["red laterite", "sandy loam"], "water": "low", "yield_qtl_acre": 10, "input_cost": 9000, "market_price": 2200},
            {"name": "Paddy (Rice)", "soil": ["clay", "alluvial", "black cotton"], "water": "high", "yield_qtl_acre": 20, "input_cost": 20000, "market_price": 2183},
            {"name": "Maize", "soil": ["loam", "sandy loam", "red laterite"], "water": "medium", "yield_qtl_acre": 20, "input_cost": 14000, "market_price": 1962},
            {"name": "Groundnut", "soil": ["sandy loam", "red laterite"], "water": "medium", "yield_qtl_acre": 8, "input_cost": 18000, "market_price": 5500},
            {"name": "Soybean", "soil": ["black cotton", "clay loam"], "water": "medium", "yield_qtl_acre": 9, "input_cost": 12000, "market_price": 4600},
            {"name": "Cotton (Bt)", "soil": ["black cotton", "deep loam"], "water": "medium", "yield_qtl_acre": 8, "input_cost": 25000, "market_price": 7121},
        ],
        "Rabi": [
            {"name": "Wheat", "soil": ["loam", "clay loam"], "water": "medium", "yield_qtl_acre": 15, "input_cost": 12000, "market_price": 2275},
            {"name": "Chickpea (Gram)", "soil": ["black cotton", "loam"], "water": "low", "yield_qtl_acre": 6, "input_cost": 8000, "market_price": 5440},
            {"name": "Sunflower", "soil": ["red laterite", "loam"], "water": "medium", "yield_qtl_acre": 5, "input_cost": 10000, "market_price": 6760},
            {"name": "Jowar (Sorghum)", "soil": ["black cotton", "loam"], "water": "low", "yield_qtl_acre": 8, "input_cost": 7000, "market_price": 3180},
        ],
    }
}

NUTRIENT_GUIDE = {
    "ragi": {"N": "60 kg/ha", "P": "30 kg/ha", "K": "30 kg/ha", "notes": "Split N: 50% basal, 50% at 30 DAT"},
    "paddy": {"N": "120 kg/ha", "P": "60 kg/ha", "K": "60 kg/ha", "notes": "4 split doses; apply ZnSO4 25 kg/ha"},
    "maize": {"N": "120 kg/ha", "P": "60 kg/ha", "K": "40 kg/ha", "notes": "Apply 1/3 N at sowing, 1/3 at knee-high, 1/3 at tasseling"},
    "groundnut": {"N": "20 kg/ha", "P": "60 kg/ha", "K": "40 kg/ha", "notes": "Apply gypsum 250 kg/ha at pegging for Ca"},
    "cotton": {"N": "120 kg/ha", "P": "60 kg/ha", "K": "80 kg/ha", "notes": "Apply micronutrients ZnSO4 and Borax"},
    "soybean": {"N": "20 kg/ha", "P": "80 kg/ha", "K": "40 kg/ha", "notes": "Rhizobium seed treatment for N fixation"},
    "wheat": {"N": "120 kg/ha", "P": "60 kg/ha", "K": "40 kg/ha", "notes": "Half N at sowing, half at first irrigation"},
    "default": {"N": "80 kg/ha", "P": "40 kg/ha", "K": "40 kg/ha", "notes": "General recommendation — conduct soil test for accuracy"},
}


class CropAdvisoryAgent:
    """Specialized agent for crop selection and agronomic advice."""

    name = "Crop Advisory Agent"

    async def run(
        self,
        farmer_profile: Optional[Dict[str, Any]] = None,
        query: str = "",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        start = time.time()
        try:
            result = await self._analyze(farmer_profile, query, context)
            result["agent_name"] = self.name
            result["status"] = "demo" if result.get("demo_mode") else "success"
            result["task"] = "Crop selection and agronomic advisory"
            result["execution_time_ms"] = int((time.time() - start) * 1000)
            return result
        except Exception as e:
            logger.error("CropAdvisoryAgent failed", error=str(e))
            return {
                "agent_name": self.name,
                "status": "error",
                "task": "Crop selection and agronomic advisory",
                "error": str(e),
                "result": {},
                "sources": [],
                "execution_time_ms": int((time.time() - start) * 1000),
            }

    async def _analyze(
        self,
        profile: Optional[Dict[str, Any]],
        query: str,
        context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        state = profile.get("state", "Karnataka") if profile else "Karnataka"
        district = profile.get("district", "Mysuru") if profile else "Mysuru"
        season = profile.get("season", "Kharif") if profile else "Kharif"
        soil_type = profile.get("soil_type", "red laterite") if profile else "red laterite"
        budget = profile.get("budget") if profile else None
        crop = profile.get("current_crop") if profile else None
        farming_pref = profile.get("farming_preference", "conventional") if profile else "conventional"

        # Get crop database suggestions
        crops_in_db = CROP_DATABASE.get(state, CROP_DATABASE["Karnataka"]).get(season, [])

        # Filter by soil type if possible
        matching = [c for c in crops_in_db if any(s in (soil_type or "").lower() for s in c.get("soil", []))]
        if not matching:
            matching = crops_in_db

        # Budget filter
        if budget:
            matching = [c for c in matching if c.get("input_cost", 0) <= budget * 1.2] or matching

        recommended = matching[:3] if matching else crops_in_db[:3]

        # Get nutrient guide
        crop_key = (crop or "").lower().split("(")[0].strip() if crop else "default"
        nutrients = NUTRIENT_GUIDE.get(crop_key, NUTRIENT_GUIDE["default"])

        # RAG retrieval for additional context
        rag_query = f"crop recommendation {state} {season} {soil_type or ''} {query}"
        rag_docs = await rag_pipeline.retrieve(rag_query, top_k=3, state=state)

        # Build Granite prompt
        profile_summary = ""
        if profile:
            profile_summary = (
                f"Farmer location: {district}, {state}\n"
                f"Season: {season}\n"
                f"Soil type: {soil_type}\n"
                f"Current crop: {crop or 'not specified'}\n"
                f"Budget: ₹{budget}/acre" if budget else ""
            )

        prompt = (
            f"Agricultural advisory request:\n"
            f"{profile_summary}\n"
            f"Query: {query}\n\n"
            f"Provide crop recommendations with reasoning, planting tips, and sustainable practices. "
            f"Focus on crops suitable for {state}, {season} season."
        )

        ai_result = await granite_service.generate(prompt)

        return {
            "recommended_crops": [
                {
                    "name": c["name"],
                    "yield_estimate": f"{c['yield_qtl_acre']} qtl/acre",
                    "input_cost": f"₹{c['input_cost']:,}/acre",
                    "indicative_price": f"₹{c['market_price']:,}/qtl",
                    "water_requirement": c["water"],
                    "suitable_soil": c.get("soil", []),
                }
                for c in recommended
            ],
            "nutrient_advice": {
                "nitrogen": nutrients["N"],
                "phosphorus": nutrients["P"],
                "potassium": nutrients["K"],
                "notes": nutrients["notes"],
                "source": "ICAR general guidelines — conduct soil test for precision recommendations",
            },
            "planting_calendar": {
                "season": season,
                "sowing_window": "June 15 – July 15" if season == "Kharif" else "October 15 – November 15",
                "notes": "Begin sowing after 3-4 consecutive rainy days with 50–60% soil moisture.",
            },
            "sustainable_practices": [
                "Apply 2–3 tonnes FYM/acre before sowing",
                "Use crop rotation to break pest cycles",
                "Practice integrated nutrient management (INM)",
                "Install biopesticide-based IPM methods",
                "Use certified, improved variety seeds from government-approved sources",
            ],
            "ai_advisory": ai_result["text"],
            "sources": rag_docs,
            "demo_mode": ai_result["demo_mode"],
        }


crop_advisory_agent = CropAdvisoryAgent()
