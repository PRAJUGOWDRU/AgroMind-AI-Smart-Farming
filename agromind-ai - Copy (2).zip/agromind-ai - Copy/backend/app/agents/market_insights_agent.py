"""
AgroMind AI — Market Insights Agent
Retrieves market prices and calculates farm profitability.
Uses AGMARKNET/government data when configured; falls back to demo data.
"""
import time
import structlog
from typing import Dict, Any, Optional
from app.config import settings
from app.services.granite_service import granite_service

logger = structlog.get_logger()

# Demo market data (Karnataka APMC indicative prices, 2024)
DEMO_MARKET_DATA = {
    "ragi": {"price": 2200, "unit": "INR/quintal", "market": "Davangere APMC", "msp": 3846, "trend": "stable"},
    "paddy": {"price": 2000, "unit": "INR/quintal", "market": "Mandya APMC", "msp": 2183, "trend": "rising"},
    "maize": {"price": 1850, "unit": "INR/quintal", "market": "Shimoga APMC", "msp": 1962, "trend": "stable"},
    "groundnut": {"price": 5400, "unit": "INR/quintal", "market": "Haveri APMC", "msp": 6377, "trend": "rising"},
    "cotton": {"price": 6800, "unit": "INR/quintal", "market": "Hubli APMC", "msp": 7121, "trend": "stable"},
    "soybean": {"price": 4200, "unit": "INR/quintal", "market": "Gulbarga APMC", "msp": 4600, "trend": "falling"},
    "wheat": {"price": 2100, "unit": "INR/quintal", "market": "Bijapur APMC", "msp": 2275, "trend": "stable"},
    "sunflower": {"price": 6200, "unit": "INR/quintal", "market": "Raichur APMC", "msp": 6760, "trend": "rising"},
    "chickpea": {"price": 4900, "unit": "INR/quintal", "market": "Mysuru APMC", "msp": 5440, "trend": "stable"},
    "jowar": {"price": 2800, "unit": "INR/quintal", "market": "Bidar APMC", "msp": 3180, "trend": "stable"},
    "tomato": {"price": 1200, "unit": "INR/quintal", "market": "Bangalore APMC", "msp": None, "trend": "volatile"},
    "onion": {"price": 1500, "unit": "INR/quintal", "market": "Bellary APMC", "msp": None, "trend": "volatile"},
    "default": {"price": 2000, "unit": "INR/quintal", "market": "Karnataka APMC", "msp": None, "trend": "unknown"},
}

# Cultivation cost estimates per acre (Karnataka, 2024)
COST_ESTIMATES = {
    "ragi": {"seeds": 800, "fertilizer": 3000, "pesticide": 1500, "labour": 4000, "irrigation": 500, "total": 9000},
    "paddy": {"seeds": 1500, "fertilizer": 6000, "pesticide": 2000, "labour": 8000, "irrigation": 3000, "total": 20500},
    "maize": {"seeds": 2000, "fertilizer": 5000, "pesticide": 1500, "labour": 4000, "irrigation": 2000, "total": 14500},
    "groundnut": {"seeds": 4000, "fertilizer": 4000, "pesticide": 2000, "labour": 6000, "irrigation": 2000, "total": 18000},
    "cotton": {"seeds": 3000, "fertilizer": 6000, "pesticide": 5000, "labour": 8000, "irrigation": 3000, "total": 25000},
    "soybean": {"seeds": 2000, "fertilizer": 3500, "pesticide": 2000, "labour": 4000, "irrigation": 1500, "total": 13000},
    "wheat": {"seeds": 1500, "fertilizer": 4500, "pesticide": 1500, "labour": 4000, "irrigation": 2500, "total": 14000},
    "default": {"seeds": 2000, "fertilizer": 4000, "pesticide": 2000, "labour": 5000, "irrigation": 2000, "total": 15000},
}

YIELD_ESTIMATES = {
    "ragi": 10, "paddy": 20, "maize": 20, "groundnut": 8, "cotton": 8,
    "soybean": 9, "wheat": 15, "sunflower": 5, "chickpea": 6,
    "jowar": 8, "default": 10,
}


class MarketInsightsAgent:
    """Specialized agent for market price analysis and profitability estimation."""

    name = "Market Insights Agent"

    DISCLAIMER = (
        "⚠️ DISCLAIMER: Market prices are indicative estimates based on recent APMC data. "
        "Actual prices vary by mandi, grade, and market conditions. "
        "Profit estimates are approximate and depend on actual yield, quality, and timing of sale. "
        "This is NOT a guaranteed return. Consult your nearest APMC or agricultural officer for current prices."
    )

    async def run(
        self,
        farmer_profile: Optional[Dict[str, Any]] = None,
        query: str = "",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        start = time.time()
        try:
            result = await self._analyze(farmer_profile, query, context)
            result["agent_name"] = self.name
            result["status"] = "demo" if result.get("demo_mode") else "success"
            result["task"] = "Market price analysis and profitability estimation"
            result["execution_time_ms"] = int((time.time() - start) * 1000)
            return result
        except Exception as e:
            logger.error("MarketInsightsAgent failed", error=str(e))
            return {
                "agent_name": self.name,
                "status": "error",
                "task": "Market price analysis and profitability estimation",
                "error": str(e),
                "result": {},
                "sources": [],
                "execution_time_ms": int((time.time() - start) * 1000),
            }

    async def _analyze(
        self,
        profile: Optional[Dict[str, Any]],
        query: str,
        context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        crop = (profile.get("current_crop", "") or "").lower().split("(")[0].strip() if profile else ""
        state = profile.get("state", "Karnataka") if profile else "Karnataka"
        district = profile.get("district", "Mysuru") if profile else "Mysuru"
        farm_size = profile.get("farm_size", 1.0) if profile else 1.0
        farm_size_unit = profile.get("farm_size_unit", "acres") if profile else "acres"

        # Convert to acres
        size_in_acres = farm_size if ("acre" in (farm_size_unit or "").lower()) else (farm_size or 1.0) * 2.47

        crop_key = crop if crop in DEMO_MARKET_DATA else "default"
        market = await self._fetch_market_price(crop or "general", district, state)

        costs = COST_ESTIMATES.get(crop_key, COST_ESTIMATES["default"])
        yield_per_acre = YIELD_ESTIMATES.get(crop_key, YIELD_ESTIMATES["default"])

        total_cost = costs["total"] * size_in_acres
        total_yield = yield_per_acre * size_in_acres  # quintals
        gross_revenue = total_yield * market["price"]  # price is INR/quintal
        net_profit = gross_revenue - total_cost
        roi = round((net_profit / total_cost) * 100, 1) if total_cost > 0 else 0

        msp = market.get("msp")
        sell_at_msp = msp and msp > market["price"]

        # Build prompt
        msp_line = f"MSP: ₹{msp}/quintal\n" if msp else ""
        prompt = (
            f"Market analysis for {crop or 'crop'} in {district}, {state}:\n"
            f"Current APMC price: ₹{market['price']}/quintal at {market.get('market', 'local APMC')}\n"
            f"{msp_line}"
            f"Farm size: {size_in_acres:.1f} acres\n"
            f"Expected yield: {total_yield:.1f} quintals\n"
            f"Estimated gross revenue: ₹{gross_revenue:,.0f}\n"
            f"Estimated costs: ₹{total_cost:,.0f}\n"
            f"Estimated net profit: ₹{net_profit:,.0f}\n\n"
            f"Query: {query}\n\n"
            "Provide market insights, price trends, and marketing recommendations."
        )

        ai_result = await granite_service.generate(prompt)

        return {
            "crop": crop or "general",
            "current_price": market["price"],
            "price_unit": market["unit"],
            "market_name": market.get("market"),
            "msp": msp,
            "price_trend": market.get("trend", "unknown"),
            "sell_recommendation": (
                f"Consider selling through procurement centers at MSP (₹{msp}/qtl) — "
                f"higher than current mandi price (₹{market['price']}/qtl)."
            ) if sell_at_msp else f"Current mandi price ₹{market['price']}/qtl. Monitor for better price.",
            "farm_analysis": {
                "farm_size_acres": round(size_in_acres, 2),
                "expected_yield_quintals": round(total_yield, 1),
                "gross_revenue": round(gross_revenue, 0),
                "cultivation_cost": round(total_cost, 0),
                "net_profit": round(net_profit, 0),
                "roi_percent": roi,
            },
            "cost_breakdown": {
                "seeds_per_acre": costs["seeds"],
                "fertilizer_per_acre": costs["fertilizer"],
                "pesticide_per_acre": costs["pesticide"],
                "labour_per_acre": costs["labour"],
                "irrigation_per_acre": costs["irrigation"],
                "total_per_acre": costs["total"],
                "note": "Estimates based on Karnataka average 2024. Actual costs vary.",
            },
            "marketing_options": [
                f"APMC Mandi — {market.get('market', 'local APMC')}: Current price ₹{market['price']}/qtl",
                "Farmer Producer Organization (FPO) — collective selling for better price",
                "e-NAM (National Agriculture Market) — online trading platform",
                "Government procurement at MSP through NCCF/FCI" if msp else "Check APMC for current prices",
                "Direct-to-consumer or agri-food processors for premium crops",
            ],
            "ai_advisory": ai_result["text"],
            "disclaimer": self.DISCLAIMER,
            "demo_mode": market.get("demo", True) or ai_result["demo_mode"],
        }

    async def _fetch_market_price(self, crop: str, district: str, state: str) -> Dict:
        """Fetch market price from AGMARKNET API or return demo data."""
        crop_key = crop.lower().split("(")[0].strip()
        demo_data = {**DEMO_MARKET_DATA.get(crop_key, DEMO_MARKET_DATA["default"]), "demo": True}

        if not settings.is_market_configured:
            return demo_data

        try:
            import httpx
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    settings.agmarknet_base_url,
                    params={
                        "api-key": settings.agmarknet_api_key,
                        "format": "json",
                        "filters[commodity]": crop.title(),
                        "filters[state]": state,
                        "limit": 5,
                    },
                )
                response.raise_for_status()
                data = response.json()
                records = data.get("records", [])
                if records:
                    prices = [float(r.get("modal_price", 0)) for r in records if r.get("modal_price")]
                    avg_price = sum(prices) / len(prices) if prices else demo_data["price"]
                    return {
                        "price": round(avg_price),
                        "unit": "INR/quintal",
                        "market": records[0].get("market", f"{district} APMC"),
                        "msp": demo_data.get("msp"),
                        "trend": "unknown",
                        "demo": False,
                    }
        except Exception as e:
            logger.warning("Market API failed, using demo data", error=str(e))

        return demo_data


market_insights_agent = MarketInsightsAgent()
