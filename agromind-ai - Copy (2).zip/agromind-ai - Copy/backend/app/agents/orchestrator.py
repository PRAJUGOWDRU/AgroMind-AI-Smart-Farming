"""
AgroMind AI — Agent Orchestrator
Coordinates all specialized agents and produces a unified final advisory.
"""
import time
import re
import structlog
from typing import Dict, Any, Optional, List
from app.agents.crop_advisory_agent import crop_advisory_agent
from app.agents.weather_irrigation_agent import weather_irrigation_agent
from app.agents.pest_disease_agent import pest_disease_agent
from app.agents.market_insights_agent import market_insights_agent
from app.rag.pipeline import rag_pipeline
from app.services.granite_service import granite_service

logger = structlog.get_logger()


class AgentOrchestrator:
    """
    Coordinates specialized agents based on farmer query.
    Routes tasks, aggregates results, and produces a unified advisory.
    """

    def _classify_intent(self, query: str) -> List[str]:
        """Determine which agents to invoke based on query analysis."""
        q = query.lower()
        agents_needed = []

        # Pest/disease detection patterns
        if any(w in q for w in [
            "yellow", "spot", "rot", "wilt", "disease", "pest", "insect", "fungi",
            "white powder", "brown", "lesion", "symptom", "dying", "blight", "virus",
            "mildew", "aphid", "caterpillar", "leaf", "damage"
        ]):
            agents_needed.append("pest_disease")

        # Weather/irrigation patterns
        if any(w in q for w in [
            "rain", "water", "irrigat", "weather", "drought", "flood", "moisture",
            "forecast", "monsoon", "temperature", "dry spell", "humidity", "when to water"
        ]):
            agents_needed.append("weather_irrigation")

        # Market/profit patterns
        if any(w in q for w in [
            "price", "sell", "market", "profit", "cost", "income", "msp", "apmc",
            "revenue", "budget", "earn", "money", "rupee", "₹", "quintal"
        ]):
            agents_needed.append("market")

        # Crop advisory patterns
        if any(w in q for w in [
            "crop", "seed", "sow", "plant", "fertilizer", "nutrient", "soil",
            "nitrogen", "phosphorus", "potassium", "recommend", "grow", "variety",
            "rotation", "organic", "stage", "harvest", "yield", "cultivation"
        ]):
            agents_needed.append("crop")

        # If no specific intent, run crop advisory + RAG as baseline
        if not agents_needed:
            agents_needed = ["crop", "weather_irrigation"]

        return agents_needed

    async def process_query(
        self,
        query: str,
        farmer_profile: Optional[Dict[str, Any]] = None,
        image_data: Optional[bytes] = None,
        image_filename: Optional[str] = None,
        language: str = "en",
    ) -> Dict[str, Any]:
        """
        Main orchestration method.
        1. Classify query intent
        2. Retrieve RAG context
        3. Invoke relevant agents in parallel (where safe)
        4. Combine results into unified advisory
        """
        start_time = time.time()
        agents_to_run = self._classify_intent(query)

        # If image provided, always include pest_disease
        if image_data and "pest_disease" not in agents_to_run:
            agents_to_run.append("pest_disease")

        logger.info("Orchestrator routing", agents=agents_to_run, query=query[:80])

        # Step 1: RAG retrieval
        rag_result = await rag_pipeline.retrieve(query, top_k=4)

        # Step 2: Run agents
        agent_results = []

        if "crop" in agents_to_run:
            result = await crop_advisory_agent.run(
                farmer_profile=farmer_profile,
                query=query,
                context={"rag_docs": rag_result},
            )
            agent_results.append(result)

        if "weather_irrigation" in agents_to_run:
            result = await weather_irrigation_agent.run(
                farmer_profile=farmer_profile,
                query=query,
                context={"rag_docs": rag_result},
            )
            agent_results.append(result)

        if "pest_disease" in agents_to_run:
            result = await pest_disease_agent.run(
                farmer_profile=farmer_profile,
                query=query,
                context={"rag_docs": rag_result},
                image_data=image_data,
                image_filename=image_filename,
            )
            agent_results.append(result)

        if "market" in agents_to_run:
            result = await market_insights_agent.run(
                farmer_profile=farmer_profile,
                query=query,
                context={"rag_docs": rag_result},
            )
            agent_results.append(result)

        # Step 3: Synthesize final answer with Granite
        final_answer = await self._synthesize(query, farmer_profile, agent_results, rag_result, language)

        # Step 4: Any demo mode?
        demo_mode = (
            final_answer.get("demo_mode", True)
            or any(r.get("demo_mode") for r in agent_results if isinstance(r.get("demo_mode"), bool))
        )

        elapsed = int((time.time() - start_time) * 1000)
        logger.info("Orchestrator complete", agents=agents_to_run, ms=elapsed)

        return {
            "query": query,
            "answer": final_answer["text"],
            "agents_used": [
                {
                    "agent_name": r.get("agent_name"),
                    "status": r.get("status"),
                    "task": r.get("task"),
                    "result": r,
                    "sources": r.get("sources", []),
                    "execution_time_ms": r.get("execution_time_ms"),
                }
                for r in agent_results
            ],
            "rag_sources": rag_result,
            "demo_mode": demo_mode,
            "model_used": "DEMO_MODE" if final_answer.get("demo_mode") else granite_service.model_id,
            "elapsed_ms": elapsed,
        }

    async def _synthesize(
        self,
        query: str,
        profile: Optional[Dict[str, Any]],
        agent_results: List[Dict[str, Any]],
        rag_docs: List[Dict[str, Any]],
        language: str,
    ) -> Dict[str, Any]:
        """Combine agent results into a single prioritized advisory."""
        profile_summary = ""
        if profile:
            profile_summary = (
                f"Farmer: {profile.get('name', 'N/A')}, "
                f"Location: {profile.get('district')}, {profile.get('state')}\n"
                f"Crop: {profile.get('current_crop', 'N/A')}, "
                f"Stage: {profile.get('crop_stage', 'N/A')}\n"
                f"Farm size: {profile.get('farm_size', 'N/A')} {profile.get('farm_size_unit', 'acres')}\n"
            )

        agent_summaries = []
        for r in agent_results:
            if r.get("status") == "error":
                agent_summaries.append(f"[{r['agent_name']}]: Error — {r.get('error', 'unknown')}")
                continue
            name = r.get("agent_name", "Agent")
            # Extract key findings
            ai_advice = r.get("ai_advisory", "")
            if ai_advice:
                agent_summaries.append(f"[{name}]:\n{ai_advice[:600]}")

        rag_context = ""
        if rag_docs:
            rag_context = "Relevant knowledge retrieved:\n" + "\n".join(
                f"- {d.get('title', 'Source')}: {d.get('text', '')[:200]}..." for d in rag_docs[:3]
            )

        prompt = (
            f"You are AgroMind AI. Synthesize the following agent analyses into one clear, "
            f"actionable advisory for the farmer.\n\n"
            f"Farmer profile:\n{profile_summary}\n"
            f"Question: {query}\n\n"
            f"Agent analyses:\n" + "\n\n".join(agent_summaries) + "\n\n"
            f"{rag_context}\n\n"
            f"Produce a prioritized action plan in {'Kannada and ' if language == 'kn' else ''}English. "
            f"Use numbered steps. Mention which information is uncertain. "
            f"End with: which agents ran, which integrations used demo data, and next steps."
        )

        return await granite_service.generate(prompt, max_tokens=1500)


orchestrator = AgentOrchestrator()
