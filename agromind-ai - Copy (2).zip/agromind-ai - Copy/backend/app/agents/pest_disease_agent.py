"""
AgroMind AI — Pest & Disease Detection Agent
Analyzes crop images for diseases/pests.
IBM Granite text model is used for reasoning; image analysis via Pillow + pattern matching.
A vision-language model adapter can be plugged in when available.
"""
import time
import base64
import structlog
from typing import Dict, Any, Optional, List
from app.services.granite_service import granite_service

logger = structlog.get_logger()

# ─── Disease Knowledge Base ────────────────────────────────────────────────

DISEASE_PATTERNS = {
    "yellow_leaves": {
        "issues": ["Nitrogen Deficiency", "Iron Chlorosis", "Yellowing Mosaic Virus", "Root Rot"],
        "primary": "Nitrogen Deficiency",
        "symptoms": [
            "Yellowing starts from older/lower leaves and progresses upward",
            "Pale green to yellow color, especially between leaf veins",
            "Stunted plant growth in severe cases",
        ],
        "severity": "Moderate",
        "ipm": [
            "Apply urea (46% N) at 25–30 kg/acre as top dressing",
            "Use neem cake (200 kg/acre) as organic nitrogen source",
            "Check soil pH — nitrogen becomes unavailable above pH 7.5",
            "Ensure proper drainage — waterlogging causes nitrogen loss",
        ],
        "chemical": [
            "Foliar spray: 2% urea solution (20 g urea in 1 L water)",
            "Apply ferrous sulphate (0.5%) for iron deficiency (yellowing between veins)",
        ],
        "consult_expert": False,
    },
    "brown_spots": {
        "issues": ["Leaf Blight", "Brown Spot Disease", "Blast", "Alternaria Leaf Spot"],
        "primary": "Leaf Blight (Helminthosporium sp.)",
        "symptoms": [
            "Brown to tan oval spots with yellow halos on leaves",
            "Spots may merge under wet conditions",
            "Severe infection causes leaf drying and premature defoliation",
        ],
        "severity": "Moderate to High",
        "ipm": [
            "Remove and destroy infected plant parts",
            "Avoid overhead irrigation to reduce leaf wetness",
            "Ensure proper plant spacing for air circulation",
            "Use disease-resistant varieties in next season",
            "Crop rotation to break disease cycle",
        ],
        "chemical": [
            "Mancozeb 75 WP @ 2 g/L water — spray every 10–12 days",
            "Carbendazim 50 WP @ 1 g/L water — for systemic control",
            "Hexaconazole 5 EC @ 2 ml/L — for severe infection",
            "⚠️ Rotate fungicides to prevent resistance. Follow label instructions.",
        ],
        "consult_expert": False,
    },
    "white_powder": {
        "issues": ["Powdery Mildew", "Downy Mildew"],
        "primary": "Powdery Mildew (Erysiphe sp.)",
        "symptoms": [
            "White powdery coating on leaf surface",
            "Affected leaves curl and turn yellow",
            "Typically appears on upper leaf surface first",
        ],
        "severity": "Moderate",
        "ipm": [
            "Increase air circulation by proper spacing",
            "Avoid excessive nitrogen fertilization",
            "Remove severely infected plant parts",
            "Spray neem oil (5 ml/L water) as preventive measure",
        ],
        "chemical": [
            "Wettable sulphur 80 WP @ 2 g/L water",
            "Triadimefon 25 WP @ 1 g/L water",
            "Azoxystrobin 23 SC @ 1 ml/L water",
            "⚠️ Do not apply sulphur when temperature exceeds 35°C.",
        ],
        "consult_expert": False,
    },
    "insects_visible": {
        "issues": ["Aphids", "Whiteflies", "Thrips", "Leafhoppers", "Scale Insects"],
        "primary": "Sucking Pest Infestation",
        "symptoms": [
            "Tiny insects visible on leaf undersides or stem",
            "Curling, yellowing, or distortion of young leaves",
            "Sticky honeydew secretion on leaves (sooty mold may follow)",
            "Stunted or wilted growing tips",
        ],
        "severity": "Moderate",
        "ipm": [
            "Install yellow sticky traps (10/acre) for monitoring and mass trapping",
            "Spray neem-based formulations (NSKE 5% or neem oil 5 ml/L)",
            "Encourage natural enemies (ladybird beetles, lacewings)",
            "Avoid excessive nitrogen which promotes soft, pest-preferred growth",
        ],
        "chemical": [
            "Imidacloprid 17.8 SL @ 0.3 ml/L (for aphids, whitefly) — one application",
            "Thiamethoxam 25 WG @ 0.3 g/L water",
            "Dimethoate 30 EC @ 2 ml/L for thrips",
            "⚠️ Avoid excessive insecticide use — it kills beneficial insects.",
        ],
        "consult_expert": False,
    },
    "stem_rot": {
        "issues": ["Stem Rot", "Collar Rot", "Fusarium Wilt", "Phytophthora Root Rot"],
        "primary": "Stem/Collar Rot (Sclerotium rolfsii or Fusarium sp.)",
        "symptoms": [
            "Rotting or discoloration at base of stem",
            "Wilting despite adequate moisture",
            "White fungal growth or dark lesions at soil line",
            "Easy pulling of plant from soil (root destruction)",
        ],
        "severity": "High",
        "ipm": [
            "Remove and destroy affected plants immediately",
            "Avoid waterlogging and improve field drainage",
            "Drench soil with Trichoderma-based biocontrol (5 g/L water)",
            "Practice deep summer ploughing to expose and kill soilborne pathogens",
        ],
        "chemical": [
            "Carbendazim 50 WP soil drench @ 1 g/L water around root zone",
            "Metalaxyl + Mancozeb @ 2 g/L for Phytophthora",
            "⚠️ Consult local agricultural officer if spread is rapid.",
        ],
        "consult_expert": True,
    },
    "default": {
        "issues": ["Unknown Issue"],
        "primary": "Unable to determine from image alone",
        "symptoms": [
            "Symptoms visible in image require closer examination",
            "Multiple causes possible — disease, pest, nutritional, or environmental stress",
        ],
        "severity": "Unknown",
        "ipm": [
            "Photograph affected plants from multiple angles (whole plant, close-up of leaf)",
            "Note when symptoms first appeared and rate of spread",
            "Check surrounding plants for similar symptoms",
            "Collect a sample for laboratory diagnosis",
        ],
        "chemical": [
            "Do not apply any pesticide until issue is identified",
            "Consult a local agricultural expert, KVK, or Krishi Vigyan Kendra",
        ],
        "consult_expert": True,
    },
}


class PestDiseaseDetectionAgent:
    """Specialized agent for crop image analysis and pest/disease detection."""

    name = "Pest & Disease Detection Agent"

    DISCLAIMER = (
        "⚠️ IMPORTANT DISCLAIMER: This analysis is AI-assisted and based on visual patterns. "
        "It is NOT a definitive diagnosis. Agricultural diseases require laboratory confirmation. "
        "Always consult a qualified agronomist or your nearest Krishi Vigyan Kendra (KVK) "
        "before applying any pesticide or treatment. Never apply pesticide combinations "
        "not recommended on the label."
    )

    async def run(
        self,
        farmer_profile: Optional[Dict[str, Any]] = None,
        query: str = "",
        context: Optional[Dict[str, Any]] = None,
        image_data: Optional[bytes] = None,
        image_filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        start = time.time()
        try:
            result = await self._analyze(farmer_profile, query, context, image_data, image_filename)
            result["agent_name"] = self.name
            result["status"] = "demo" if result.get("demo_mode") else "success"
            result["task"] = "Crop image analysis for pest and disease detection"
            result["execution_time_ms"] = int((time.time() - start) * 1000)
            return result
        except Exception as e:
            logger.error("PestDiseaseDetectionAgent failed", error=str(e))
            return {
                "agent_name": self.name,
                "status": "error",
                "task": "Crop image analysis for pest and disease detection",
                "error": str(e),
                "result": {},
                "sources": [],
                "execution_time_ms": int((time.time() - start) * 1000),
            }

    async def _analyze(
        self,
        profile: Optional[Dict[str, Any]],
        query: str,
        context: Optional[Dict[str, Any]],
        image_data: Optional[bytes],
        image_filename: Optional[str],
    ) -> Dict[str, Any]:
        crop = profile.get("current_crop", "") if profile else ""
        crop_stage = profile.get("crop_stage", "") if profile else ""

        # Classify symptoms from query + basic image analysis
        symptom_key = self._classify_symptoms(query, image_data)
        pattern = DISEASE_PATTERNS.get(symptom_key, DISEASE_PATTERNS["default"])

        # Build prompt for Granite
        image_context = ""
        if image_data:
            image_context = f"An image has been uploaded for analysis (filename: {image_filename or 'crop_image'}). "
            image_analysis = self._basic_image_analysis(image_data)
            image_context += f"Image properties: {image_analysis}. "

        prompt = (
            f"Crop disease/pest analysis request:\n"
            f"Crop: {crop or 'not specified'}, Stage: {crop_stage or 'not specified'}\n"
            f"{image_context}"
            f"Farmer describes: {query}\n\n"
            f"Based on the symptoms described, the most likely issue appears to be: "
            f"{pattern['primary']}.\n"
            f"Visible symptoms: {', '.join(pattern['symptoms'][:2])}\n\n"
            f"Provide a comprehensive analysis including: diagnosis reasoning, severity, "
            f"IPM recommendations prioritizing biological/cultural controls, chemical options "
            f"as last resort, and when to consult an expert."
        )

        ai_result = await granite_service.generate(prompt)

        return {
            "detected_issue": pattern["primary"],
            "possible_issues": pattern["issues"],
            "confidence": "Moderate (visual pattern match)" if symptom_key != "default" else "Low (insufficient information)",
            "symptoms": pattern["symptoms"],
            "severity": pattern["severity"],
            "ipm_recommendations": pattern["ipm"],
            "chemical_options": pattern["chemical"],
            "consult_expert": pattern["consult_expert"],
            "ai_advisory": ai_result["text"],
            "disclaimer": self.DISCLAIMER,
            "image_analyzed": image_data is not None,
            "note": (
                "IBM Granite text model used for reasoning. "
                "For image analysis, a dedicated vision model is recommended. "
                "Current analysis is based on symptom description and basic image properties."
            ),
            "demo_mode": ai_result["demo_mode"],
        }

    def _classify_symptoms(self, query: str, image_data: Optional[bytes]) -> str:
        """Simple keyword-based symptom classification."""
        query_lower = query.lower()
        if any(w in query_lower for w in ["yellow", "yellowing", "pale", "chlorosis"]):
            return "yellow_leaves"
        if any(w in query_lower for w in ["brown spot", "blight", "lesion", "dark spot"]):
            return "brown_spots"
        if any(w in query_lower for w in ["white powder", "powdery", "mildew"]):
            return "white_powder"
        if any(w in query_lower for w in ["insect", "bug", "aphid", "fly", "pest", "whitefly"]):
            return "insects_visible"
        if any(w in query_lower for w in ["stem rot", "wilt", "collar rot", "root rot", "wilting"]):
            return "stem_rot"
        return "default"

    def _basic_image_analysis(self, image_data: bytes) -> str:
        """Basic image property analysis using Pillow."""
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(image_data))
            width, height = img.size
            mode = img.mode
            return f"{width}x{height} pixels, {mode} mode, {len(image_data)//1024}KB"
        except Exception:
            return "unable to read image properties"


pest_disease_agent = PestDiseaseDetectionAgent()
