// AgroMind AI — Centralized API Client
import axios, { AxiosError } from 'axios';

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

export const api = axios.create({
  baseURL: BASE_URL,
  timeout: 60000,
  headers: { 'Content-Type': 'application/json' },
});

// Response interceptor for error normalization
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const message =
      (error.response?.data as { detail?: string })?.detail ||
      error.message ||
      'An unexpected error occurred';
    return Promise.reject(new Error(message));
  }
);

// ─── Health ──────────────────────────────────────────────────────────────────

export const healthCheck = () => api.get('/api/health');

// ─── Farmer Profile ───────────────────────────────────────────────────────────

export const getFarmerProfile = (farmerId: string) =>
  api.get(`/api/farmer/profile/${farmerId}`);

export const createFarmerProfile = (data: Record<string, unknown>) =>
  api.post('/api/farmer/profile', data);

export const updateFarmerProfile = (farmerId: string, data: Record<string, unknown>) =>
  api.put(`/api/farmer/profile/${farmerId}`, data);

// ─── Chat ─────────────────────────────────────────────────────────────────────

export const sendChat = (query: string, farmerId?: string, language = 'en') =>
  api.post('/api/chat', { query, farmer_id: farmerId, language });

// ─── Advisory ────────────────────────────────────────────────────────────────

export const getCropAdvisory = (data: Record<string, unknown>) =>
  api.post('/api/advisory/crop', data);

export const getIrrigationAdvisory = (data: Record<string, unknown>) =>
  api.post('/api/advisory/irrigation', data);

// ─── Detection ───────────────────────────────────────────────────────────────

export const detectDisease = (query: string, farmerId?: string, image?: File) => {
  const formData = new FormData();
  formData.append('query', query);
  if (farmerId) formData.append('farmer_id', farmerId);
  if (image) formData.append('image', image);
  return api.post('/api/detection/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

// ─── Market ──────────────────────────────────────────────────────────────────

export const getMarketInsights = (data: Record<string, unknown>) =>
  api.post('/api/market/insights', data);

// ─── RAG ─────────────────────────────────────────────────────────────────────

export const queryRAG = (query: string, crop?: string, state?: string, topK = 5) =>
  api.post('/api/rag/query', { query, crop, state, top_k: topK });

export const uploadKnowledgeDocument = (formData: FormData) =>
  api.post('/api/knowledge/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

export const getKnowledgeSources = () => api.get('/api/knowledge/sources');

// ─── Status ──────────────────────────────────────────────────────────────────

export const getIntegrationsStatus = () => api.get('/api/integrations/status');
export const testGraniteConnection = () => api.post('/api/integrations/test-granite');
export const getAgentsStatus = () => api.get('/api/agents/status');
export const getHistory = (farmerId?: string, limit = 20) =>
  api.get('/api/history', { params: { farmer_id: farmerId, limit } });
