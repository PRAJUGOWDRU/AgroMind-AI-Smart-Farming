// AgroMind AI — Root Application with Routing
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { AskAI } from './pages/AskAI';
import { CropSoilAdvisory } from './pages/CropSoilAdvisory';
import { WeatherIrrigation } from './pages/WeatherIrrigation';
import { PestDiseaseDetection } from './pages/PestDiseaseDetection';
import { MarketProfit } from './pages/MarketProfit';
import { FarmProfile } from './pages/FarmProfile';
import { KnowledgeBase } from './pages/KnowledgeBase';
import { AgentActivity } from './pages/AgentActivity';
import { SettingsPage } from './pages/SettingsPage';

function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: { fontSize: 13, maxWidth: 360 },
        }}
      />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="ask" element={<AskAI />} />
          <Route path="crop" element={<CropSoilAdvisory />} />
          <Route path="weather" element={<WeatherIrrigation />} />
          <Route path="detection" element={<PestDiseaseDetection />} />
          <Route path="market" element={<MarketProfit />} />
          <Route path="profile" element={<FarmProfile />} />
          <Route path="knowledge" element={<KnowledgeBase />} />
          <Route path="agents" element={<AgentActivity />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
