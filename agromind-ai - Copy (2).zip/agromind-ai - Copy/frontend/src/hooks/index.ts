// AgroMind AI — Custom React Hooks

import { useState, useEffect, useCallback } from 'react';
import { healthCheck, getIntegrationsStatus, getHistory } from '../services/api';
import type { IntegrationStatus, HistoryItem } from '../types';

// ─── useFarmerProfile ─────────────────────────────────────────────────────────

export const FARMER_ID_KEY = 'agromind_farmer_id';

export function useLocalFarmerId(): [string | null, (id: string) => void] {
  const [farmerId, setFarmerIdState] = useState<string | null>(
    () => localStorage.getItem(FARMER_ID_KEY)
  );
  const setFarmerId = (id: string) => {
    localStorage.setItem(FARMER_ID_KEY, id);
    setFarmerIdState(id);
  };
  return [farmerId, setFarmerId];
}

// ─── useHealthStatus ──────────────────────────────────────────────────────────

export function useHealthStatus() {
  const [status, setStatus] = useState<'loading' | 'ok' | 'error'>('loading');
  const [demoMode, setDemoMode] = useState(true);

  useEffect(() => {
    healthCheck()
      .then((res) => {
        setStatus('ok');
        setDemoMode(res.data.demo_mode ?? true);
      })
      .catch(() => setStatus('error'));
  }, []);

  return { status, demoMode };
}

// ─── useIntegrations ─────────────────────────────────────────────────────────

export function useIntegrations() {
  const [integrations, setIntegrations] = useState<IntegrationStatus[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getIntegrationsStatus();
      setIntegrations(res.data.integrations || []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  return { integrations, loading, refresh: fetch };
}

// ─── useHistory ───────────────────────────────────────────────────────────────

export function useHistory(farmerId?: string | null) {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getHistory(farmerId || undefined, 20);
      setHistory(res.data.history || []);
    } catch {
      setHistory([]);
    } finally {
      setLoading(false);
    }
  }, [farmerId]);

  useEffect(() => { fetch(); }, [fetch]);

  return { history, loading, refresh: fetch };
}
