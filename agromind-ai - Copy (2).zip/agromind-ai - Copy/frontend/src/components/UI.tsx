// AgroMind AI — Shared UI Components
import React from 'react';
import { clsx } from 'clsx';
import { AlertTriangle, CheckCircle, Info, Loader2 } from 'lucide-react';

// ─── DemoBadge ────────────────────────────────────────────────────────────────

export const DemoBadge: React.FC<{ className?: string }> = ({ className }) => (
  <span className={clsx('demo-badge', className)}>
    ⚡ DEMO MODE
  </span>
);

// ─── StatusDot ────────────────────────────────────────────────────────────────

export const StatusDot: React.FC<{ status: string }> = ({ status }) => {
  const color =
    status === 'connected' || status === 'ready' || status === 'ok'
      ? '#22c55e'
      : status === 'demo'
      ? '#f59e0b'
      : '#ef4444';
  return (
    <span
      style={{
        display: 'inline-block',
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: color,
        flexShrink: 0,
      }}
    />
  );
};

// ─── LoadingSpinner ───────────────────────────────────────────────────────────

export const LoadingSpinner: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className,
}) => (
  <Loader2
    size={size}
    className={className}
    style={{ animation: 'spin 1s linear infinite' }}
  />
);

// ─── Alert ────────────────────────────────────────────────────────────────────

interface AlertProps {
  type: 'info' | 'warning' | 'success' | 'error';
  children: React.ReactNode;
  className?: string;
}

export const Alert: React.FC<AlertProps> = ({ type, children, className }) => {
  const styles: Record<string, React.CSSProperties> = {
    info: { background: '#eff6ff', border: '1px solid #bfdbfe', color: '#1e40af' },
    warning: { background: '#fffbeb', border: '1px solid #fde68a', color: '#92400e' },
    success: { background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#14532d' },
    error: { background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b' },
  };
  const icons = {
    info: <Info size={16} />,
    warning: <AlertTriangle size={16} />,
    success: <CheckCircle size={16} />,
    error: <AlertTriangle size={16} />,
  };
  return (
    <div
      className={clsx('alert', className)}
      style={{
        ...styles[type],
        padding: '10px 14px',
        borderRadius: 8,
        display: 'flex',
        alignItems: 'flex-start',
        gap: 8,
        fontSize: 14,
      }}
    >
      <span style={{ flexShrink: 0, marginTop: 1 }}>{icons[type]}</span>
      <span>{children}</span>
    </div>
  );
};

// ─── Card ─────────────────────────────────────────────────────────────────────

interface CardProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  padding?: number | string;
}

export const Card: React.FC<CardProps> = ({ children, className, style, padding = '20px' }) => (
  <div
    className={clsx('card', className)}
    style={{ padding, ...style }}
  >
    {children}
  </div>
);

// ─── Button ───────────────────────────────────────────────────────────────────

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
}

const BTN_STYLES: Record<string, React.CSSProperties> = {
  primary: { background: '#16a34a', color: '#fff', border: '1px solid #16a34a' },
  secondary: { background: '#f3f4f6', color: '#374151', border: '1px solid #d1d5db' },
  outline: { background: 'transparent', color: '#16a34a', border: '1px solid #16a34a' },
  danger: { background: '#ef4444', color: '#fff', border: '1px solid #ef4444' },
};

const BTN_SIZE: Record<string, React.CSSProperties> = {
  sm: { padding: '6px 12px', fontSize: 13, borderRadius: 6 },
  md: { padding: '8px 16px', fontSize: 14, borderRadius: 8 },
  lg: { padding: '11px 22px', fontSize: 15, borderRadius: 8 },
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  loading,
  icon,
  children,
  disabled,
  style,
  ...rest
}) => (
  <button
    {...rest}
    disabled={disabled || loading}
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontWeight: 500,
      cursor: disabled || loading ? 'not-allowed' : 'pointer',
      opacity: disabled || loading ? 0.65 : 1,
      transition: 'opacity 0.15s',
      ...BTN_STYLES[variant],
      ...BTN_SIZE[size],
      ...style,
    }}
  >
    {loading ? <LoadingSpinner size={14} /> : icon}
    {children}
  </button>
);

// ─── Input ────────────────────────────────────────────────────────────────────

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export const Input: React.FC<InputProps> = ({ label, error, hint, id, ...rest }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
    {label && (
      <label htmlFor={id} style={{ fontSize: 13, fontWeight: 500, color: '#374151' }}>
        {label}
      </label>
    )}
    <input
      id={id}
      {...rest}
      style={{
        padding: '8px 12px',
        border: `1px solid ${error ? '#ef4444' : '#d1d5db'}`,
        borderRadius: 8,
        fontSize: 14,
        outline: 'none',
        width: '100%',
        background: '#fff',
        color: '#1f2937',
        ...rest.style,
      }}
    />
    {error && <span style={{ fontSize: 12, color: '#ef4444' }}>{error}</span>}
    {hint && !error && <span style={{ fontSize: 12, color: '#6b7280' }}>{hint}</span>}
  </div>
);

// ─── Select ───────────────────────────────────────────────────────────────────

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: { value: string; label: string }[];
  error?: string;
}

export const Select: React.FC<SelectProps> = ({ label, options, error, id, ...rest }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
    {label && (
      <label htmlFor={id} style={{ fontSize: 13, fontWeight: 500, color: '#374151' }}>
        {label}
      </label>
    )}
    <select
      id={id}
      {...rest}
      style={{
        padding: '8px 12px',
        border: `1px solid ${error ? '#ef4444' : '#d1d5db'}`,
        borderRadius: 8,
        fontSize: 14,
        background: '#fff',
        color: '#1f2937',
        width: '100%',
        cursor: 'pointer',
        ...rest.style,
      }}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
    {error && <span style={{ fontSize: 12, color: '#ef4444' }}>{error}</span>}
  </div>
);

// ─── Textarea ─────────────────────────────────────────────────────────────────

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const Textarea: React.FC<TextareaProps> = ({ label, error, id, ...rest }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
    {label && (
      <label htmlFor={id} style={{ fontSize: 13, fontWeight: 500, color: '#374151' }}>
        {label}
      </label>
    )}
    <textarea
      id={id}
      {...rest}
      style={{
        padding: '8px 12px',
        border: `1px solid ${error ? '#ef4444' : '#d1d5db'}`,
        borderRadius: 8,
        fontSize: 14,
        resize: 'vertical',
        minHeight: 80,
        width: '100%',
        fontFamily: 'inherit',
        color: '#1f2937',
        background: '#fff',
        ...rest.style,
      }}
    />
    {error && <span style={{ fontSize: 12, color: '#ef4444' }}>{error}</span>}
  </div>
);

// ─── SectionHeader ────────────────────────────────────────────────────────────

export const SectionHeader: React.FC<{
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}> = ({ title, subtitle, icon, action }) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 20,
    }}
  >
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      {icon && (
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 8,
            background: '#dcfce7',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#16a34a',
          }}
        >
          {icon}
        </div>
      )}
      <div>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: '#111827' }}>{title}</h2>
        {subtitle && <p style={{ fontSize: 13, color: '#6b7280', marginTop: 2 }}>{subtitle}</p>}
      </div>
    </div>
    {action}
  </div>
);
