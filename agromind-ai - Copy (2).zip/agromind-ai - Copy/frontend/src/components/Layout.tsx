// AgroMind AI — App Layout with Sidebar Navigation
import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard, MessageSquare, Sprout, CloudRain, Bug,
  TrendingUp, User, BookOpen, Activity, Settings, Menu, X, Leaf,
} from 'lucide-react';
import { DemoBadge, StatusDot } from './UI';
import { useHealthStatus } from '../hooks';

const NAV_ITEMS = [
  { to: '/', icon: <LayoutDashboard size={18} />, label: 'Dashboard', labelKn: 'ಮುಖಪುಟ' },
  { to: '/ask', icon: <MessageSquare size={18} />, label: 'Ask AgroMind AI', labelKn: 'AI ಕೇಳಿ' },
  { to: '/crop', icon: <Sprout size={18} />, label: 'Crop & Soil Advisory', labelKn: 'ಬೆಳೆ ಸಲಹೆ' },
  { to: '/weather', icon: <CloudRain size={18} />, label: 'Weather & Irrigation', labelKn: 'ಹವಾಮಾನ' },
  { to: '/detection', icon: <Bug size={18} />, label: 'Pest & Disease', labelKn: 'ರೋಗ ಪತ್ತೆ' },
  { to: '/market', icon: <TrendingUp size={18} />, label: 'Market & Profit', labelKn: 'ಮಾರುಕಟ್ಟೆ' },
  { to: '/profile', icon: <User size={18} />, label: 'My Farm Profile', labelKn: 'ನನ್ನ ಪ್ರೊಫೈಲ್' },
  { to: '/knowledge', icon: <BookOpen size={18} />, label: 'Knowledge Base', labelKn: 'ಜ್ಞಾನ ಕೋಶ' },
  { to: '/agents', icon: <Activity size={18} />, label: 'AI Agent Activity', labelKn: 'AI ಚಟುವಟಿಕೆ' },
  { to: '/settings', icon: <Settings size={18} />, label: 'Settings', labelKn: 'ಸೆಟ್ಟಿಂಗ್ಸ್' },
];

export const Layout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { status, demoMode } = useHealthStatus();

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f9fafb' }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)',
            zIndex: 40, display: 'none',
          }}
          className="mobile-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        style={{
          width: 240,
          background: 'linear-gradient(180deg, #14532d 0%, #166534 60%, #15803d 100%)',
          display: 'flex',
          flexDirection: 'column',
          flexShrink: 0,
          position: 'sticky',
          top: 0,
          height: '100vh',
          overflowY: 'auto',
          zIndex: 50,
        }}
        className="sidebar"
      >
        {/* Logo */}
        <div
          style={{
            padding: '20px 16px 16px',
            borderBottom: '1px solid rgba(255,255,255,0.1)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div
              style={{
                width: 36, height: 36, borderRadius: 8,
                background: '#22c55e', display: 'flex',
                alignItems: 'center', justifyContent: 'center',
              }}
            >
              <Leaf size={20} color="#fff" />
            </div>
            <div>
              <div style={{ color: '#fff', fontWeight: 700, fontSize: 15, lineHeight: 1.2 }}>
                AgroMind AI
              </div>
              <div style={{ color: '#86efac', fontSize: 11 }}>Smart Farming Companion</div>
            </div>
          </div>
          {/* Status indicator */}
          <div
            style={{
              marginTop: 12, display: 'flex', alignItems: 'center', gap: 6,
              padding: '4px 8px', background: 'rgba(255,255,255,0.1)',
              borderRadius: 6,
            }}
          >
            <StatusDot status={status === 'ok' ? 'connected' : 'error'} />
            <span style={{ fontSize: 11, color: '#dcfce7' }}>
              {status === 'loading' ? 'Connecting...' : status === 'ok' ? 'Backend Connected' : 'Backend Offline'}
            </span>
            {demoMode && <DemoBadge />}
          </div>
        </div>

        {/* Nav items */}
        <nav style={{ flex: 1, padding: '12px 8px', overflow: 'auto' }}>
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '9px 10px',
                borderRadius: 8,
                marginBottom: 2,
                color: isActive ? '#fff' : '#a7f3d0',
                background: isActive ? 'rgba(255,255,255,0.15)' : 'transparent',
                fontWeight: isActive ? 600 : 400,
                fontSize: 13.5,
                textDecoration: 'none',
                transition: 'all 0.15s',
              })}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div
          style={{
            padding: '12px 16px',
            borderTop: '1px solid rgba(255,255,255,0.1)',
            color: '#a7f3d0',
            fontSize: 11,
          }}
        >
          <div>Powered by IBM Granite</div>
          <div style={{ marginTop: 2, color: '#6ee7b7' }}>watsonx.ai</div>
        </div>
      </aside>

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Top bar */}
        <header
          style={{
            background: '#fff',
            borderBottom: '1px solid #e5e7eb',
            padding: '12px 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'sticky',
            top: 0,
            zIndex: 30,
          }}
        >
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{
              display: 'none', background: 'none', border: 'none',
              padding: 4, color: '#374151',
            }}
            className="menu-btn"
          >
            {sidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {demoMode && (
              <Alert>
                <span style={{ fontSize: 12, color: '#92400e' }}>
                  🔧 Running in <strong>DEMO MODE</strong> — configure IBM Granite credentials in Settings for AI-powered responses
                </span>
              </Alert>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, color: '#6b7280' }}>
              Karnataka Agricultural Advisory Platform
            </span>
          </div>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, padding: '24px', overflowY: 'auto', maxWidth: 1200 }}>
          <Outlet />
        </main>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .sidebar { position: fixed !important; left: ${sidebarOpen ? '0' : '-260px'}; transition: left 0.3s; }
          .mobile-overlay { display: block !important; }
          .menu-btn { display: flex !important; }
        }
      `}</style>
    </div>
  );
};

// Alert for header (inline import prevention)
const Alert: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div
    style={{
      background: '#fffbeb',
      border: '1px solid #fde68a',
      borderRadius: 6,
      padding: '4px 12px',
      fontSize: 12,
    }}
  >
    {children}
  </div>
);
