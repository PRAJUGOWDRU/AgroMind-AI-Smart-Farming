// AgroMind AI — Crop & Soil Advisory Page
import React, { useState } from 'react';
import { Sprout, Leaf, FlaskConical, Calendar } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, Select, SectionHeader, LoadingSpinner } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { getCropAdvisory } from '../services/api';
import type { CropAdvisoryResult } from '../types';

const DISTRICTS = ['Mysuru', 'Davangere', 'Shimoga', 'Mandya', 'Hassan', 'Belgaum', 'Hubli-Dharwad', 'Bijapur', 'Gulbarga', 'Raichur', 'Tumkur', 'Kolar', 'Udupi'];
const SEASONS = [{ value: 'Kharif', label: 'Kharif (June–October)' }, { value: 'Rabi', label: 'Rabi (November–March)' }, { value: 'Zaid', label: 'Zaid/Summer (March–June)' }];
const SOILS = [{ value: 'red laterite', label: 'Red Laterite' }, { value: 'black cotton', label: 'Black Cotton (Vertisol)' }, { value: 'sandy loam', label: 'Sandy Loam' }, { value: 'alluvial', label: 'Alluvial' }, { value: 'clay loam', label: 'Clay Loam' }, { value: 'loam', label: 'Loam' }];
const PREFS = [{ value: 'conventional', label: 'Conventional' }, { value: 'organic', label: 'Organic' }, { value: 'integrated', label: 'Integrated (INM/IPM)' }];

export const CropSoilAdvisory: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const [district, setDistrict] = useState('Mysuru');
  const [season, setSeason] = useState('Kharif');
  const [soil, setSoil] = useState('red laterite');
  const [budget, setBudget] = useState('');
  const [pref, setPref] = useState('conventional');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CropAdvisoryResult | null>(null);
  const [error, setError] = useState('');

  const getAdvice = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getCropAdvisory({
        farmer_id: farmerId,
        state: 'Karnataka',
        district,
        season,
        soil_type: soil,
        budget: budget ? parseFloat(budget) : undefined,
        farming_preference: pref,
      });
      setResult(res.data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to get advisory');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 960 }}>
      <SectionHeader title="Crop & Soil Advisory" subtitle="Get AI-powered crop recommendations for your farm" icon={<Sprout size={18} />} />

      {/* Form */}
      <Card style={{ marginBottom: 20 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>🌾 Farm Parameters</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
          <Select label="District" value={district} onChange={(e) => setDistrict(e.target.value)} options={DISTRICTS.map((d) => ({ value: d, label: d }))} />
          <Select label="Season" value={season} onChange={(e) => setSeason(e.target.value)} options={SEASONS} />
          <Select label="Soil Type" value={soil} onChange={(e) => setSoil(e.target.value)} options={SOILS} />
          <Select label="Farming Preference" value={pref} onChange={(e) => setPref(e.target.value)} options={PREFS} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 13, fontWeight: 500, color: '#374151' }}>Budget (₹/acre)</label>
            <input type="number" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="e.g., 15000" style={{ padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, color: '#1f2937' }} />
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <Button onClick={getAdvice} loading={loading} icon={<Leaf size={16} />} size="lg">
            Get Crop Advisory
          </Button>
        </div>
      </Card>

      {error && <Alert type="error" className="mb-4">{error}</Alert>}

      {loading && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
          <LoadingSpinner size={28} />
          <p style={{ marginTop: 12, fontSize: 14 }}>Consulting agricultural knowledge base...</p>
        </div>
      )}

      {result && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {result.demo_mode && <DemoBadge />}

          {/* Recommended Crops */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>🌱 Recommended Crops</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
              {result.recommended_crops.map((crop, i) => (
                <div key={i} style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10, padding: '14px 16px' }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: '#14532d', marginBottom: 8 }}>
                    {i === 0 ? '⭐ ' : ''}{crop.name}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                    {crop.yield_estimate && <Row label="Yield" value={crop.yield_estimate} />}
                    {crop.input_cost && <Row label="Input Cost" value={crop.input_cost} />}
                    {crop.indicative_price && <Row label="Market Price" value={crop.indicative_price} />}
                    {crop.water_requirement && <Row label="Water Need" value={crop.water_requirement} />}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Nutrient Advice */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>
              <FlaskConical size={16} style={{ display: 'inline', marginRight: 6 }} />
              Nutrient Recommendations
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 10 }}>
              <NutrientCard label="Nitrogen (N)" value={result.nutrient_advice.nitrogen} color="#16a34a" />
              <NutrientCard label="Phosphorus (P)" value={result.nutrient_advice.phosphorus} color="#d97706" />
              <NutrientCard label="Potassium (K)" value={result.nutrient_advice.potassium} color="#7c3aed" />
            </div>
            <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 4 }}>{result.nutrient_advice.notes}</p>
            <p style={{ fontSize: 11, color: '#9ca3af' }}>Source: {result.nutrient_advice.source}</p>
          </Card>

          {/* Planting Calendar */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>
              <Calendar size={16} style={{ display: 'inline', marginRight: 6 }} />
              Planting Calendar
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>
              {Object.entries(result.planting_calendar).map(([k, v]) => (
                <div key={k} style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
                  <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 2, textTransform: 'capitalize' }}>{k.replace(/_/g, ' ')}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{v}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Sustainable Practices */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>♻️ Sustainable Practices</h3>
            <ul style={{ paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              {result.sustainable_practices.map((p, i) => (
                <li key={i} style={{ fontSize: 13, color: '#374151' }}>{p}</li>
              ))}
            </ul>
          </Card>

          {/* AI Advisory */}
          {result.ai_advisory && (
            <Card>
              <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>🤖 AI Advisory</h3>
              <div className="ai-response" style={{ fontSize: 14, color: '#1f2937' }}>{result.ai_advisory}</div>
            </Card>
          )}

          {/* Sources */}
          {result.sources && result.sources.length > 0 && (
            <Card>
              <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 8 }}>📚 Knowledge Sources</h3>
              {result.sources.map((s, i) => (
                <div key={i} style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>
                  • {s.title || s.organization || 'Agricultural Knowledge Base'}
                  {s.source_url && <a href={s.source_url} target="_blank" rel="noopener noreferrer" style={{ marginLeft: 4, color: '#3b82f6' }}>↗</a>}
                </div>
              ))}
            </Card>
          )}

          <Alert type="warning">
            ⚠️ These recommendations are AI-generated advisory suggestions. Always verify with your local agricultural officer, KVK, or soil test before applying fertilizers.
          </Alert>
        </div>
      )}
    </div>
  );
};

const Row: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
    <span style={{ color: '#6b7280' }}>{label}:</span>
    <span style={{ fontWeight: 600, color: '#111827' }}>{value}</span>
  </div>
);

const NutrientCard: React.FC<{ label: string; value: string; color: string }> = ({ label, value, color }) => (
  <div style={{ background: '#f9fafb', borderRadius: 8, padding: '12px', textAlign: 'center', borderTop: `3px solid ${color}` }}>
    <div style={{ fontSize: 11, color: '#6b7280' }}>{label}</div>
    <div style={{ fontSize: 16, fontWeight: 700, color, marginTop: 4 }}>{value}</div>
  </div>
);
