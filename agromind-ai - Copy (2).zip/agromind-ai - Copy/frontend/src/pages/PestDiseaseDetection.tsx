// AgroMind AI — Pest & Disease Detection Page
import React, { useState, useRef } from 'react';
import { Bug, Upload, Image, AlertTriangle } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, Textarea, SectionHeader, LoadingSpinner } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { detectDisease } from '../services/api';
import type { DetectionResult } from '../types';

const MAX_SIZE_MB = 10;

export const PestDiseaseDetection: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const [query, setQuery] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [error, setError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`Image too large. Maximum size: ${MAX_SIZE_MB}MB`);
      return;
    }
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/jpg'].includes(file.type)) {
      setError('Invalid file type. Please upload JPG, PNG, or WebP image.');
      return;
    }
    setError('');
    setImage(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const analyze = async () => {
    if (!query.trim() && !image) {
      setError('Please describe the symptoms or upload a crop image');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await detectDisease(
        query || 'Analyze this crop image for diseases or pests',
        farmerId || undefined,
        image || undefined,
      );
      setResult(res.data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const severityColor = (s: string) => {
    if (!s) return '#6b7280';
    const sl = s.toLowerCase();
    if (sl.includes('high')) return '#ef4444';
    if (sl.includes('moderate')) return '#f59e0b';
    return '#22c55e';
  };

  return (
    <div style={{ maxWidth: 920 }}>
      <SectionHeader
        title="Pest & Disease Detection"
        subtitle="Upload crop images or describe symptoms for AI-powered analysis"
        icon={<Bug size={18} />}
      />

      <Alert type="warning" className="mb-4">
        <strong>Important:</strong> AI analysis is based on symptom description and image patterns. It is NOT a definitive diagnosis.
        Always consult a qualified agronomist or your nearest KVK for confirmation before applying any treatment.
      </Alert>

      {/* Input Form */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>🔍 Describe Symptoms</h3>

        <Textarea
          label="Describe the symptoms you see on your crop"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g., Leaves are turning yellow from the bottom, brown spots with yellow halos appearing on leaves, plants wilting despite irrigation..."
          rows={4}
        />

        {/* Image Upload */}
        <div style={{ marginTop: 14 }}>
          <label style={{ fontSize: 13, fontWeight: 500, color: '#374151', display: 'block', marginBottom: 8 }}>
            📷 Upload Crop Image (optional — JPG, PNG, WebP, max {MAX_SIZE_MB}MB)
          </label>
          <div
            onClick={() => fileInput.current?.click()}
            style={{
              border: '2px dashed #d1d5db', borderRadius: 10, padding: '20px',
              textAlign: 'center', cursor: 'pointer', background: imagePreview ? '#f0fdf4' : '#f9fafb',
              transition: 'all 0.15s',
            }}
          >
            {imagePreview ? (
              <div>
                <img
                  src={imagePreview}
                  alt="Uploaded crop"
                  style={{ maxHeight: 200, maxWidth: '100%', borderRadius: 8, margin: '0 auto', display: 'block' }}
                />
                <p style={{ marginTop: 8, fontSize: 12, color: '#16a34a' }}>✓ {image?.name}</p>
              </div>
            ) : (
              <div style={{ color: '#6b7280' }}>
                <Upload size={32} style={{ margin: '0 auto 8px' }} />
                <p style={{ fontSize: 13 }}>Click to upload crop image</p>
                <p style={{ fontSize: 11 }}>JPG, PNG, WebP · Max {MAX_SIZE_MB}MB</p>
              </div>
            )}
          </div>
          <input
            ref={fileInput}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleImageChange}
            style={{ display: 'none' }}
          />
          {imagePreview && (
            <button
              onClick={() => { setImage(null); setImagePreview(null); }}
              style={{ marginTop: 6, fontSize: 12, color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer' }}
            >
              Remove image
            </button>
          )}
        </div>

        {error && <Alert type="error" className="mt-3">{error}</Alert>}

        <div style={{ marginTop: 14 }}>
          <Button
            onClick={analyze}
            loading={loading}
            icon={<Bug size={16} />}
            size="lg"
            disabled={!query.trim() && !image}
          >
            Analyze Crop
          </Button>
        </div>
      </Card>

      {loading && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
          <LoadingSpinner size={28} />
          <p style={{ marginTop: 12, fontSize: 14 }}>Analyzing symptoms and knowledge base...</p>
        </div>
      )}

      {result && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {result.demo_mode && <DemoBadge />}

          {/* Detection Result */}
          <Card style={{ borderLeft: `4px solid ${severityColor(result.severity)}` }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: '#111827' }}>
                  🔍 {result.detected_issue}
                </h3>
                <div style={{ display: 'flex', gap: 8, marginTop: 6, flexWrap: 'wrap' }}>
                  {result.possible_issues.slice(0, 3).map((issue, i) => (
                    <span key={i} style={{ fontSize: 11, background: '#f3f4f6', color: '#374151', padding: '2px 8px', borderRadius: 12 }}>
                      {issue}
                    </span>
                  ))}
                </div>
              </div>
              <div style={{ textAlign: 'center', flexShrink: 0 }}>
                <div style={{
                  background: severityColor(result.severity), color: '#fff',
                  padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 700,
                }}>
                  {result.severity} Severity
                </div>
                {result.confidence && (
                  <div style={{ fontSize: 11, color: '#6b7280', marginTop: 4 }}>{result.confidence}</div>
                )}
              </div>
            </div>

            {/* Symptoms */}
            <div style={{ marginTop: 14 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Visible Symptoms:</div>
              <ul style={{ paddingLeft: 16 }}>
                {result.symptoms.map((s, i) => <li key={i} style={{ fontSize: 13, color: '#374151', marginBottom: 4 }}>{s}</li>)}
              </ul>
            </div>
          </Card>

          {/* IPM Recommendations */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>🌿 IPM Recommendations (Preferred)</h3>
            <ul style={{ paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              {result.ipm_recommendations.map((r, i) => (
                <li key={i} style={{ fontSize: 13, color: '#374151' }}>{r}</li>
              ))}
            </ul>
          </Card>

          {/* Chemical Options */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>⚗️ Chemical Options (Last Resort)</h3>
            <Alert type="warning" className="mb-3">
              Always follow label instructions. Observe pre-harvest intervals. Rotate pesticides to prevent resistance.
            </Alert>
            <ul style={{ paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              {result.chemical_options.map((c, i) => (
                <li key={i} style={{ fontSize: 13, color: '#374151' }}>{c}</li>
              ))}
            </ul>
          </Card>

          {/* AI Advisory */}
          {result.ai_advisory && (
            <Card>
              <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>🤖 AI Detailed Advisory</h3>
              <div className="ai-response" style={{ fontSize: 14, color: '#1f2937' }}>{result.ai_advisory}</div>
            </Card>
          )}

          {/* Consult Expert */}
          {result.consult_expert && (
            <Alert type="error">
              <AlertTriangle size={16} style={{ display: 'inline', marginRight: 6 }} />
              <strong>Expert Consultation Recommended:</strong> The symptoms suggest a serious issue. Please contact your nearest KVK, agriculture officer, or plant disease diagnostic laboratory before applying any treatment.
            </Alert>
          )}

          {/* Disclaimer */}
          <Alert type="info">{result.disclaimer}</Alert>
        </div>
      )}
    </div>
  );
};
