// AgroMind AI — Ask AgroMind AI Page (Main Chat Interface)
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, RefreshCw, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, LoadingSpinner } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { sendChat } from '../services/api';
import type { ChatResponse } from '../types';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  response?: ChatResponse;
  timestamp: string;
}

const SAMPLE_QUERIES = [
  "My crop leaves are turning yellow, rainfall expected this week — what should I do?",
  "What crops should I grow this Kharif season in Mysuru?",
  "How much water does my ragi crop need at vegetative stage?",
  "What is the current market price for maize in Karnataka?",
  "How to control bollworm in cotton without using too many chemicals?",
];

const AgentBadge: React.FC<{ name: string; status: string; timeMs?: number }> = ({ name, status, timeMs }) => {
  const color = status === 'success' ? '#16a34a' : status === 'demo' ? '#d97706' : '#dc2626';
  const bg = status === 'success' ? '#f0fdf4' : status === 'demo' ? '#fffbeb' : '#fef2f2';
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 4,
        background: bg, color, fontSize: 11, fontWeight: 600,
        padding: '2px 8px', borderRadius: 12, border: `1px solid ${bg}`,
      }}
    >
      {status === 'demo' ? '⚡' : status === 'success' ? '✓' : '✗'} {name}
      {timeMs && <span style={{ color: '#9ca3af', fontWeight: 400 }}>({timeMs}ms)</span>}
    </span>
  );
};

export const AskAI: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        'Namaskara! 🌾 I am AgroMind AI, your intelligent farming companion.\n\n' +
        'I can help you with crop recommendations, soil health, weather-based irrigation, ' +
        'pest and disease identification, and market insights.\n\n' +
        'Please describe your farming situation or ask a specific question!',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [expandedAgents, setExpandedAgents] = useState<number[]>([]);
  const messagesEnd = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async (query?: string) => {
    const text = query || input.trim();
    if (!text || loading) return;
    setInput('');
    setLoading(true);

    setMessages((prev) => [
      ...prev,
      { role: 'user', content: text, timestamp: new Date().toISOString() },
    ]);

    try {
      const res = await sendChat(text, farmerId || undefined, 'en');
      const data: ChatResponse = res.data;
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: data.answer,
          response: data,
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unable to get response';
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: `❌ Error: ${msg}\n\nPlease check that the backend is running at http://localhost:8000`,
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const toggleAgents = (idx: number) => {
    setExpandedAgents((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', display: 'flex', flexDirection: 'column', height: 'calc(100vh - 120px)' }}>
      {/* Header */}
      <div style={{ marginBottom: 16 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#111827' }}>
          💬 Ask AgroMind AI
        </h1>
        <p style={{ color: '#6b7280', fontSize: 13, marginTop: 4 }}>
          Powered by IBM Granite · Multi-agent agricultural advisory · RAG-enhanced responses
        </p>
      </div>

      {/* Sample queries */}
      <div style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {SAMPLE_QUERIES.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              disabled={loading}
              style={{
                padding: '4px 10px', fontSize: 12, borderRadius: 16,
                border: '1px solid #d1d5db', background: '#fff', color: '#374151',
                cursor: 'pointer', transition: 'all 0.15s',
              }}
            >
              {q.length > 50 ? q.slice(0, 47) + '...' : q}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div
        style={{
          flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column',
          gap: 16, padding: '8px 0', minHeight: 0,
        }}
      >
        {messages.map((msg, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            {/* Avatar */}
            <div
              style={{
                width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
                background: msg.role === 'user' ? '#e0f2fe' : '#dcfce7',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              {msg.role === 'user' ? (
                <User size={16} color="#0284c7" />
              ) : (
                <Bot size={16} color="#16a34a" />
              )}
            </div>

            <div style={{ flex: 1, minWidth: 0 }}>
              {/* Message bubble */}
              <div
                style={{
                  background: msg.role === 'user' ? '#eff6ff' : '#fff',
                  border: '1px solid',
                  borderColor: msg.role === 'user' ? '#bfdbfe' : '#e5e7eb',
                  borderRadius: 12,
                  padding: '12px 16px',
                }}
              >
                <div className="ai-response" style={{ fontSize: 14, color: '#1f2937', whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </div>
              </div>

              {/* Agent details (for AI messages with response data) */}
              {msg.response && (
                <div style={{ marginTop: 8 }}>
                  {/* Demo badge */}
                  {msg.response.demo_mode && (
                    <DemoBadge />
                  )}

                  {/* Agents used */}
                  {msg.response.agents_used && msg.response.agents_used.length > 0 && (
                    <div style={{ marginTop: 6 }}>
                      <button
                        onClick={() => toggleAgents(i)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 4,
                          fontSize: 12, color: '#6b7280', background: 'none',
                          border: 'none', cursor: 'pointer', padding: 0,
                        }}
                      >
                        {expandedAgents.includes(i) ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                        Agents: {msg.response.agents_used.map((a) => (
                          <AgentBadge
                            key={a.agent_name}
                            name={a.agent_name}
                            status={a.status}
                            timeMs={a.execution_time_ms}
                          />
                        ))}
                      </button>

                      {expandedAgents.includes(i) && (
                        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
                          {msg.response.rag_sources && msg.response.rag_sources.length > 0 && (
                            <div style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
                              <div style={{ fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 6 }}>
                                📚 Knowledge Sources Retrieved:
                              </div>
                              {msg.response.rag_sources.slice(0, 3).map((s, j) => (
                                <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#6b7280', marginBottom: 4 }}>
                                  <span>•</span>
                                  <span>{s.title || 'Agricultural Knowledge'}</span>
                                  {s.source_url && (
                                    <a href={s.source_url} target="_blank" rel="noopener noreferrer">
                                      <ExternalLink size={10} />
                                    </a>
                                  )}
                                  {s.demo && <DemoBadge />}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Model used */}
                  <div style={{ marginTop: 4, fontSize: 11, color: '#9ca3af' }}>
                    Model: {msg.response.model_used} · {new Date(msg.response.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%',
              background: '#dcfce7', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Bot size={16} color="#16a34a" />
            </div>
            <div style={{
              background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12,
              padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <LoadingSpinner size={16} />
              <span style={{ fontSize: 13, color: '#6b7280' }}>
                Consulting agricultural knowledge base...
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEnd} />
      </div>

      {/* Input area */}
      <div
        style={{
          marginTop: 12, background: '#fff', border: '1px solid #e5e7eb',
          borderRadius: 12, padding: '12px 16px', display: 'flex', gap: 8, alignItems: 'flex-end',
        }}
      >
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder="Describe your farming situation or ask a question... (Press Enter to send, Shift+Enter for new line)"
          style={{
            flex: 1, border: 'none', outline: 'none', resize: 'none',
            fontSize: 14, fontFamily: 'inherit', minHeight: 44, maxHeight: 140,
            color: '#1f2937', lineHeight: 1.5,
          }}
          rows={2}
        />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <button
            onClick={() => send()}
            disabled={!input.trim() || loading}
            style={{
              width: 40, height: 40, borderRadius: 8,
              background: input.trim() && !loading ? '#16a34a' : '#e5e7eb',
              border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: input.trim() && !loading ? 'pointer' : 'not-allowed',
              transition: 'background 0.15s',
            }}
          >
            <Send size={16} color={input.trim() && !loading ? '#fff' : '#9ca3af'} />
          </button>
          <button
            onClick={() => setMessages(messages.slice(0, 1))}
            style={{
              width: 40, height: 40, borderRadius: 8,
              background: '#f3f4f6', border: 'none', display: 'flex',
              alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
            }}
            title="Clear chat"
          >
            <RefreshCw size={14} color="#6b7280" />
          </button>
        </div>
      </div>

      {!farmerId && (
        <p style={{ fontSize: 12, color: '#9ca3af', marginTop: 6, textAlign: 'center' }}>
          💡 <a href="/profile" style={{ color: '#16a34a' }}>Set up your farm profile</a> for personalized, location-specific advice.
        </p>
      )}
    </div>
  );
};
