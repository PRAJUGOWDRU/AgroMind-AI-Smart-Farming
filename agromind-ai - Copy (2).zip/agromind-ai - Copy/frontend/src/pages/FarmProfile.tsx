// AgroMind AI — Farm Profile Setup Page
import React, { useState, useEffect } from 'react';
import { User, Save, CheckCircle } from 'lucide-react';
import { Card, Alert, Input, Select, Button, SectionHeader } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { getFarmerProfile, createFarmerProfile, updateFarmerProfile } from '../services/api';
import toast from 'react-hot-toast';
import type { FarmerProfile } from '../types';

const STATES = ['Karnataka', 'Maharashtra', 'Andhra Pradesh', 'Tamil Nadu', 'Telangana', 'Kerala', 'Goa', 'Gujarat', 'Rajasthan', 'Madhya Pradesh', 'Uttar Pradesh', 'Punjab', 'Haryana', 'Bihar', 'Odisha', 'West Bengal'];
const KARNATAKA_DISTRICTS = ['Bangalore Rural', 'Bangalore Urban', 'Belgaum', 'Bellary', 'Bidar', 'Bijapur', 'Chamarajnagar', 'Chikkaballapur', 'Chikkamagaluru', 'Chitradurga', 'Dakshina Kannada', 'Davangere', 'Dharwad', 'Gadag', 'Gulbarga', 'Hassan', 'Haveri', 'Kodagu', 'Kolar', 'Koppal', 'Mandya', 'Mysuru', 'Raichur', 'Ramanagara', 'Shimoga', 'Tumkur', 'Udupi', 'Uttara Kannada', 'Vijayapura', 'Yadgir'];
const SOIL_TYPES = ['Red Laterite', 'Black Cotton (Vertisol)', 'Alluvial', 'Sandy Loam', 'Clay Loam', 'Loam', 'Sandy', 'Silty Loam'];
const WATER_SOURCES = ['Borewell', 'Open Well', 'Canal Irrigation', 'Tank Irrigation', 'River', 'Rainwater Only', 'Drip System'];
const IRRIGATION_METHODS = ['Drip Irrigation', 'Sprinkler', 'Flood Irrigation', 'Furrow Irrigation', 'Rain-fed', 'Border Strip'];
const CROPS = ['Ragi (Finger Millet)', 'Paddy (Rice)', 'Maize', 'Groundnut', 'Soybean', 'Cotton (Bt)', 'Wheat', 'Jowar (Sorghum)', 'Bajra (Pearl Millet)', 'Sunflower', 'Chickpea', 'Onion', 'Tomato', 'Sugarcane', 'Banana', 'Coconut'];
const CROP_STAGES = ['Pre-sowing', 'Seedling/Germination', 'Vegetative', 'Flowering', 'Grain-fill/Pod-fill', 'Ripening', 'Harvest-ready'];
const SEASONS = ['Kharif (June–October)', 'Rabi (November–March)', 'Zaid/Summer (March–June)', 'Year-round'];
const FARMING_PREFS = [{ value: 'conventional', label: 'Conventional Farming' }, { value: 'organic', label: 'Organic Farming' }, { value: 'integrated', label: 'Integrated Farming (INM/IPM)' }];
const LANGUAGES = [{ value: 'en', label: 'English' }, { value: 'kn', label: 'ಕನ್ನಡ (Kannada)' }, { value: 'hi', label: 'हिंदी (Hindi)' }];

const emptyProfile = (): Partial<FarmerProfile> => ({
  state: 'Karnataka',
  district: 'Mysuru',
  farm_size_unit: 'acres',
  farming_preference: 'conventional',
  preferred_language: 'en',
});

export const FarmProfile: React.FC = () => {
  const [farmerId, setFarmerId] = useLocalFarmerId();
  const [form, setForm] = useState<Partial<FarmerProfile>>(emptyProfile());
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [customFarmerId, setCustomFarmerId] = useState('');

  useEffect(() => {
    if (farmerId) {
      setLoading(true);
      getFarmerProfile(farmerId)
        .then((res) => {
          setForm(res.data);
          setCustomFarmerId(res.data.farmer_id);
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [farmerId]);

  const field = (key: keyof FarmerProfile, value: string | number) =>
    setForm((f) => ({ ...f, [key]: value }));

  const handleSave = async () => {
    if (!form.district) {
      toast.error('District is required');
      return;
    }
    setSaving(true);
    try {
      const id = farmerId || customFarmerId || `farmer_${Date.now()}`;
      const payload = { ...form, farmer_id: id };

      if (farmerId) {
        await updateFarmerProfile(farmerId, payload as Record<string, unknown>);
      } else {
        await createFarmerProfile(payload as Record<string, unknown>);
        setFarmerId(id);
      }
      setSaved(true);
      toast.success('Farm profile saved successfully!');
      setTimeout(() => setSaved(false), 3000);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 200 }}>
        <div style={{ textAlign: 'center', color: '#6b7280' }}>Loading profile...</div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 780, margin: '0 auto' }}>
      <SectionHeader
        title="My Farm Profile"
        subtitle="Provide your farm details for personalized AI recommendations"
        icon={<User size={18} />}
        action={
          <Button
            onClick={handleSave}
            loading={saving}
            icon={saved ? <CheckCircle size={16} /> : <Save size={16} />}
            variant={saved ? 'secondary' : 'primary'}
          >
            {saved ? 'Saved!' : 'Save Profile'}
          </Button>
        }
      />

      {!farmerId && (
        <Alert type="info" className="mb-5">
          You don't have a profile yet. Fill in the details below and click Save Profile to create one.
        </Alert>
      )}

      {/* Farmer ID */}
      {!farmerId && (
        <Card style={{ marginBottom: 16 }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Profile ID</h3>
          <Input
            label="Farmer ID (optional — auto-generated if empty)"
            value={customFarmerId}
            onChange={(e) => setCustomFarmerId(e.target.value)}
            placeholder="e.g., ramesh_mysuru_001"
            hint="A unique identifier for your profile. Use a memorable name."
          />
        </Card>
      )}

      {/* Section 1: Location */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, color: '#111827' }}>
          📍 Location & Farm Details
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
          <Input label="Farmer Name" value={form.name || ''} onChange={(e) => field('name', e.target.value)} placeholder="Your name (optional)" />
          <Select
            label="State *"
            value={form.state || 'Karnataka'}
            onChange={(e) => field('state', e.target.value)}
            options={STATES.map((s) => ({ value: s, label: s }))}
          />
          <Select
            label="District *"
            value={form.district || ''}
            onChange={(e) => field('district', e.target.value)}
            options={[{ value: '', label: '— Select District —' }, ...(form.state === 'Karnataka' ? KARNATAKA_DISTRICTS : [form.district || '']).map((d) => ({ value: d, label: d }))]}
          />
          <Input label="Village" value={form.village || ''} onChange={(e) => field('village', e.target.value)} placeholder="Village name" />
          <div style={{ display: 'flex', gap: 8 }}>
            <Input
              label="Farm Size"
              type="number"
              value={form.farm_size || ''}
              onChange={(e) => field('farm_size', parseFloat(e.target.value))}
              placeholder="e.g., 2.5"
              style={{ flex: 2 }}
            />
            <Select
              label="Unit"
              value={form.farm_size_unit || 'acres'}
              onChange={(e) => field('farm_size_unit', e.target.value as 'acres' | 'hectares')}
              options={[{ value: 'acres', label: 'Acres' }, { value: 'hectares', label: 'Hectares' }]}
              style={{ flex: 1 }}
            />
          </div>
        </div>
      </Card>

      {/* Section 2: Soil & Water */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, color: '#111827' }}>
          🌱 Soil & Water
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
          <Select label="Soil Type" value={form.soil_type || ''} onChange={(e) => field('soil_type', e.target.value)} options={[{ value: '', label: '— Select —' }, ...SOIL_TYPES.map((s) => ({ value: s.toLowerCase(), label: s }))]} />
          <Select label="Water Source" value={form.water_source || ''} onChange={(e) => field('water_source', e.target.value)} options={[{ value: '', label: '— Select —' }, ...WATER_SOURCES.map((s) => ({ value: s.toLowerCase(), label: s }))]} />
          <Select label="Irrigation Method" value={form.irrigation_method || ''} onChange={(e) => field('irrigation_method', e.target.value)} options={[{ value: '', label: '— Select —' }, ...IRRIGATION_METHODS.map((s) => ({ value: s.toLowerCase(), label: s }))]} />
        </div>
      </Card>

      {/* Section 3: Crop Info */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, color: '#111827' }}>
          🌾 Crop Information
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
          <Select label="Current Crop" value={form.current_crop || ''} onChange={(e) => field('current_crop', e.target.value)} options={[{ value: '', label: '— Select —' }, ...CROPS.map((c) => ({ value: c, label: c }))]} />
          <Select label="Crop Stage" value={form.crop_stage || ''} onChange={(e) => field('crop_stage', e.target.value)} options={[{ value: '', label: '— Select —' }, ...CROP_STAGES.map((s) => ({ value: s.toLowerCase(), label: s }))]} />
          <Select label="Season" value={form.season || ''} onChange={(e) => field('season', e.target.value)} options={[{ value: '', label: '— Select —' }, ...SEASONS.map((s) => ({ value: s.split(' ')[0], label: s }))]} />
          <Input label="Sowing Date" type="date" value={form.sowing_date || ''} onChange={(e) => field('sowing_date', e.target.value)} />
          <Input label="Budget (₹/acre)" type="number" value={form.budget || ''} onChange={(e) => field('budget', parseFloat(e.target.value))} placeholder="e.g., 20000" />
          <Select label="Farming Preference" value={form.farming_preference || 'conventional'} onChange={(e) => field('farming_preference', e.target.value as FarmerProfile['farming_preference'])} options={FARMING_PREFS} />
        </div>
      </Card>

      {/* Section 4: Soil Test (optional) */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 4, color: '#111827' }}>
          🧪 Soil Test Results (Optional)
        </h3>
        <p style={{ fontSize: 12, color: '#6b7280', marginBottom: 14 }}>
          Enter values from your soil health card or lab report. Leave blank if not available — AI will use general estimates.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 14 }}>
          <Input label="pH" type="number" step="0.1" min="0" max="14" value={form.soil_ph || ''} onChange={(e) => field('soil_ph', parseFloat(e.target.value))} placeholder="6.5" />
          <Input label="Nitrogen (kg/ha)" type="number" value={form.soil_nitrogen || ''} onChange={(e) => field('soil_nitrogen', parseFloat(e.target.value))} placeholder="200" />
          <Input label="Phosphorus (kg/ha)" type="number" value={form.soil_phosphorus || ''} onChange={(e) => field('soil_phosphorus', parseFloat(e.target.value))} placeholder="20" />
          <Input label="Potassium (kg/ha)" type="number" value={form.soil_potassium || ''} onChange={(e) => field('soil_potassium', parseFloat(e.target.value))} placeholder="150" />
          <Input label="EC (dS/m)" type="number" step="0.01" value={form.soil_ec || ''} onChange={(e) => field('soil_ec', parseFloat(e.target.value))} placeholder="0.5" />
        </div>
      </Card>

      {/* Language */}
      <Card style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14, color: '#111827' }}>⚙️ Preferences</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
          <Select label="Preferred Language" value={form.preferred_language || 'en'} onChange={(e) => field('preferred_language', e.target.value as FarmerProfile['preferred_language'])} options={LANGUAGES} />
        </div>
      </Card>

      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
        <Button onClick={handleSave} loading={saving} size="lg" icon={<Save size={16} />}>
          Save Farm Profile
        </Button>
      </div>

      <Alert type="info" className="mt-4">
        <strong>Privacy:</strong> Your farm profile is stored locally in the AgroMind AI database and used only to provide personalized agricultural advice.
        Uploaded images are processed temporarily and not stored permanently.
      </Alert>
    </div>
  );
};
