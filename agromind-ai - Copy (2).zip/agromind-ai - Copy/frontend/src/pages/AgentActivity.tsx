// AgroMind AI — AI Agent Activity Page
import React, { useState, useEffect } from 'react';
import { Activity, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, SectionHeader, LoadingSpinner, StatusDot } from '../components/UI';
import { useLocalFarmerId, useHistory } from '../hooks';
import { getAgentsStatus, getIntegrationsStatus } from '../services/api';

export const AgentActivity: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const { history, loading: histLoading, refresh: refreshHistory } = useHistory(farmerId);
  const [agents, setAgents] = useState<Record<string, unknown>[]>([]);
  const [integrations, setIntegrations] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);

  const loadStatus = async () => {
    setLoading(true);
    try {
      const [agentsRes, intRes] = await Promise.all([getAgentsStatus(), getIntegrationsStatus()]);
      setAgents(agentsRes.data.agents || []);
      setIntegrations(intRes.data.integrations || []);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  useEffect(() => { loadStatus(); }, []);

  const statusIcon = (status: string) => {
    if (status === 'ready' || status === 'connected' || status === 'ok') return <CheckCircle size={14} color="#16a34a" />;
    if (status === 'demo') return <Clock size={14} color="#d97706" />;
    return <XCircle size={14} color="#ef4444" />;
  };

  return (
    <div style={{ maxWidth: 960 }}>
      <SectionHeader
        title="AI Agent Activity"
        subtitle="Monitor specialized agent status, integrations, and advisory history"
        icon={<Activity size={18} />}
        action={
          <Button onClick={() => { loadStatus(); refreshHistory(); }} loading={loading} size="sm" variant="secondary" icon={<RefreshCw size={14} />}>
            Refresh
          </Button>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(440px, 1fr))', gap: 16 }}>
        {/* Agent Status */}
        <Card>
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>🤖 Agent Status</h3>
          {loading ? <LoadingSpinner size={20} /> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {agents.map((agent, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 10,
                  padding: '12px', background: '#f9fafb', borderRadius: 8,
                }}>
                  <div style={{ marginTop: 2 }}>{statusIcon(agent.status as string)}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{agent.name as string}</span>
                      <span style={{
                        fontSize: 10, fontWeight: 600,
                        background: agent.status === 'ready' ? '#dcfce7' : '#fff7ed',
                        color: agent.status === 'ready' ? '#16a34a' : '#d97706',
                        padding: '1px 6px', borderRadius: 8,
                      }}>
                        {(agent.status as string)?.toUpperCase()}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>{agent.description as string}</div>
                    {agent.note && <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2, fontStyle: 'italic' }}>{agent.note as string}</div>}
                    {(agent.capabilities as string[])?.length > 0 && (
                      <div style={{ display: 'flex', gap: 4, marginTop: 6, flexWrap: 'wrap' }}>
                        {(agent.capabilities as string[]).map((c) => (
                          <span key={c} style={{ fontSize: 10, background: '#e0f2fe', color: '#0369a1', padding: '1px 6px', borderRadius: 8 }}>{c}</span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {agents.length === 0 && <p style={{ color: '#6b7280', fontSize: 13 }}>No agent data. Backend may be offline.</p>}
            </div>
          )}
        </Card>

        {/* Integrations Status */}
        <Card>
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>🔌 Integration Status</h3>
          {loading ? <LoadingSpinner size={20} /> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {integrations.map((integ, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px', background: '#f9fafb', borderRadius: 8 }}>
                  <StatusDot status={integ.status as string} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{integ.name as string}</div>
                    <div style={{ fontSize: 12, color: '#6b7280', marginTop: 1 }}>{integ.message as string}</div>
                    {integ.model && <div style={{ fontSize: 11, color: '#9ca3af' }}>Model: {integ.model as string}</div>}
                  </div>
                  {integ.demo_mode && <DemoBadge />}
                </div>
              ))}
              {integrations.length === 0 && <p style={{ color: '#6b7280', fontSize: 13 }}>No integration data.</p>}
            </div>
          )}
        </Card>
      </div>

      {/* Advisory History */}
      <Card style={{ marginTop: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <h3 style={{ fontSize: 15, fontWeight: 600 }}>📜 Advisory History</h3>
          {histLoading && <LoadingSpinner size={16} />}
        </div>
        {history.length === 0 ? (
          <Alert type="info">No advisory history yet. Start by asking AgroMind AI a farming question.</Alert>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {history.map((item) => (
              <div key={item.id} style={{
                padding: '12px 14px', background: '#f9fafb', borderRadius: 8,
                border: '1px solid #f3f4f6',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>
                    Q: {item.query.slice(0, 100)}{item.query.length > 100 ? '...' : ''}
                  </span>
                  {item.demo_mode && <DemoBadge />}
                </div>
                <div style={{ fontSize: 12, color: '#6b7280' }}>{item.response_preview.slice(0, 160)}...</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                  <span style={{ fontSize: 11, color: '#9ca3af' }}>{new Date(item.created_at).toLocaleString()}</span>
                  {item.agents_used && (
                    <span style={{ fontSize: 11, color: '#6b7280' }}>
                      Agents: {Array.isArray(item.agents_used) ? item.agents_used.join(', ') : item.agents_used}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};
