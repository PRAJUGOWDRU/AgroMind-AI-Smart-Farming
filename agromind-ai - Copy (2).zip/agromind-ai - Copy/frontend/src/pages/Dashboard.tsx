// AgroMind AI — Dashboard Page
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Sprout, CloudRain, Bug, TrendingUp, MessageSquare,
  MapPin, Thermometer, Droplets, AlertTriangle, ChevronRight,
  Sun, Wind,
} from 'lucide-react';
import { Card, Alert, DemoBadge, LoadingSpinner } from '../components/UI';
import { useLocalFarmerId, useHealthStatus } from '../hooks';
import { getFarmerProfile, getIrrigationAdvisory, getMarketInsights } from '../services/api';
import type { FarmerProfile, WeatherData } from '../types';

const QUICK_ACTIONS = [
  { to: '/ask', icon: <MessageSquare size={20} />, label: 'Ask AI Advisor', color: '#16a34a', bg: '#dcfce7' },
  { to: '/crop', icon: <Sprout size={20} />, label: 'Crop Advisory', color: '#0284c7', bg: '#e0f2fe' },
  { to: '/weather', icon: <CloudRain size={20} />, label: 'Weather & Irrigation', color: '#7c3aed', bg: '#ede9fe' },
  { to: '/detection', icon: <Bug size={20} />, label: 'Disease Detection', color: '#d97706', bg: '#fef3c7' },
  { to: '/market', icon: <TrendingUp size={20} />, label: 'Market Prices', color: '#dc2626', bg: '#fee2e2' },
];

export const Dashboard: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const { demoMode } = useHealthStatus();
  const [profile, setProfile] = useState<FarmerProfile | null>(null);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (farmerId) {
      getFarmerProfile(farmerId)
        .then((res) => setProfile(res.data))
        .catch(() => {});
    }
  }, [farmerId]);

  useEffect(() => {
    if (profile) {
      setLoading(true);
      getIrrigationAdvisory({
        location: `${profile.district}, ${profile.state}`,
        crop: profile.current_crop,
        crop_stage: profile.crop_stage,
        farmer_id: farmerId,
      })
        .then((res) => setWeather(res.data?.weather_summary || null))
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [profile, farmerId]);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  })();

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 700, color: '#111827' }}>
              {greeting}, {profile?.name || 'Farmer'} 👋
            </h1>
            <p style={{ color: '#6b7280', marginTop: 4, fontSize: 14 }}>
              Your personalized agricultural advisory dashboard
            </p>
          </div>
          {demoMode && <DemoBadge />}
        </div>
      </div>

      {/* Farm Profile Summary */}
      {profile ? (
        <Card style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#111827' }}>
              📍 Your Farm
            </h3>
            <Link to="/profile" style={{ fontSize: 13, color: '#16a34a', display: 'flex', alignItems: 'center', gap: 4 }}>
              Edit Profile <ChevronRight size={14} />
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
            {[
              { icon: <MapPin size={14} />, label: 'Location', value: `${profile.district}, ${profile.state}` },
              { icon: <Sprout size={14} />, label: 'Current Crop', value: profile.current_crop || 'Not set' },
              { icon: <Sun size={14} />, label: 'Season', value: profile.season || 'Not set' },
              { icon: <Droplets size={14} />, label: 'Irrigation', value: profile.irrigation_method || 'Not set' },
              { icon: <span style={{ fontSize: 14 }}>🌱</span>, label: 'Crop Stage', value: profile.crop_stage || 'Not set' },
              { icon: <span style={{ fontSize: 14 }}>🌾</span>, label: 'Farm Size', value: profile.farm_size ? `${profile.farm_size} ${profile.farm_size_unit}` : 'Not set' },
            ].map((item, i) => (
              <div key={i} style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#6b7280', fontSize: 11, marginBottom: 4 }}>
                  {item.icon} {item.label}
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{item.value}</div>
              </div>
            ))}
          </div>
        </Card>
      ) : (
        <Alert type="info" className="mb-5">
          <div>
            👤 No farm profile found.{' '}
            <Link to="/profile" style={{ fontWeight: 600, color: '#1e40af' }}>
              Set up your profile
            </Link>{' '}
            for personalized recommendations.
          </div>
        </Alert>
      )}

      {/* Quick Actions */}
      <div style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#111827', marginBottom: 12 }}>
          ⚡ Quick Actions
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
          {QUICK_ACTIONS.map((action) => (
            <Link
              key={action.to}
              to={action.to}
              style={{
                background: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: 12,
                padding: '16px 14px',
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                textDecoration: 'none',
                transition: 'box-shadow 0.15s',
              }}
            >
              <div
                style={{
                  width: 40, height: 40, borderRadius: 10,
                  background: action.bg, display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                  color: action.color, flexShrink: 0,
                }}
              >
                {action.icon}
              </div>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>
                {action.label}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {/* Weather Widget */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20, marginBottom: 24 }}>
        <Card>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#111827' }}>🌤 Weather</h3>
            {loading && <LoadingSpinner size={16} />}
            {weather?.demo && <DemoBadge />}
          </div>
          {weather ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, marginBottom: 8 }}>
                <span style={{ fontSize: 36, fontWeight: 700, color: '#111827' }}>
                  {Math.round(weather.temperature)}°C
                </span>
                <span style={{ fontSize: 13, color: '#6b7280', paddingBottom: 6 }}>
                  {weather.description}
                </span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                <Stat icon={<Droplets size={14} />} label="Humidity" value={`${weather.humidity}%`} />
                <Stat icon={<CloudRain size={14} />} label="Rain Prob." value={`${weather.rain_probability}%`} />
                <Stat icon={<Wind size={14} />} label="Wind" value={`${Math.round(weather.wind_speed || 0)} km/h`} />
              </div>
              {(weather.rain_probability || 0) > 60 && (
                <Alert type="warning" className="mt-3">
                  ⚠️ High rainfall probability — consider delaying irrigation and checking field drainage.
                </Alert>
              )}
            </div>
          ) : (
            <div style={{ color: '#6b7280', fontSize: 13, textAlign: 'center', padding: '20px 0' }}>
              {loading ? 'Loading weather...' : 'Set location in profile to see weather'}
            </div>
          )}
        </Card>

        {/* Recommendations Card */}
        <Card>
          <h3 style={{ fontSize: 15, fontWeight: 600, color: '#111827', marginBottom: 12 }}>
            💡 Recommended Actions
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { icon: '🌱', text: 'Apply recommended fertilizers based on crop stage', priority: 'medium' },
              { icon: '💧', text: 'Check soil moisture before next irrigation', priority: 'low' },
              { icon: '🔍', text: 'Monitor for early signs of leaf blight', priority: 'high' },
              { icon: '📊', text: 'Review market prices before harvest planning', priority: 'medium' },
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: 8,
                  padding: '8px 10px', borderRadius: 8,
                  background: item.priority === 'high' ? '#fff7ed' : '#f9fafb',
                  border: `1px solid ${item.priority === 'high' ? '#fed7aa' : '#f3f4f6'}`,
                }}
              >
                <span style={{ fontSize: 16 }}>{item.icon}</span>
                <span style={{ fontSize: 13, color: '#374151' }}>{item.text}</span>
              </div>
            ))}
          </div>
          <Link
            to="/ask"
            style={{
              display: 'block', marginTop: 12, textAlign: 'center',
              padding: '8px', background: '#f0fdf4', borderRadius: 8,
              color: '#16a34a', fontSize: 13, fontWeight: 600, textDecoration: 'none',
            }}
          >
            Get personalized advice from AI →
          </Link>
        </Card>
      </div>

      {/* Disclaimer */}
      <Alert type="info">
        <strong>Disclaimer:</strong> AgroMind AI provides advisory support only. Recommendations should be verified with qualified agricultural experts. 
        AI suggestions do not replace professional agricultural advice. Always consult your nearest KVK or agriculture officer for critical decisions.
      </Alert>
    </div>
  );
};

const Stat: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
  <div style={{ textAlign: 'center', padding: '6px', background: '#f9fafb', borderRadius: 6 }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, color: '#6b7280', fontSize: 11 }}>
      {icon} {label}
    </div>
    <div style={{ fontSize: 14, fontWeight: 600, color: '#111827', marginTop: 2 }}>{value}</div>
  </div>
);
