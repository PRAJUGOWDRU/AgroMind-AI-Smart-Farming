// AgroMind AI — Settings & API Configuration Page
import React, { useState } from 'react';
import { Settings, CheckCircle, XCircle, RefreshCw, Eye, EyeOff } from 'lucide-react';
import { Card, Alert, Input, Button, SectionHeader, DemoBadge, StatusDot } from '../components/UI';
import { useIntegrations } from '../hooks';
import { testGraniteConnection } from '../services/api';

export const SettingsPage: React.FC = () => {
  const { integrations, loading, refresh } = useIntegrations();
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<Record<string, unknown> | null>(null);

  const testGranite = async () => {
    setTestLoading(true);
    try {
      const res = await testGraniteConnection();
      setTestResult(res.data);
    } catch (err: unknown) {
      setTestResult({ success: false, message: err instanceof Error ? err.message : 'Test failed' });
    } finally { setTestLoading(false); }
  };

  const graniteInteg = integrations.find((i) => i.name?.toString().includes('Granite'));

  return (
    <div style={{ maxWidth: 800 }}>
      <SectionHeader
        title="Settings & API Configuration"
        subtitle="Configure IBM Granite, weather, and market data integrations"
        icon={<Settings size={18} />}
      />

      {/* IBM Granite Status */}
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <h3 style={{ fontSize: 15, fontWeight: 600 }}>🤖 IBM Granite (watsonx.ai)</h3>
          <div style={{ display: 'flex', gap: 8 }}>
            {graniteInteg && <StatusDot status={graniteInteg.status as string} />}
            {graniteInteg?.demo_mode && <DemoBadge />}
          </div>
        </div>

        {graniteInteg?.demo_mode ? (
          <Alert type="warning" className="mb-4">
            IBM Granite is not configured. The application is running in DEMO MODE with realistic sample responses.
            To enable AI-powered responses, configure the environment variables below.
          </Alert>
        ) : (
          <Alert type="success" className="mb-4">
            ✅ IBM Granite connected — Model: {graniteInteg?.model as string}
          </Alert>
        )}

        <div style={{ background: '#1e1e1e', borderRadius: 8, padding: '16px', marginBottom: 14, fontFamily: 'monospace' }}>
          <div style={{ color: '#9ca3af', fontSize: 12, marginBottom: 8 }}># backend/.env — Required environment variables</div>
          {[
            { key: 'WATSONX_API_KEY', value: 'your_ibm_watsonx_api_key_here', desc: 'IBM Cloud API key' },
            { key: 'WATSONX_PROJECT_ID', value: 'your_ibm_watsonx_project_id_here', desc: 'watsonx.ai project ID' },
            { key: 'WATSONX_URL', value: 'https://us-south.ml.cloud.ibm.com', desc: 'watsonx.ai endpoint' },
            { key: 'WATSONX_MODEL_ID', value: 'ibm/granite-13b-chat-v2', desc: 'Granite model ID' },
          ].map(({ key, value, desc }) => (
            <div key={key} style={{ marginBottom: 4 }}>
              <span style={{ color: '#86efac' }}>{key}</span>
              <span style={{ color: '#d1d5db' }}>=</span>
              <span style={{ color: '#fcd34d' }}>{value}</span>
              <span style={{ color: '#6b7280' }}> # {desc}</span>
            </div>
          ))}
        </div>

        <div style={{ marginBottom: 12 }}>
          <Button onClick={testGranite} loading={testLoading} size="sm" variant="outline" icon={<RefreshCw size={14} />}>
            Test Connection
          </Button>
        </div>

        {testResult && (
          <Alert type={testResult.success ? 'success' : 'warning'}>
            {testResult.success ? '✅ Connection successful!' : '⚡ ' + (testResult.message as string)}
            {testResult.sample_response && (
              <div style={{ marginTop: 6, fontSize: 12, color: '#374151', borderTop: '1px solid #fde68a', paddingTop: 6 }}>
                Sample: {testResult.sample_response as string}
              </div>
            )}
          </Alert>
        )}

        <div style={{ marginTop: 14 }}>
          <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Setup Instructions:</h4>
          <ol style={{ paddingLeft: 20, fontSize: 13, color: '#374151', lineHeight: 1.8 }}>
            <li>Go to <a href="https://cloud.ibm.com/catalog/services/watsonx-ai" target="_blank" rel="noopener noreferrer">IBM Cloud watsonx.ai</a></li>
            <li>Create a new project or use an existing one</li>
            <li>Copy your Project ID from the project settings</li>
            <li>Generate an API key from IBM Cloud → Manage → IAM → API keys</li>
            <li>Copy the values into <code>backend/.env</code></li>
            <li>Restart the backend: <code>uvicorn app.main:app --reload</code></li>
          </ol>
        </div>
      </Card>

      {/* All Integrations */}
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <h3 style={{ fontSize: 15, fontWeight: 600 }}>🔌 Integration Status</h3>
          <Button onClick={refresh} loading={loading} size="sm" variant="secondary" icon={<RefreshCw size={14} />}>Refresh</Button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {integrations.map((integ, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px',
              background: '#f9fafb', borderRadius: 8, border: '1px solid #f3f4f6',
            }}>
              <StatusDot status={integ.status as string} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{integ.name as string}</div>
                <div style={{ fontSize: 12, color: '#6b7280' }}>{integ.message as string}</div>
              </div>
              {integ.demo_mode ? (
                <DemoBadge />
              ) : (
                <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#16a34a' }}>
                  <CheckCircle size={12} /> Live
                </span>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Weather API */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>🌤 Weather API (OpenWeatherMap)</h3>
        <div style={{ background: '#1e1e1e', borderRadius: 8, padding: '12px 16px', fontFamily: 'monospace', marginBottom: 12 }}>
          <span style={{ color: '#86efac' }}>OPENWEATHER_API_KEY</span>
          <span style={{ color: '#d1d5db' }}>=</span>
          <span style={{ color: '#fcd34d' }}>your_openweather_api_key_here</span>
        </div>
        <p style={{ fontSize: 13, color: '#6b7280' }}>
          Get a free API key at <a href="https://openweathermap.org/api" target="_blank" rel="noopener noreferrer">openweathermap.org</a>.
          The free plan supports current weather and 5-day forecasts. Without this key, demo weather data is used.
        </p>
      </Card>

      {/* Market API */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>📊 Market Data (AGMARKNET / data.gov.in)</h3>
        <div style={{ background: '#1e1e1e', borderRadius: 8, padding: '12px 16px', fontFamily: 'monospace', marginBottom: 12 }}>
          <span style={{ color: '#86efac' }}>AGMARKNET_API_KEY</span>
          <span style={{ color: '#d1d5db' }}>=</span>
          <span style={{ color: '#fcd34d' }}>your_data_gov_in_api_key_here</span>
        </div>
        <p style={{ fontSize: 13, color: '#6b7280' }}>
          Register at <a href="https://data.gov.in" target="_blank" rel="noopener noreferrer">data.gov.in</a> for AGMARKNET price data.
          Without this key, Karnataka APMC indicative prices from demo data are used.
        </p>
      </Card>

      {/* Demo Mode Notice */}
      <Alert type="info">
        <strong>Demo Mode:</strong> AgroMind AI is fully functional in demo mode. All features work with realistic Karnataka
        agricultural data. Configure IBM Granite credentials to enable AI-powered responses using IBM watsonx.ai.
        The DEMO badge is clearly shown whenever demo data is being used.
      </Alert>
    </div>
  );
};
