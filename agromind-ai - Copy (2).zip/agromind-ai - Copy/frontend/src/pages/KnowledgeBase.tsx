// AgroMind AI — Knowledge Base Page
import React, { useState, useEffect } from 'react';
import { BookOpen, Upload, Search, RefreshCw } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, Input, Select, Textarea, SectionHeader, LoadingSpinner } from '../components/UI';
import { queryRAG, uploadKnowledgeDocument, getKnowledgeSources } from '../services/api';

export const KnowledgeBase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'search' | 'sources' | 'upload'>('search');
  const [query, setQuery] = useState('');
  const [ragResult, setRagResult] = useState<Record<string, unknown> | null>(null);
  const [queryLoading, setQueryLoading] = useState(false);
  const [sources, setSources] = useState<Record<string, unknown>[]>([]);
  const [sourcesLoading, setSourcesLoading] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    title: '', organization: '', crop: '', state: 'Karnataka', source_url: '', language: 'en'
  });
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState('');
  const [error, setError] = useState('');

  const loadSources = async () => {
    setSourcesLoading(true);
    try {
      const res = await getKnowledgeSources();
      setSources(res.data.sources || []);
    } catch { setSources([]); }
    finally { setSourcesLoading(false); }
  };

  useEffect(() => { loadSources(); }, []);

  const doQuery = async () => {
    if (!query.trim()) return;
    setQueryLoading(true);
    setError('');
    try {
      const res = await queryRAG(query, undefined, 'Karnataka', 5);
      setRagResult(res.data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Query failed');
    } finally { setQueryLoading(false); }
  };

  const doUpload = async () => {
    if (!uploadFile || !uploadForm.title) {
      setError('Title and file are required');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const fd = new FormData();
      Object.entries(uploadForm).forEach(([k, v]) => { if (v) fd.append(k, v); });
      fd.append('file', uploadFile);
      const res = await uploadKnowledgeDocument(fd);
      setUploadMsg(`✅ ${res.data.title} — ${res.data.chunks_indexed} chunks indexed`);
      setUploadFile(null);
      setUploadForm({ title: '', organization: '', crop: '', state: 'Karnataka', source_url: '', language: 'en' });
      loadSources();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally { setUploading(false); }
  };

  return (
    <div style={{ maxWidth: 960 }}>
      <SectionHeader
        title="Knowledge Base"
        subtitle="Agricultural knowledge, government advisories, and RAG-powered search"
        icon={<BookOpen size={18} />}
      />

      {/* Tab Nav */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: '#f3f4f6', padding: 4, borderRadius: 8, width: 'fit-content' }}>
        {(['search', 'sources', 'upload'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            style={{
              padding: '6px 16px', borderRadius: 6, border: 'none', fontSize: 13, fontWeight: 500,
              background: activeTab === t ? '#fff' : 'transparent',
              color: activeTab === t ? '#111827' : '#6b7280',
              cursor: 'pointer', boxShadow: activeTab === t ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
            }}
          >
            {t === 'search' ? '🔍 Search' : t === 'sources' ? '📚 Sources' : '📤 Upload'}
          </button>
        ))}
      </div>

      {/* Search Tab */}
      {activeTab === 'search' && (
        <div>
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>RAG-Powered Knowledge Search</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') doQuery(); }}
                placeholder="e.g., How to manage blast disease in ragi?"
                style={{
                  flex: 1, padding: '10px 14px', border: '1px solid #d1d5db',
                  borderRadius: 8, fontSize: 14, outline: 'none',
                }}
              />
              <Button onClick={doQuery} loading={queryLoading} icon={<Search size={16} />}>
                Search
              </Button>
            </div>
          </Card>

          {error && <Alert type="error" className="mb-4">{error}</Alert>}
          {queryLoading && <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}><LoadingSpinner size={24} /></div>}

          {ragResult && !queryLoading && (
            <div>
              {ragResult.demo_mode && <DemoBadge />}
              <Card style={{ marginBottom: 14 }}>
                <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 10 }}>🤖 AI Answer</h3>
                <div className="ai-response" style={{ fontSize: 14, color: '#1f2937' }}>{ragResult.answer as string}</div>
              </Card>

              {(ragResult.sources as Record<string, unknown>[])?.length > 0 && (
                <Card>
                  <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 10 }}>📚 Retrieved Sources</h3>
                  {(ragResult.sources as Record<string, unknown>[]).map((s, i) => (
                    <div key={i} style={{ borderBottom: i < (ragResult.sources as unknown[]).length - 1 ? '1px solid #f3f4f6' : 'none', paddingBottom: 12, marginBottom: 12 }}>
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{s.title as string}</div>
                          {s.organization && <div style={{ fontSize: 12, color: '#6b7280' }}>by {s.organization as string}</div>}
                          <div style={{ fontSize: 12, color: '#374151', marginTop: 6 }}>{(s.text as string)?.slice(0, 200)}...</div>
                          {s.source_url && <a href={s.source_url as string} target="_blank" rel="noopener noreferrer" style={{ fontSize: 12, color: '#3b82f6', marginTop: 4, display: 'block' }}>View Source ↗</a>}
                        </div>
                        {s.demo && <DemoBadge />}
                        {s.relevance && <span style={{ fontSize: 11, color: '#6b7280', flexShrink: 0 }}>Relevance: {Math.round((s.relevance as number) * 100)}%</span>}
                      </div>
                    </div>
                  ))}
                </Card>
              )}
            </div>
          )}
        </div>
      )}

      {/* Sources Tab */}
      {activeTab === 'sources' && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600 }}>Indexed Knowledge Sources ({sources.length})</h3>
            <Button onClick={loadSources} loading={sourcesLoading} size="sm" variant="secondary" icon={<RefreshCw size={14} />}>Refresh</Button>
          </div>
          <Alert type="info" className="mb-4">
            These are trusted agricultural knowledge sources indexed in the RAG pipeline.
            The sample corpus includes ICAR, KVK Karnataka, IMD, and APMC guidelines.
          </Alert>
          {sourcesLoading ? <LoadingSpinner size={24} /> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {sources.map((s, i) => (
                <Card key={i} padding="14px 16px">
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{s.title as string}</div>
                      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>
                        {s.organization as string} · {(s.source_type as string)?.toUpperCase()}
                        {s.crop && ` · Crop: ${s.crop}`}
                        {s.state && ` · ${s.state}`}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: 11, color: '#6b7280' }}>{s.chunk_count as number} chunks</span>
                      <span style={{ fontSize: 11, background: s.indexed ? '#f0fdf4' : '#fff7ed', color: s.indexed ? '#16a34a' : '#d97706', padding: '2px 6px', borderRadius: 4 }}>
                        {s.indexed ? '✓ Indexed' : '⏳ Pending'}
                      </span>
                    </div>
                  </div>
                </Card>
              ))}
              {sources.length === 0 && <p style={{ color: '#6b7280', textAlign: 'center', padding: '20px' }}>No sources found. Backend sample corpus will be loaded on startup.</p>}
            </div>
          )}
        </div>
      )}

      {/* Upload Tab */}
      {activeTab === 'upload' && (
        <div>
          <Alert type="info" className="mb-4">
            Upload agricultural documents (PDF, TXT, Markdown) to expand the knowledge base.
            Only upload from trusted, verifiable sources.
          </Alert>
          {uploadMsg && <Alert type="success" className="mb-4">{uploadMsg}</Alert>}
          {error && <Alert type="error" className="mb-4">{error}</Alert>}

          <Card>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 14 }}>
              <Input label="Document Title *" value={uploadForm.title} onChange={(e) => setUploadForm(f => ({...f, title: e.target.value}))} placeholder="e.g., ICAR Ragi Cultivation Guide" />
              <Input label="Organization" value={uploadForm.organization} onChange={(e) => setUploadForm(f => ({...f, organization: e.target.value}))} placeholder="e.g., ICAR" />
              <Input label="Crop (if applicable)" value={uploadForm.crop} onChange={(e) => setUploadForm(f => ({...f, crop: e.target.value}))} placeholder="e.g., Ragi" />
              <Input label="State" value={uploadForm.state} onChange={(e) => setUploadForm(f => ({...f, state: e.target.value}))} placeholder="Karnataka" />
              <Input label="Source URL" value={uploadForm.source_url} onChange={(e) => setUploadForm(f => ({...f, source_url: e.target.value}))} placeholder="https://..." />
              <Select label="Language" value={uploadForm.language} onChange={(e) => setUploadForm(f => ({...f, language: e.target.value}))} options={[{value:'en',label:'English'},{value:'kn',label:'Kannada'},{value:'hi',label:'Hindi'}]} />
            </div>

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 13, fontWeight: 500, color: '#374151', display: 'block', marginBottom: 6 }}>
                Document File * (PDF, TXT, Markdown)
              </label>
              <input
                type="file"
                accept=".pdf,.txt,.md"
                onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                style={{ fontSize: 13, color: '#374151' }}
              />
              {uploadFile && <p style={{ fontSize: 12, color: '#16a34a', marginTop: 4 }}>✓ {uploadFile.name}</p>}
            </div>

            <Button onClick={doUpload} loading={uploading} icon={<Upload size={16} />}>
              Upload & Index Document
            </Button>
          </Card>
        </div>
      )}
    </div>
  );
};
