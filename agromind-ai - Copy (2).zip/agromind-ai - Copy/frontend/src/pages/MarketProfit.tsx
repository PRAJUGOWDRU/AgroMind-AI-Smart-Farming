// AgroMind AI — Market & Profit Insights Page
import React, { useState } from 'react';
import { TrendingUp, IndianRupee } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, Select, SectionHeader, LoadingSpinner, Input } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { getMarketInsights } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import type { MarketInsight } from '../types';

const CROPS = ['Ragi', 'Paddy', 'Maize', 'Groundnut', 'Cotton', 'Soybean', 'Wheat', 'Jowar', 'Sunflower', 'Chickpea', 'Onion', 'Tomato'];
const DISTRICTS = ['Mysuru', 'Davangere', 'Shimoga', 'Mandya', 'Hassan', 'Belgaum', 'Hubli-Dharwad', 'Bijapur', 'Gulbarga', 'Raichur', 'Tumkur', 'Kolar'];

const TREND_ICON: Record<string, string> = { rising: '📈', falling: '📉', stable: '➡️', volatile: '⚡', unknown: '❓' };

export const MarketProfit: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const [crop, setCrop] = useState('Ragi');
  const [district, setDistrict] = useState('Mysuru');
  const [farmSize, setFarmSize] = useState('2');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MarketInsight | null>(null);
  const [error, setError] = useState('');

  const fetchInsights = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await getMarketInsights({
        crop,
        district,
        state: 'Karnataka',
        farm_size: parseFloat(farmSize) || 1,
        farm_size_unit: 'acres',
      });
      setResult(res.data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to get market insights');
    } finally {
      setLoading(false);
    }
  };

  const profitColor = result && result.farm_analysis.net_profit >= 0 ? '#16a34a' : '#ef4444';

  const costChartData = result ? [
    { name: 'Seeds', value: result.cost_breakdown.seeds_per_acre as number },
    { name: 'Fertilizer', value: result.cost_breakdown.fertilizer_per_acre as number },
    { name: 'Pesticide', value: result.cost_breakdown.pesticide_per_acre as number },
    { name: 'Labour', value: result.cost_breakdown.labour_per_acre as number },
    { name: 'Irrigation', value: result.cost_breakdown.irrigation_per_acre as number },
  ] : [];

  return (
    <div style={{ maxWidth: 1000 }}>
      <SectionHeader
        title="Market & Profit Insights"
        subtitle="Current APMC prices, cost analysis, and profitability estimation"
        icon={<TrendingUp size={18} />}
      />

      {/* Form */}
      <Card style={{ marginBottom: 20 }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 14 }}>📊 Analysis Parameters</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
          <Select label="Crop" value={crop} onChange={(e) => setCrop(e.target.value)} options={CROPS.map((c) => ({ value: c, label: c }))} />
          <Select label="District (Nearest APMC)" value={district} onChange={(e) => setDistrict(e.target.value)} options={DISTRICTS.map((d) => ({ value: d, label: d }))} />
          <Input label="Farm Size (acres)" type="number" value={farmSize} onChange={(e) => setFarmSize(e.target.value)} placeholder="e.g., 2" min="0.1" step="0.5" />
        </div>
        <div style={{ marginTop: 14 }}>
          <Button onClick={fetchInsights} loading={loading} icon={<TrendingUp size={16} />} size="lg">
            Get Market Insights
          </Button>
        </div>
      </Card>

      {error && <Alert type="error" className="mb-4">{error}</Alert>}
      {loading && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
          <LoadingSpinner size={28} />
          <p style={{ marginTop: 12, fontSize: 14 }}>Retrieving market data...</p>
        </div>
      )}

      {result && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {result.demo_mode && <DemoBadge />}

          {/* Price Summary */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
            <Card>
              <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>Current APMC Price</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: '#111827' }}>
                ₹{result.current_price?.toLocaleString()}
              </div>
              <div style={{ fontSize: 12, color: '#6b7280' }}>{result.price_unit}</div>
              <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>{result.market_name}</div>
              <div style={{ marginTop: 6, fontSize: 13, fontWeight: 600 }}>
                {TREND_ICON[result.price_trend || 'unknown']} {result.price_trend || 'Unknown'} trend
              </div>
            </Card>
            {result.msp && (
              <Card>
                <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>Minimum Support Price (MSP)</div>
                <div style={{ fontSize: 28, fontWeight: 700, color: '#16a34a' }}>₹{result.msp.toLocaleString()}</div>
                <div style={{ fontSize: 12, color: '#6b7280' }}>{result.price_unit}</div>
                <div style={{
                  marginTop: 8, fontSize: 12,
                  background: result.msp > (result.current_price || 0) ? '#dcfce7' : '#fee2e2',
                  color: result.msp > (result.current_price || 0) ? '#14532d' : '#991b1b',
                  padding: '4px 8px', borderRadius: 6,
                }}>
                  {result.msp > (result.current_price || 0) ? '⬆️ MSP > Market Price — sell via procurement' : '✓ Market price above MSP'}
                </div>
              </Card>
            )}
            <Card>
              <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>Est. Net Profit</div>
              <div style={{ fontSize: 28, fontWeight: 700, color: profitColor }}>
                ₹{result.farm_analysis.net_profit.toLocaleString()}
              </div>
              <div style={{ fontSize: 12, color: '#6b7280' }}>for {result.farm_analysis.farm_size_acres} acres</div>
              <div style={{ fontSize: 13, marginTop: 4 }}>
                ROI: <strong style={{ color: profitColor }}>{result.farm_analysis.roi_percent}%</strong>
              </div>
            </Card>
          </div>

          {/* Farm Financial Analysis */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>💰 Financial Analysis — {result.crop} ({result.farm_analysis.farm_size_acres} acres)</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10, marginBottom: 14 }}>
              <FinanceCard label="Expected Yield" value={`${result.farm_analysis.expected_yield_quintals} qtl`} icon="🌾" />
              <FinanceCard label="Gross Revenue" value={`₹${result.farm_analysis.gross_revenue.toLocaleString()}`} icon="💵" color="#16a34a" />
              <FinanceCard label="Total Cost" value={`₹${result.farm_analysis.cultivation_cost.toLocaleString()}`} icon="📋" color="#ef4444" />
              <FinanceCard label="Net Profit" value={`₹${result.farm_analysis.net_profit.toLocaleString()}`} icon="📈" color={profitColor} />
            </div>
          </Card>

          {/* Cost Breakdown Chart */}
          {costChartData.length > 0 && (
            <Card>
              <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 14 }}>📊 Cost Breakdown (per acre)</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={costChartData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${(v/1000).toFixed(0)}K`} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={70} />
                  <Tooltip formatter={(v: number) => [`₹${v.toLocaleString()}`, 'Cost']} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {costChartData.map((_, idx) => (
                      <Cell key={idx} fill={['#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#60a5fa'][idx % 5]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 6 }}>{result.cost_breakdown.note as string}</p>
            </Card>
          )}

          {/* Marketing Options */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 10 }}>🏪 Marketing Options</h3>
            {result.marketing_options.map((opt, i) => (
              <div key={i} style={{
                padding: '8px 12px', borderRadius: 8, marginBottom: 6,
                background: '#f9fafb', border: '1px solid #f3f4f6', fontSize: 13, color: '#374151',
              }}>
                {opt}
              </div>
            ))}
          </Card>

          {/* Sell Recommendation */}
          {(result as unknown as Record<string, unknown>)['sell_recommendation'] && (
            <Alert type="success">
              <strong>💡 Sell Recommendation:</strong> {String((result as unknown as Record<string, unknown>)['sell_recommendation'])}
            </Alert>
          )}

          <Alert type="warning">{result.disclaimer}</Alert>
        </div>
      )}
    </div>
  );
};

const FinanceCard: React.FC<{ label: string; value: string; icon: string; color?: string }> = ({ label, value, icon, color = '#111827' }) => (
  <div style={{ background: '#f9fafb', borderRadius: 10, padding: '14px 12px', textAlign: 'center' }}>
    <div style={{ fontSize: 22 }}>{icon}</div>
    <div style={{ fontSize: 16, fontWeight: 700, color, marginTop: 4 }}>{value}</div>
    <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{label}</div>
  </div>
);
