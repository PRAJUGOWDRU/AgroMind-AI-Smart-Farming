// AgroMind AI — Weather & Irrigation Page
import React, { useState, useEffect } from 'react';
import { CloudRain, Droplets, Wind, Thermometer, Sun } from 'lucide-react';
import { Card, Alert, DemoBadge, Button, SectionHeader, LoadingSpinner } from '../components/UI';
import { useLocalFarmerId } from '../hooks';
import { getIrrigationAdvisory, getFarmerProfile } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import type { FarmerProfile } from '../types';

export const WeatherIrrigation: React.FC = () => {
  const [farmerId] = useLocalFarmerId();
  const [profile, setProfile] = useState<FarmerProfile | null>(null);
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (farmerId) {
      getFarmerProfile(farmerId).then((r) => setProfile(r.data)).catch(() => {});
    }
  }, [farmerId]);

  const fetchWeather = async () => {
    setLoading(true);
    setError('');
    try {
      const loc = profile ? `${profile.district}, ${profile.state}` : 'Mysuru, Karnataka';
      const res = await getIrrigationAdvisory({
        farmer_id: farmerId,
        location: loc,
        crop: profile?.current_crop,
        crop_stage: profile?.crop_stage,
        irrigation_method: profile?.irrigation_method,
      });
      setResult(res.data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to fetch weather data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (profile || !farmerId) fetchWeather();
  }, [profile]);

  const weather = result?.weather_summary as Record<string, unknown> | undefined;
  const forecast = (weather?.forecast as Record<string, unknown>[]) || [];
  const demoMode = !!(result?.demo_mode);

  const chartData = forecast.map((f: Record<string, unknown>) => ({
    day: f.day as string,
    maxTemp: f.max,
    minTemp: f.min,
    rainProb: f.rain_prob,
    rainMm: f.rain_mm,
  }));

  return (
    <div style={{ maxWidth: 1000 }}>
      <SectionHeader
        title="Weather & Irrigation Advisory"
        subtitle="Weather-based irrigation recommendations powered by real-time data"
        icon={<CloudRain size={18} />}
        action={
          <Button onClick={fetchWeather} loading={loading} icon={<CloudRain size={16} />}>
            Refresh
          </Button>
        }
      />

      {error && <Alert type="error" className="mb-4">{error}</Alert>}

      {loading && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
          <LoadingSpinner size={28} />
          <p style={{ marginTop: 12, fontSize: 14 }}>Fetching weather data...</p>
        </div>
      )}

      {!loading && !result && (
        <Alert type="info">
          Set up your farm profile with location details to get weather-based irrigation advice.
          <Button onClick={fetchWeather} size="sm" style={{ marginLeft: 8 }}>Load Demo</Button>
        </Alert>
      )}

      {result && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {demoMode && <DemoBadge />}

          {/* Current Weather */}
          {weather && (
            <Card>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                <h3 style={{ fontSize: 15, fontWeight: 600 }}>🌤 Current Weather — {weather.location as string}</h3>
                {weather.demo && <DemoBadge />}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12 }}>
                <WeatherStat icon={<Thermometer size={20} color="#ef4444" />} value={`${Math.round(weather.temperature as number)}°C`} label="Temperature" />
                <WeatherStat icon={<Droplets size={20} color="#3b82f6" />} value={`${weather.humidity}%`} label="Humidity" />
                <WeatherStat icon={<CloudRain size={20} color="#60a5fa" />} value={`${weather.rain_probability}%`} label="Rain Probability" />
                <WeatherStat icon={<Wind size={20} color="#6b7280" />} value={`${Math.round(weather.wind_speed as number || 0)} km/h`} label="Wind Speed" />
                <WeatherStat icon={<Sun size={20} color="#f59e0b" />} value={String(weather.description)} label="Condition" wide />
              </div>
            </Card>
          )}

          {/* Irrigation Advisory */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>💧 Irrigation Recommendation</h3>
            <div style={{
              background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10,
              padding: '14px 16px', fontSize: 14, color: '#14532d', fontWeight: 500,
            }}>
              {result.irrigation_recommendation as string}
            </div>
            {result.next_irrigation && (
              <p style={{ marginTop: 8, fontSize: 13, color: '#6b7280' }}>
                📅 Next irrigation: <strong>{result.next_irrigation as string}</strong>
              </p>
            )}
          </Card>

          {/* Warnings */}
          {(result.weather_warnings as string[])?.length > 0 && (
            <div>
              {(result.weather_warnings as string[]).map((w, i) => (
                <Alert key={i} type="warning" className="mb-2">{w}</Alert>
              ))}
            </div>
          )}

          {/* 5-Day Forecast Chart */}
          {chartData.length > 0 && (
            <Card>
              <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>📊 5-Day Forecast</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="maxTemp" name="Max Temp (°C)" fill="#f87171" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="minTemp" name="Min Temp (°C)" fill="#60a5fa" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="rainProb" name="Rain Prob (%)" fill="#34d399" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          )}

          {/* Water Saving Tips */}
          <Card>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 12 }}>💡 Water-Saving Tips</h3>
            <ul style={{ paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              {(result.water_saving_tips as string[])?.map((tip, i) => (
                <li key={i} style={{ fontSize: 13, color: '#374151' }}>{tip}</li>
              ))}
            </ul>
          </Card>

          {/* AI Advisory */}
          {result.ai_advisory && (
            <Card>
              <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>🤖 AI Advisory</h3>
              <div className="ai-response" style={{ fontSize: 14, color: '#1f2937' }}>{result.ai_advisory as string}</div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

const WeatherStat: React.FC<{ icon: React.ReactNode; value: string; label: string; wide?: boolean }> = ({ icon, value, label, wide }) => (
  <div style={{
    textAlign: 'center', background: '#f9fafb', borderRadius: 10, padding: '14px 10px',
    gridColumn: wide ? 'span 2' : undefined,
  }}>
    <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 6 }}>{icon}</div>
    <div style={{ fontSize: 18, fontWeight: 700, color: '#111827' }}>{value}</div>
    <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{label}</div>
  </div>
);
