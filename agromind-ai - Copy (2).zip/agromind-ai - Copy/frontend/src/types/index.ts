// AgroMind AI — TypeScript Type Definitions

export interface FarmerProfile {
  farmer_id: string;
  name?: string;
  state: string;
  district: string;
  village?: string;
  farm_size?: number;
  farm_size_unit: 'acres' | 'hectares';
  soil_type?: string;
  water_source?: string;
  irrigation_method?: string;
  current_crop?: string;
  crop_stage?: string;
  sowing_date?: string;
  season?: string;
  budget?: number;
  farming_preference: 'conventional' | 'organic' | 'integrated';
  preferred_language: 'en' | 'kn' | 'hi';
  soil_ph?: number;
  soil_nitrogen?: number;
  soil_phosphorus?: number;
  soil_potassium?: number;
  soil_ec?: number;
  created_at?: string;
  updated_at?: string;
}

export interface AgentResult {
  agent_name: string;
  status: 'success' | 'error' | 'skipped' | 'demo';
  task: string;
  result: Record<string, unknown>;
  sources: KnowledgeSource[];
  execution_time_ms?: number;
}

export interface ChatResponse {
  query: string;
  answer: string;
  agents_used: AgentResult[];
  rag_sources: KnowledgeSource[];
  demo_mode: boolean;
  model_used: string;
  timestamp: string;
}

export interface KnowledgeSource {
  title?: string;
  organization?: string;
  crop?: string;
  state?: string;
  source_url?: string;
  type?: string;
  relevance?: number;
  demo?: boolean;
  text?: string;
}

export interface WeatherData {
  location: string;
  temperature: number;
  feels_like?: number;
  humidity: number;
  rainfall_mm?: number;
  wind_speed?: number;
  description: string;
  rain_probability?: number;
  forecast?: ForecastDay[];
  demo?: boolean;
}

export interface ForecastDay {
  day: string;
  max: number;
  min: number;
  rain_prob: number;
  rain_mm: number;
}

export interface MarketInsight {
  crop: string;
  current_price?: number;
  price_unit: string;
  market_name?: string;
  msp?: number;
  price_trend?: string;
  farm_analysis: {
    farm_size_acres: number;
    expected_yield_quintals: number;
    gross_revenue: number;
    cultivation_cost: number;
    net_profit: number;
    roi_percent: number;
  };
  cost_breakdown: Record<string, unknown>;
  marketing_options: string[];
  disclaimer: string;
  demo_mode: boolean;
}

export interface DetectionResult {
  detected_issue: string;
  possible_issues: string[];
  confidence?: string;
  symptoms: string[];
  severity: string;
  ipm_recommendations: string[];
  chemical_options: string[];
  consult_expert: boolean;
  ai_advisory?: string;
  disclaimer: string;
  demo_mode: boolean;
}

export interface CropAdvisoryResult {
  recommended_crops: RecommendedCrop[];
  nutrient_advice: NutrientAdvice;
  planting_calendar: Record<string, string>;
  sustainable_practices: string[];
  ai_advisory?: string;
  sources: KnowledgeSource[];
  demo_mode: boolean;
}

export interface RecommendedCrop {
  name: string;
  yield_estimate?: string;
  input_cost?: string;
  indicative_price?: string;
  water_requirement?: string;
  suitable_soil?: string[];
}

export interface NutrientAdvice {
  nitrogen: string;
  phosphorus: string;
  potassium: string;
  notes: string;
  source?: string;
}

export interface IntegrationStatus {
  name: string;
  configured: boolean;
  status: 'connected' | 'demo' | 'error' | 'not_configured';
  message?: string;
  demo_mode: boolean;
  model?: string;
}

export interface HistoryItem {
  id: number;
  farmer_id: string;
  query: string;
  response_preview: string;
  agents_used?: string[];
  demo_mode: boolean;
  created_at: string;
}
