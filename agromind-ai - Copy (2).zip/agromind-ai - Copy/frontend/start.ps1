# AgroMind AI — Frontend Startup Script (PowerShell)
# Run from the frontend folder:  .\start.ps1

Set-StrictMode -Off

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  AgroMind AI Frontend Startup" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# ── Check Node.js ─────────────────────────────────────────────────────────────
try {
    $nodeVersion = node --version 2>&1
    Write-Host "Node.js found: $nodeVersion" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Node.js not found." -ForegroundColor Red
    Write-Host "Install Node.js 18+ from https://nodejs.org/" -ForegroundColor Yellow
    exit 1
}

# ── Install npm packages if needed ────────────────────────────────────────────
if (-not (Test-Path "node_modules")) {
    Write-Host "Installing npm packages (this may take a few minutes)..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) { Write-Host "npm install failed" -ForegroundColor Red; exit 1 }
} else {
    Write-Host "node_modules already present — skipping npm install" -ForegroundColor Gray
}

# ── Create .env if missing ────────────────────────────────────────────────────
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example" -ForegroundColor Green
}

# ── Start dev server ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Starting AgroMind AI Frontend..." -ForegroundColor Green
Write-Host "  App URL  : http://localhost:5173" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop." -ForegroundColor Gray
Write-Host ""

npm run dev
