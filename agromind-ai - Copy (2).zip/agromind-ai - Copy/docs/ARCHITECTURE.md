# AgroMind AI — Architecture

## System Architecture

```mermaid
graph TB
    subgraph Frontend["Frontend (React + TypeScript + Vite)"]
        UI["Dashboard / Pages"]
        API_CLIENT["Axios API Client"]
    end

    subgraph Backend["Backend (FastAPI + Python)"]
        ROUTER["FastAPI Routes"]
        ORCH["Agent Orchestrator"]
        
        subgraph Agents["Specialized Agents"]
            CROP["Crop Advisory Agent"]
            WEATHER["Weather & Irrigation Agent"]
            PEST["Pest & Disease Agent"]
            MARKET["Market Insights Agent"]
        end
        
        RAG["RAG Pipeline (ChromaDB)"]
        GRANITE["IBM Granite Service"]
        DB["SQLite Database"]
    end

    subgraph External["External Services"]
        WATSONX["IBM watsonx.ai\n(Granite LLM)"]
        OPENWEATHER["OpenWeatherMap API"]
        AGMARKNET["AGMARKNET / data.gov.in"]
    end

    subgraph KnowledgeBase["Knowledge Base"]
        CHROMA["ChromaDB Vector Store"]
        DOCS["Agricultural Documents\n(ICAR, KVK, IMD, APMC)"]
    end

    UI --> API_CLIENT
    API_CLIENT --> ROUTER
    ROUTER --> ORCH
    ORCH --> CROP
    ORCH --> WEATHER
    ORCH --> PEST
    ORCH --> MARKET
    ORCH --> RAG
    ORCH --> GRANITE

    CROP --> GRANITE
    WEATHER --> GRANITE
    PEST --> GRANITE
    MARKET --> GRANITE

    RAG --> CHROMA
    CHROMA --> DOCS

    GRANITE --> WATSONX
    WEATHER --> OPENWEATHER
    MARKET --> AGMARKNET

    ORCH --> DB
    ROUTER --> DB
```

## Data Flow: Farmer Query Processing

```mermaid
sequenceDiagram
    participant F as Farmer (Frontend)
    participant API as FastAPI Backend
    participant O as Orchestrator
    participant RAG as RAG Pipeline
    participant CROP as Crop Agent
    participant WX as Weather Agent
    participant PEST as Pest Agent
    participant MKT as Market Agent
    participant G as IBM Granite

    F->>API: POST /api/chat (query + farmer_id)
    API->>API: Load farmer profile from SQLite
    API->>O: process_query(query, profile)
    O->>O: classify_intent(query)
    O->>RAG: retrieve(query, top_k=4)
    RAG-->>O: relevant documents + sources
    
    par Parallel Agent Execution
        O->>CROP: run(profile, query)
        O->>WX: run(profile, query)
        O->>PEST: run(profile, query, image)
        O->>MKT: run(profile, query)
    end

    CROP->>G: generate(prompt)
    WX->>G: generate(prompt)
    PEST->>G: generate(prompt)
    MKT->>G: generate(prompt)
    
    G-->>CROP: AI response
    G-->>WX: AI response
    G-->>PEST: AI response
    G-->>MKT: AI response

    O->>G: synthesize(all_agent_results)
    G-->>O: unified advisory

    O-->>API: {answer, agents_used, rag_sources, demo_mode}
    API->>API: Save to advisory history
    API-->>F: ChatResponse
```

## Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Frontend | React 18 + TypeScript + Vite | SPA with responsive dashboard |
| Routing | React Router v6 | Client-side navigation |
| Charts | Recharts | Weather and market visualizations |
| HTTP Client | Axios | API communication |
| Backend | FastAPI + Python | REST API and agent coordination |
| ORM | SQLAlchemy (async) | Database operations |
| Database | SQLite (aiosqlite) | Farmer profiles and history |
| LLM | IBM Granite via watsonx.ai | Agricultural reasoning and advisory |
| LLM SDK | ibm-watsonx-ai | Official IBM SDK |
| RAG | ChromaDB + SentenceTransformers | Knowledge retrieval |
| Embeddings | all-MiniLM-L6-v2 | Text vectorization |
| Image Processing | Pillow | Image validation and analysis |
| Weather | OpenWeatherMap API | Live weather data |
| Market Data | AGMARKNET / data.gov.in | Live agricultural prices |

## Agent Architecture

### Intent Classification
The orchestrator classifies each query into one or more intents:
- `crop` — Crop selection, nutrients, planting advice
- `weather_irrigation` — Weather analysis, irrigation timing
- `pest_disease` — Disease/pest identification, IPM
- `market` — Prices, profitability, marketing

### Demo Mode
All external services (IBM Granite, weather API, market API) have demo fallbacks.
Demo data is clearly labeled with "⚡ DEMO MODE" badges throughout the UI.

## Security Considerations
- API keys stored server-side only (never in frontend code)
- File upload validation (type + size limits)
- CORS configured for specific origins
- Input validation via Pydantic schemas
- Structured logging (no sensitive data in logs)
