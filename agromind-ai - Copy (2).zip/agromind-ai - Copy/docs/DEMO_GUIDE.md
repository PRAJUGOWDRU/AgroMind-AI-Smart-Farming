# AgroMind AI — Hackathon Demo Guide

## 🌾 Demonstration Scenario

**Farmer:** Ramesh Kumar, Mysuru District, Karnataka  
**Farm:** 2.5 acres, Red Laterite soil, Borewell, Drip irrigation  
**Crop:** Ragi (Finger Millet), Vegetative stage  
**Season:** Kharif 2024  
**Budget:** ₹25,000/year  
**Query:** "My crop leaves are turning yellow, rainfall is expected this week, and I have a limited budget. What should I do?"

---

## 🎯 Step-by-Step Demo

### Step 1: Start the Application
```bash
# Terminal 1 — Backend
cd agromind-ai/backend
uvicorn app.main:app --reload

# Terminal 2 — Frontend
cd agromind-ai/frontend
npm run dev
```

Open: http://localhost:5173

### Step 2: Create Farmer Profile
1. Click **"My Farm Profile"** in the sidebar
2. Fill in:
   - Name: Ramesh Kumar
   - State: Karnataka
   - District: Mysuru
   - Farm Size: 2.5 acres
   - Soil Type: Red Laterite
   - Water Source: Borewell
   - Irrigation Method: Drip Irrigation
   - Current Crop: Ragi (Finger Millet)
   - Crop Stage: Vegetative
   - Season: Kharif
   - Budget: 25000
3. Click **"Save Profile"**

### Step 3: Ask AgroMind AI
1. Click **"Ask AgroMind AI"** in the sidebar
2. Type the query:
   > "My crop leaves are turning yellow, rainfall is expected this week, and I have a limited budget. What should I do?"
3. Press Enter
4. Observe:
   - **Multiple agents** being invoked (Pest & Disease, Weather & Irrigation, Crop Advisory)
   - **RAG sources** retrieved from ICAR and KVK Karnataka knowledge base
   - **Unified advisory** with prioritized action plan
   - Clear **DEMO MODE** badge if IBM Granite is not configured

### Step 4: Disease Detection
1. Click **"Pest & Disease"**
2. Type: "Leaves are yellowing from the bottom, brown spots visible"
3. Optionally upload a crop photo (JPG/PNG)
4. Click **"Analyze Crop"**
5. Review:
   - Detected issue with confidence
   - IPM recommendations (cultural/biological/chemical)
   - Disclaimer and expert consultation guidance

### Step 5: Weather & Irrigation
1. Click **"Weather & Irrigation"**
2. Click **"Refresh"** to load weather for Mysuru
3. Observe:
   - Current weather with humidity, rain probability
   - **Irrigation recommendation** based on expected rainfall
   - 5-day forecast bar chart
   - Water-saving tips

### Step 6: Market & Profit Analysis
1. Click **"Market & Profit"**
2. Select: Crop=Ragi, District=Mysuru, Farm Size=2.5
3. Click **"Get Market Insights"**
4. Review:
   - Current APMC price vs MSP
   - Estimated gross revenue, costs, net profit
   - ROI percentage
   - Cost breakdown chart
   - Marketing options (mandi, e-NAM, FPO)

### Step 7: Crop Advisory
1. Click **"Crop & Soil Advisory"**
2. Set: District=Mysuru, Season=Kharif, Soil=Red Laterite, Budget=25000
3. Click **"Get Crop Advisory"**
4. Review:
   - Top 3 recommended crops with yield/cost/price
   - Nutrient recommendations (N-P-K)
   - Planting calendar
   - Sustainable practices

### Step 8: Knowledge Base
1. Click **"Knowledge Base"**
2. Search: "How to manage blast disease in ragi?"
3. Observe RAG retrieval from ICAR Ragi Cultivation Guide
4. View sources tab for indexed documents
5. Upload tab available for adding new documents

### Step 9: Settings & Agent Activity
1. Click **"Settings"** to view IBM Granite configuration status
2. Click **"AI Agent Activity"** to see:
   - All 5 agents (4 specialized + orchestrator) with status
   - Integration status (Granite, Weather, Market, RAG)
   - Advisory history from this demo

---

## 🔄 With IBM Granite Configured

When `WATSONX_API_KEY` and `WATSONX_PROJECT_ID` are set:
1. All AI responses come from IBM Granite (`ibm/granite-13b-chat-v2`)
2. DEMO MODE badges disappear
3. Responses are fully AI-powered, personalized, and context-aware
4. Settings page shows "✅ Connected" status

---

## 📊 Key Features to Highlight

| Feature | Technology | Demo Status |
|---------|-----------|-------------|
| Multi-agent orchestration | Custom Python agents | ✅ Full demo |
| IBM Granite integration | ibm-watsonx-ai SDK | ✅ With API key / DEMO mode |
| RAG knowledge retrieval | ChromaDB + SentenceTransformers | ✅ Full demo |
| Crop disease detection | Pillow + Granite reasoning | ✅ Full demo |
| Weather-based irrigation | OpenWeatherMap | ✅ With API key / DEMO mode |
| Market price analysis | AGMARKNET demo data | ✅ Full demo |
| Farmer profile management | SQLite + SQLAlchemy | ✅ Full demo |
| Knowledge base upload | ChromaDB + text extraction | ✅ Full demo |
| Responsive dashboard | React + TypeScript | ✅ Full demo |
| Kannada language support | Profile preference | ✅ Structure ready |

---

## ⚠️ Known Limitations

1. **IBM Granite required for AI responses** — Demo mode provides realistic fallbacks
2. **Image analysis** uses basic pattern matching; a dedicated vision model would improve accuracy
3. **Market prices** are from 2024 estimates; live AGMARKNET API required for real-time data
4. **Kannada responses** require prompting Granite in Kannada (profile language setting)
5. **Python 3.10+** required for backend; not pre-installed on all systems
6. **ChromaDB** creates local vector store; no cloud deployment configured
