# AgroMind AI — Complete Setup & Run Guide

## Prerequisites

- **Node.js 18+** (for frontend)
- **Python 3.10+** (for backend)
- **pip** (Python package manager)

---

## 1. Quick Start

### Clone / Setup

```bash
cd agromind-ai
```

### Backend Setup (PowerShell)

```powershell
cd agromind-ai\backend

# Create virtual environment
python -m venv venv

# Activate (PowerShell)
venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Copy environment file
Copy-Item .env.example .env

# Edit .env with your credentials (optional — demo mode works without them)
# See Section 3 for IBM Granite setup

# Start backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**One-click alternative:**
```powershell
cd agromind-ai\backend
.\start.ps1
```

Backend will be available at: http://localhost:8000
API docs: http://localhost:8000/api/docs

### Frontend Setup (PowerShell)

```powershell
cd agromind-ai\frontend

# Install dependencies
npm install

# Copy environment file
Copy-Item .env.example .env

# Start development server
npm run dev
```

**One-click alternative:**
```powershell
cd agromind-ai\frontend
.\start.ps1
```

Frontend will be available at: http://localhost:5173

---

## 2. IBM watsonx.ai / Granite Setup

1. Go to [IBM Cloud](https://cloud.ibm.com/catalog/services/watson-studio)
2. Create a watsonx.ai service instance
3. Create a project in watsonx.ai
4. Get your Project ID from project settings
5. Generate an API key: IBM Cloud → Manage → IAM → API keys
6. Edit `backend/.env`:

```
WATSONX_API_KEY=your_actual_api_key
WATSONX_PROJECT_ID=your_project_id
WATSONX_URL=https://us-south.ml.cloud.ibm.com
WATSONX_MODEL_ID=ibm/granite-13b-chat-v2
DEMO_MODE=false
```

7. Restart backend: `uvicorn app.main:app --reload`
8. Test connection: Go to **Settings** → **Test Connection**

### Available IBM Granite Models

| Model ID | Description |
|----------|-------------|
| `ibm/granite-13b-chat-v2` | Best for agricultural advisory chat (recommended) |
| `ibm/granite-13b-instruct-v2` | Good for structured recommendations |
| `ibm/granite-3-8b-instruct` | Faster, lower resource usage |

---

## 3. Weather API Setup (Optional)

1. Register at [OpenWeatherMap](https://openweathermap.org/api)
2. Get a free API key
3. Add to `backend/.env`:
```
OPENWEATHER_API_KEY=your_key
```

---

## 4. Market Data API Setup (Optional)

1. Register at [data.gov.in](https://data.gov.in)
2. Get an API key for AGMARKNET dataset
3. Add to `backend/.env`:
```
AGMARKNET_API_KEY=your_key
```

---

## 5. Run Tests

```powershell
cd agromind-ai\backend
venv\Scripts\Activate.ps1

# Run all tests
pytest tests/ -v

# Run a specific test
pytest tests/test_api.py::test_health -v
```

---

## 6. Production Build

### Frontend

```bash
cd frontend
npm run build
# Output in frontend/dist/
```

### Backend (production)

```bash
cd backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## 7. Environment Variables Reference

### Backend (`backend/.env`)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `WATSONX_API_KEY` | For AI | - | IBM Cloud API key |
| `WATSONX_PROJECT_ID` | For AI | - | watsonx.ai project ID |
| `WATSONX_URL` | For AI | `https://us-south.ml.cloud.ibm.com` | watsonx.ai endpoint |
| `WATSONX_MODEL_ID` | No | `ibm/granite-13b-chat-v2` | Granite model |
| `DEMO_MODE` | No | `true` | Force demo mode |
| `DATABASE_URL` | No | `sqlite+aiosqlite:///./agromind.db` | Database connection |
| `OPENWEATHER_API_KEY` | For weather | - | OpenWeatherMap key |
| `AGMARKNET_API_KEY` | For market | - | data.gov.in key |
| `MAX_UPLOAD_SIZE_MB` | No | `10` | Max image/doc upload |
| `LOG_LEVEL` | No | `INFO` | Logging level |

### Frontend (`frontend/.env`)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `VITE_API_BASE_URL` | No | `http://localhost:8000` | Backend URL |

---

## 8. Directory Structure

```
agromind-ai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app entry point
│   │   ├── config.py            # Settings from env vars
│   │   ├── api/                 # API route handlers
│   │   ├── agents/              # Specialized AI agents
│   │   │   ├── crop_advisory_agent.py
│   │   │   ├── weather_irrigation_agent.py
│   │   │   ├── pest_disease_agent.py
│   │   │   ├── market_insights_agent.py
│   │   │   └── orchestrator.py
│   │   ├── services/
│   │   │   └── granite_service.py  # IBM Granite adapter
│   │   ├── rag/
│   │   │   └── pipeline.py      # ChromaDB RAG pipeline
│   │   ├── models/              # SQLAlchemy DB models
│   │   ├── schemas/             # Pydantic request/response schemas
│   │   └── database/            # DB connection
│   ├── tests/                   # Test suite
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.tsx              # Root with routing
│   │   ├── components/          # Shared UI components
│   │   ├── pages/               # 10 application pages
│   │   ├── services/api.ts      # Centralized API client
│   │   ├── hooks/               # Custom React hooks
│   │   └── types/               # TypeScript type definitions
│   ├── package.json
│   └── .env.example
├── knowledge_base/
│   └── README.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API.md
│   └── DEMO_GUIDE.md
└── README.md
```
