# AgroMind AI — API Reference

Base URL: `http://localhost:8000`  
Interactive Docs: `http://localhost:8000/api/docs`

---

## Health

### GET /api/health
Returns application health and service status.

**Response:**
```json
{
  "status": "ok",
  "app": "AgroMind AI",
  "version": "1.0.0",
  "demo_mode": true,
  "services": {
    "database": "ok",
    "ibm_granite": "not_configured",
    "rag_pipeline": "ready",
    "weather_api": "demo",
    "market_api": "demo"
  }
}
```

---

## Farmer Profile

### POST /api/farmer/profile
Create a new farmer profile.

**Request:**
```json
{
  "farmer_id": "ramesh_mysuru_001",
  "name": "Ramesh Kumar",
  "state": "Karnataka",
  "district": "Mysuru",
  "farm_size": 2.5,
  "farm_size_unit": "acres",
  "soil_type": "red laterite",
  "current_crop": "Ragi",
  "season": "Kharif",
  "budget": 25000
}
```

### GET /api/farmer/profile/{farmer_id}
Retrieve a farmer profile.

### PUT /api/farmer/profile/{farmer_id}
Update a farmer profile.

---

## Advisory & Chat

### POST /api/chat
Main AI advisory endpoint — routes to multi-agent orchestrator.

**Request:**
```json
{
  "query": "My crop leaves are turning yellow, rainfall expected this week",
  "farmer_id": "ramesh_mysuru_001",
  "language": "en"
}
```

**Response:**
```json
{
  "query": "...",
  "answer": "...",
  "agents_used": [
    {
      "agent_name": "Pest & Disease Detection Agent",
      "status": "demo",
      "task": "...",
      "execution_time_ms": 120
    }
  ],
  "rag_sources": [...],
  "demo_mode": true,
  "model_used": "DEMO_MODE",
  "timestamp": "2024-10-14T..."
}
```

### POST /api/advisory/crop
Crop-specific advisory with recommendations.

### POST /api/advisory/irrigation  
Weather-based irrigation advisory.

---

## Detection

### POST /api/detection/analyze
Pest and disease detection (multipart form).

**Form Data:**
- `query` (str): Symptom description
- `farmer_id` (str, optional): Farmer ID
- `image` (file, optional): Crop image (JPG/PNG/WebP, max 10MB)

---

## Market

### POST /api/market/insights
Market price and profitability analysis.

**Request:**
```json
{
  "crop": "Ragi",
  "district": "Mysuru",
  "state": "Karnataka",
  "farm_size": 2.5,
  "farm_size_unit": "acres"
}
```

---

## RAG / Knowledge

### POST /api/rag/query
Search the agricultural knowledge base.

**Request:**
```json
{
  "query": "How to manage blast disease in ragi?",
  "crop": "ragi",
  "state": "Karnataka",
  "top_k": 5
}
```

### POST /api/knowledge/upload
Upload a document to the knowledge base (multipart form).

### GET /api/knowledge/sources
List all indexed knowledge sources.

---

## Status

### GET /api/integrations/status
Integration status for all external services.

### POST /api/integrations/test-granite
Test IBM Granite connection.

### GET /api/agents/status
Status of all AI agents.

### GET /api/history
Advisory history. Optional query param: `farmer_id`, `limit`.
